# Trading Journal — handoff

This is the latest deployed Trading Journal source export, not a static HTML site.
React 19 + TypeScript + Vinext/Vite; Cloudflare Worker APIs; Drizzle + D1 database (DB) and R2 object storage (BUCKET). Georgian, English and Russian dictionaries are in lib/journal-*.ts.

## Project map
- app/trading-journal.tsx: main journal and account workflow
- app/trade-calendar.tsx, app/economic-calendar.tsx: trading calendar and economic news
- app/statistics-page.tsx, lib/advanced-statistics.ts: statistics
- app/profile-menu.tsx and app/settings/: profile and account progress
- app/api/: protected server routes
- db/schema.ts and drizzle/: schema and migrations
- tests/: existing workflow and calculations tests

## Preserve current behavior
- Keep the calm dark/light design; avoid bright purple.
- Profile menu no longer shows Settings or language choices. Profile page has name/photo and account progress. Journal lower-left utility block and floating language selector were removed.
- Use Georgian spelling “თრეიდი”. Keep existing language dictionaries.
- Do not change access from owner-private or enable actual billing without explicit authorization. Membership billing is currently a test flow.
- Maintain owner-scoped authorization for trades, accounts, screenshots and profiles. Never trust unauthenticated identity headers on a different hosting platform.
- Preserve D1/R2 user data; never reset production or replay migrations blindly.
- Economic news uses fixed Fair Economy thisweek JSON and archived received weeks; do not fabricate next-week news.

## Development
Node >=22.13; package manager pnpm@11.25.0. Install locked dependencies using pnpm install --frozen-lockfile (package install:ci invokes a Bash helper; Windows users can use pnpm directly). Read README.md and scripts/execution-profile.mjs for portable runtime setup. npm run dev starts a local development server. npm run build builds the Worker; npx tsc --noEmit --incremental false checks TypeScript. Local D1 migrations must be applied to local storage in order for data routes to work; README.md documents this. Existing test files contain local Miniflare fixtures.

## Hosting boundary
.openai/hosting.json identifies the existing private Sites project. A GitHub upload does not publish changes to it. Production ChatGPT sign-in, service access and D1/R2 bindings are platform-managed. To run elsewhere, provision storage and authentication and adapt the deployment configuration; simply opening the app in Claude is not a full hosting migration. For the existing Site, return changes for a Sites deployment.

## Export scope
This ZIP contains source, schema, migrations, assets, dependency lockfile and tests. It excludes installed dependencies, Git history, build output, credentials, production database rows, private screenshots/photos and news cache. It is not a personal-data backup.
