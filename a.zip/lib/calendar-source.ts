import {getScreenshotsBucket} from '@/db';
import {MONTHLY_NEWS_URL,NEWS_URL,parseEconomicEvents,parseMonthlyEconomicEvents,economicWeek,type EconomicEvent} from '@/lib/economic-news';
import {shiftDate,todayIn} from '@/lib/trading';
export type Cached={events:EconomicEvent[];fetchedAt:string;attemptedAt?:string;failed?:boolean;coverage?:{start:string;end:string};source?:string;schemaVersion?:number};
const KEY='public-feed-cache/economic-calendar-v1.json';let pending:Promise<Cached|null>|null=null;
async function calendar():Promise<Cached|null>{const bucket=getScreenshotsBucket();let saved:Cached|null=null;try{const object=await bucket.get(KEY);if(object)saved=await object.json<Cached>();}catch{}
 // A manually transcribed Forex Factory month is authoritative until the next
 // monthly import replaces it. Do not silently swap it for another provider.
 if(saved?.source==='Forex Factory (manual)'&&saved.schemaVersion===5){await archive(saved);return saved;}
 const last=Date.parse(saved?.attemptedAt??saved?.fetchedAt??''),from=todayIn('America/New_York'),to=shiftDate(from,29);if(saved&&saved.schemaVersion===4&&saved.coverage?.end>=to&&Date.now()-last<(saved.failed?600000:3600000)){await archive(saved);return saved;}
 if(saved?.events.length)await archive(saved);
 const now=new Date().toISOString();
 try{const url=new URL(MONTHLY_NEWS_URL);url.searchParams.set('from',from);url.searchParams.set('to',to);url.searchParams.set('limit','500');const response=await fetch(url,{headers:{Accept:'application/json'},signal:AbortSignal.timeout(12000)});if(!response.ok)throw Error('Monthly calendar provider unavailable');const raw=await response.text();if(raw.length>1000000)throw Error('Calendar feed too large');const parsed=JSON.parse(raw) as unknown;const events=parseMonthlyEconomicEvents(parsed);const next:Cached={events,fetchedAt:now,attemptedAt:now,failed:false,coverage:{start:from,end:to},source:'Finance Calendar',schemaVersion:4};await archive(next);await bucket.put(KEY,JSON.stringify(next),{httpMetadata:{contentType:'application/json'}});return next;
 }catch{
  // Keep the previous month when the range provider is temporarily down; use
  // the established weekly feed only when no monthly snapshot is available.
  if(!saved?.events.length){try{const response=await fetch(NEWS_URL,{headers:{Accept:'application/json'},signal:AbortSignal.timeout(12000)});if(response.ok){const raw=await response.text();if(raw.length<=1000000){const events=parseEconomicEvents(JSON.parse(raw));const next:Cached={events,fetchedAt:now,attemptedAt:now,failed:false,coverage:economicWeek(events),source:'Forex Factory'};await archive(next);await bucket.put(KEY,JSON.stringify(next),{httpMetadata:{contentType:'application/json'}});return next;}}}catch{}}
  const fallback:Cached={events:saved?.events??[],fetchedAt:saved?.fetchedAt??'',attemptedAt:now,failed:true,coverage:saved?.coverage,source:saved?.source??'Forex Factory'};try{await bucket.put(KEY,JSON.stringify(fallback));}catch{}return fallback;
 }}

async function archive(data:Cached){const groups=new Map<string,EconomicEvent[]>();for(const event of data.events){const start=economicWeek([event]).start;groups.set(start,[...(groups.get(start)??[]),event]);}for(const events of groups.values())await archiveWeek({...data,events});}
async function archiveWeek(data:Cached){if(!data.events.length)return;const bucket=getScreenshotsBucket(),coverage=economicWeek(data.events),key=`public-feed-cache/calendar-weeks/${coverage.start}.json`;const previous=await bucket.get(key);if(previous){const old=await previous.json<Cached>();if(old.fetchedAt>=data.fetchedAt)return;}await bucket.put(key,JSON.stringify({...data,coverage}),{httpMetadata:{contentType:'application/json'}});}
export async function currentCalendar(){if(!pending)pending=calendar().finally(()=>{pending=null;});return pending;}

export async function storeMonthlyCalendar(events:EconomicEvent[],from:string,to:string){const now=new Date().toISOString(),data:Cached={events,fetchedAt:now,attemptedAt:now,failed:false,coverage:{start:from,end:to},source:'Forex Factory (manual)',schemaVersion:5};const bucket=getScreenshotsBucket();await archive(data);await bucket.put(KEY,JSON.stringify(data),{httpMetadata:{contentType:'application/json'}});return data;}

export async function savedCalendar(){try{const object=await getScreenshotsBucket().get(KEY);return object?await object.json<Cached>():null;}catch{return null;}}

