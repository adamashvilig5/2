import { shiftDate,stats,tradeOrder,type Trade } from './trading.ts';

export const WEEKDAY_LABELS=['ორშაბათი','სამშაბათი','ოთხშაბათი','ხუთშაბათი','პარასკევი','შაბათი','კვირა'];
export type PerformanceGroup={key:string;label:string;pnl:number;count:number;wins:number;winRate:number};
export function weekStart(date:string){const day=new Date(date+'T00:00:00Z').getUTCDay();return shiftDate(date,-((day+6)%7));}
export function weekdayPerformance(trades:Trade[]):PerformanceGroup[]{
 return WEEKDAY_LABELS.map((label,index)=>{const rows=trades.filter(t=>(new Date(t.date+'T00:00:00Z').getUTCDay()+6)%7===index),wins=rows.filter(t=>t.pnl>0).length;return {key:String(index),label,pnl:rows.reduce((sum,t)=>sum+t.pnl,0),count:rows.length,wins,winRate:rows.length?wins/rows.length*100:0};});
}
export function aggregatePerformance(trades:Trade[],kind:'day'|'week'|'month'|'year'|'session'):PerformanceGroup[]{
 const groups=new Map<string,Trade[]>();
 for(const t of trades){const key=kind==='day'?t.date:kind==='week'?weekStart(t.date):kind==='month'?t.date.slice(0,7):kind==='year'?t.date.slice(0,4):t.session;groups.set(key,[...(groups.get(key)??[]),t]);}
 return [...groups].map(([key,rows])=>({key,label:kind==='week'?`${key} — ${shiftDate(key,6)}`:key,pnl:rows.reduce((sum,t)=>sum+t.pnl,0),count:rows.length,wins:rows.filter(t=>t.pnl>0).length,winRate:rows.filter(t=>t.pnl>0).length/rows.length*100})).sort((a,b)=>b.pnl-a.pnl||a.key.localeCompare(b.key));
}
/** Daily, unannualized realized-equity Sharpe, with a zero daily risk-free rate.
 * Each calendar day is an equal period, including zero-P&L days. No fabricated
 * capital, annualization, or infinite score when return volatility is absent.
 * Formula: William F. Sharpe, The Sharpe Ratio (1994), ex-post definition.
 */
export function dailySharpe(trades:Trade[],opening:number|null,start:string,end:string){
 const empty=(reason:string,observations=0)=>({value:null as number|null,reason,observations,activeDays:0});
 if(opening===null||opening<=0)return empty('მიუთითე დადებითი საწყისი ბალანსი.');
 const span=Math.floor((Date.parse(end)-Date.parse(start))/86400000)+1;
 if(span<2)return empty('საჭიროა მინიმუმ ორი კალენდარული დღე.');
 const dayPnl=new Map<string,number>();for(const t of trades)if(t.date>=start&&t.date<=end)dayPnl.set(t.date,(dayPnl.get(t.date)??0)+t.pnl);
 if(dayPnl.size<2)return empty('საჭიროა მინიმუმ ორი დღე ჩაწერილი თრეიდებით.',span);
 let equity=opening,count=0,mean=0,m2=0;
 for(let i=0;i<span;i++){const pnl=dayPnl.get(shiftDate(start,i))??0;if(equity<=0)return empty('ბალანსი პერიოდის განმავლობაში ნულამდე ან ქვემოთ ჩამოვიდა.',count);const value=pnl/equity;count++;const delta=value-mean;mean+=delta/count;m2+=delta*(value-mean);equity+=pnl;}
 if(equity<=0)return empty('პერიოდის ბოლოს ბალანსი დადებითი უნდა იყოს.',count);
 const deviation=Math.sqrt(m2/(count-1));
 if(deviation<=Number.EPSILON)return empty('დღიური უკუგებების ცვალებადობა ნულია.',count);
 return {value:mean/deviation,reason:'',observations:count,activeDays:dayPnl.size};
}
export function advancedStatistics(trades:Trade[],opening:number|null,start:string,end:string){
 const rows=trades.filter(t=>t.date>=start&&t.date<=end).sort(tradeOrder),metrics=stats(rows,opening);
 const wins=rows.filter(t=>t.pnl>0),bestTrade=[...rows].sort((a,b)=>b.pnl-a.pnl||tradeOrder(a,b))[0]??null,worstTrade=[...rows].filter(t=>t.pnl<0).sort((a,b)=>a.pnl-b.pnl||tradeOrder(a,b))[0]??null,smallestWin=[...wins].sort((a,b)=>a.pnl-b.pnl||tradeOrder(a,b))[0]??null;
 return {metrics,expectancy:rows.length?metrics.pnl/rows.length:null,expectancyR:rows.length?rows.reduce((sum,t)=>sum+t.pnl/t.risk,0)/rows.length:null,bestTrade,worstTrade,smallestWin,sharpe:dailySharpe(rows,opening,start,end),weekdays:weekdayPerformance(rows),sessions:aggregatePerformance(rows,'session'),daily:aggregatePerformance(rows,'day'),records:{day:aggregatePerformance(rows,'day')[0]??null,week:aggregatePerformance(rows,'week')[0]??null,month:aggregatePerformance(rows,'month')[0]??null,year:aggregatePerformance(rows,'year')[0]??null,session:aggregatePerformance(rows,'session')[0]??null}};
}
export function calendarAction(trades:Trade[],date:string,today:string){const rows=trades.filter(t=>t.date===date).sort(tradeOrder);return {kind:rows.length===1?'review':rows.length>1||date>today?'list':'new',rows} as {kind:'review'|'list'|'new';rows:Trade[]};}
