import {z} from 'zod';
import {dateSchema,shiftDate} from './trading';
import {economicDay,type EconomicEvent} from './economic-news';
export const CURRENCIES=['USD','EUR','GBP','JPY','CAD','AUD','NZD','CHF','CNY','ALL'] as const;
export const IMPACTS=['High','Medium','Low','Holiday','Unknown'] as const;
export function calendarQuery(url:string,defaults:{start:string;end:string}){const p=new URL(url).searchParams;
 const from=dateSchema.parse(p.get('from')??defaults.start),to=dateSchema.parse(p.get('to')??defaults.end);
 if(from>to||Date.parse(to)-Date.parse(from)>365*86400000)throw Error('Choose a date range of at most 366 days, with from before to.');
 const timezone=p.get('timezone')??'America/New_York';try{new Intl.DateTimeFormat('en',{timeZone:timezone});}catch{throw Error('Invalid timezone.');}
 const currencies=p.has('currency')?z.array(z.enum(CURRENCIES)).parse(p.get('currency')!.split(',').filter(Boolean).map(v=>v.toUpperCase())):null;
 const impacts=p.has('impact')?z.array(z.enum(IMPACTS)).parse(p.get('impact')!.split(',').filter(Boolean).map(v=>v.charAt(0).toUpperCase()+v.slice(1).toLowerCase())):null;
 return {from,to,timezone,currencies,impacts};}
export type CalendarQuery=ReturnType<typeof calendarQuery>;
export function filterCalendar(events:EconomicEvent[],q:CalendarQuery){return events.filter(e=>{const day=economicDay(e,q.timezone);return day>=q.from&&day<=q.to&&(!q.currencies||q.currencies.includes(e.currency as typeof CURRENCIES[number]))&&(!q.impacts||q.impacts.includes(e.impact));});}
export function archiveWeeks(from:string,to:string){const d=new Date(from+'T12:00:00Z');d.setUTCDate(d.getUTCDate()-d.getUTCDay()-7);const weeks:string[]=[];for(let day=d.toISOString().slice(0,10);day<=shiftDate(to,7);day=shiftDate(day,7))weeks.push(day);return weeks;}
export function missingDates(from:string,to:string,periods:{start:string;end:string}[]){const missing:string[]=[];for(let d=from;d<=to;d=shiftDate(d,1))if(!periods.some(p=>d>=p.start&&d<=p.end))missing.push(d);return missing;}
