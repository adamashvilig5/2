export const SITE_OWNER_ID='6dc21193-6e50-4598-ad58-9ba6f57cb2f8';
export const SESSION_COOKIE='journal_member_session';
export type Member={id:string;email:string;name:string;created_at:string;suspended:number};
export type Subscription={member_id:string;status:'demo'|'demo_used'|'inactive'|'trialing'|'active';period_end:string;cancel_at_end:number;price_cents:number;revision:number};
export type MembershipPlan={price_cents:number;trial_days:number;revision:number;currency?:'USD'|'GEL'};
export type BillingEvent={id:string;kind:string;amount_cents:number;created_at:string};
export const defaultPlan:MembershipPlan={price_cents:2000,trial_days:0,revision:0,currency:'USD'};
export function hasAccess(member:Member,subscription:Subscription|null,now=Date.now()){return !member.suspended&&!!subscription&&(['demo','demo_used'].includes(subscription.status)||(['trialing','active'].includes(subscription.status)&&Date.parse(subscription.period_end)>now));}
export function nextMonth(now=new Date()){
 const result=new Date(now),day=result.getUTCDate();result.setUTCDate(1);result.setUTCMonth(result.getUTCMonth()+1);const last=new Date(Date.UTC(result.getUTCFullYear(),result.getUTCMonth()+1,0)).getUTCDate();result.setUTCDate(Math.min(day,last));return result.toISOString();
}
