import { z } from 'zod';
import { dateSchema } from './trading.ts';
export const MINDSET_OPTIONS=['confident','focused','calm','patient','anxious','fomo','revenge','tired'] as const;
export const innerSpaceSchema=z.object({date:dateSchema,mood:z.number().int().min(1).max(5).nullable(),mindset:z.array(z.enum(MINDSET_OPTIONS)).max(8).refine(a=>new Set(a).size===a.length),energy:z.number().int().min(1).max(5),note:z.string().max(6000),lesson:z.string().max(2000),intention:z.string().max(2000),breathingSessions:z.number().int().min(0).max(1000),revision:z.number().int().min(0)});
export type InnerEntry=z.infer<typeof innerSpaceSchema>;
export const blankInnerEntry=(date:string):InnerEntry=>({date,mood:null,mindset:[],energy:3,note:'',lesson:'',intention:'',breathingSessions:0,revision:0});
export function innerAnalytics(entries:InnerEntry[]){const checked=entries.filter(e=>e.mood!==null);return {entries:entries.length,averageMood:checked.length?checked.reduce((sum,e)=>sum+e.mood!,0)/checked.length:null,averageEnergy:entries.length?entries.reduce((sum,e)=>sum+e.energy,0)/entries.length:null,mindsets:MINDSET_OPTIONS.map(id=>({id,count:entries.filter(e=>e.mindset.includes(id)).length})).filter(e=>e.count).sort((a,b)=>b.count-a.count)};}
