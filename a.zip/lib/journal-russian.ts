// English source labels shared by Georgian and English components.
const entries = `
CSV import|Импорт CSV
Membership / test sign-up|Подписка / тестовая регистрация
Admin|Администрирование
Your subscription is inactive. Open Membership to manage access.|Подписка неактивна. Откройте раздел подписки для управления доступом.
Delete permanently|Удалить навсегда
Permanently delete account|Удалить счёт навсегда
This cannot be undone. The account and all its trades and screenshots will be permanently deleted and cannot be restored.|Это действие необратимо. Счёт, все его сделки и скриншоты будут удалены навсегда без возможности восстановления.
The account, its trades and screenshots were permanently deleted.|Счёт, его сделки и скриншоты удалены навсегда.
Restore an account or permanently delete its records.|Восстановите счёт или удалите его записи навсегда.
No deleted accounts.|Нет удалённых счетов.
Time format|Формат времени
24-hour|24-часовой
12-hour (AM/PM)|12-часовой (AM/PM)
12-hour format|12-часовой формат
AM or PM|AM или PM
Close|Закрыть
Close the form? Unsaved changes will be lost.|Закрыть форму? Несохранённые изменения будут потеряны.
Select at least one emotion.|Выберите хотя бы одну эмоцию.
Trade and screenshots saved.|Сделка и скриншоты сохранены.
Trade saved, but screenshots could not be fully updated. Press Save again.|Сделка сохранена, но не все скриншоты обновлены. Нажмите «Сохранить» ещё раз.
{v0} — {v1}: delete this trade and its screenshots?|{v0} — {v1}: удалить сделку и её скриншоты?
Trade deleted.|Сделка удалена.
Settings saved.|Настройки сохранены.
Your daily plan has unsaved changes. Switch to another day?|В плане дня есть несохранённые изменения. Перейти к другому дню?
Daily goals saved.|Цели дня сохранены.
Some photos could not be added. Use PNG, JPG or WebP, up to 8 MB each.|Некоторые фото не добавлены. Используйте PNG, JPG или WebP размером до 8 МБ каждое.
Each trade can hold up to {v0} photos. Extra photos were not added.|К сделке можно добавить до {v0} фото. Лишние фото не добавлены.
Your strategy has unsaved changes. Leave this page?|В стратегии есть несохранённые изменения. Покинуть страницу?
Your strategy has unsaved changes. Return to the trade?|В стратегии есть несохранённые изменения. Вернуться к сделке?
Account deleted. You can restore it from Deleted Accounts.|Счёт удалён. Его можно восстановить в разделе удалённых счетов.
Account and its records restored.|Счёт и его записи восстановлены.
Account saved.|Счёт сохранён.
All records|Все записи
Last {v0} days|Последние {v0} дней
A good trade starts with a clear plan.|Хорошая сделка начинается с чёткого плана.
Your goal is to follow your plan; the results appear in the data.|Ваша цель — следовать плану; результаты отражаются в данных.
Patience works even when you are not trading.|Терпение приносит пользу, даже когда вы не торгуете.
Record the reason. Review the outcome. Repeat the good habit.|Запишите причину. Оцените результат. Закрепите полезную привычку.
One trade does not define your progress.|Одна сделка не определяет ваш прогресс.
Home|Главная
Trade journal|Журнал сделок
Calendar|Календарь
My strategies|Мои стратегии
Your private journal|Ваш личный журнал
Your records and results in one place.|Ваши записи и результаты в одном месте.
Time settings|Настройки времени
Private workspace|Личное пространство
Open achievements|Открыть достижения
View achievements and level|Достижения и уровень
Only for you|Только для вас
Loading journal…|Загрузка журнала…
Could not load the journal|Не удалось загрузить журнал
Try again|Повторить
Sign in with ChatGPT|Войти через ChatGPT
My journal|Мой журнал
Every day is part of your progress.|Каждый день — часть вашего прогресса.
Record your trade. Keep the context.|Запишите сделку. Сохраните контекст.
Results by day and month.|Результаты по дням и месяцам.
Your strategies, with your own conditions.|Ваши стратегии с вашими условиями.
Goals, experience and your progress.|Цели, опыт и ваш прогресс.
Find what works for you.|Найдите то, что работает для вас.
Add trade|Добавить сделку
Add account|Добавить счёт
Dismiss notification|Закрыть уведомление
new achievements unlocked.|новые достижения открыты.
View|Просмотр
Dismiss achievement notification|Закрыть уведомление о достижении
You have no active trading account|У вас нет активного торгового счёта
Add an account or restore a deleted account with its saved trades and photos.|Добавьте счёт или восстановите удалённый счёт с сохранёнными сделками и фото.
Restore account|Восстановить счёт
Period|Период
Trading calendar|Торговый календарь
Select a day to open its records|Выберите день, чтобы открыть записи
A closer look at your results|Подробный анализ результатов
Cumulative P&L · {v0}|Накопленный P&L · {v0}
Equity · {v0}|Капитал · {v0}
No trades in this period yet. Add your first record.|В этом периоде пока нет сделок. Добавьте первую запись.
6 metrics · normalized to 0–100|6 показателей · шкала 0–100
How is the score calculated?|Как рассчитывается оценка?
This indicative score averages six components. Win % and consistency are used directly. Profit factor and average win/loss reach 100 at 3; recovery factor at 5. Drawdown scores 100 at 0% and 0 at 20%. Without an opening balance, the drawdown score is 0. Infinity means there is no corresponding loss.|Ориентировочная оценка — среднее шести компонентов. Процент побед и стабильность используются напрямую. Профит-фактор и отношение средней прибыли к убытку достигают 100 при значении 3; фактор восстановления — при 5. Оценка просадки равна 100 при 0% и 0 при 20%. Без начального баланса оценка просадки равна 0. Бесконечность означает отсутствие соответствующего убытка.
Win rate: positive-P&L trades / all records. Consistency: profitable days / trading days. Partial is also one record; edit the same trade to record its final result.|Процент побед: прибыльные сделки / все записи. Стабильность: прибыльные дни / торговые дни. Частичная сделка также считается одной записью; для итогового результата отредактируйте её.
Daily goals and rules|Цели и правила дня
Daily plan date|Дата плана дня
My plan|Мой план
Your daily goal, risk limit and focus…|Цель дня, лимит риска и приоритет…
Unsaved changes|Несохранённые изменения
Plan saved|План сохранён
Saving…|Сохранение…
Save plan|Сохранить план
Recent trades|Последние сделки
View all|Показать все
Search trades|Поиск сделок
Symbol, setup, emotion…|Инструмент, сетап, эмоция…
Result filter|Фильтр результата
All results|Все результаты
records|записей
Date / time|Дата / время
Symbol|Инструмент
Result|Результат
Setup / emotion|Сетап / эмоция
Screenshot|Скриншот
(+1 day)|(+1 день)
Edit {v0} trade|Редактировать сделку {v0}
Delete {v0} trade|Удалить сделку {v0}
No trades match these filters.|Нет сделок по выбранным фильтрам.
You have not recorded any trades yet.|Вы ещё не записали ни одной сделки.
Data is saved to your private account.|Данные сохраняются в вашей личной учётной записи.
{v0} trades · {v1}|{v0} сделок · {v1}
No records for this day yet.|За этот день пока нет записей.
Edit trade|Редактировать сделку
New trade|Новая сделка
Record the outcome and context for your next review.|Запишите результат и контекст для следующего анализа.
Trading account|Торговый счёт
Trade symbol|Торговый инструмент
Other symbol|Другой инструмент
Enter symbol|Введите инструмент
Profit + / loss −|Прибыль + / убыток −
After commissions. Enter losses as negative amounts.|После комиссий. Указывайте убытки отрицательными числами.
e.g. 100|например, 100
P&L ÷ Risk · realized result|P&L ÷ риск · фактический результат
Trade date|Дата сделки
Time:|Время:
. An exit time before the entry time is treated as the following day.|. Если время выхода раньше времени входа, выход относится к следующему дню.
My strategy|Моя стратегия
Create / manage|Создать / управлять
conditions|условий
No strategy yet. Create one with your own name and conditions.|Стратегий пока нет. Создайте свою с названием и условиями.
Create my strategy|Создать мою стратегию
Historical strategy:|Сохранённая стратегия:
Remove|Убрать
· conditions|· условий
This strategy has no conditions yet.|В этой стратегии пока нет условий.
conditions met|условий выполнено
Previously recorded setup:|Ранее записанный сетап:
Emotions at entry|Эмоции при входе
Select one or more emotions.|Выберите одну или несколько эмоций.
Why did you enter? What would you do differently?|Почему вы вошли? Что сделали бы иначе?
Changes will be applied when you save.|Изменения применятся после сохранения.
This trade will be added to your private journal.|Эта сделка будет добавлена в ваш личный журнал.
Cancel|Отмена
Save trade|Сохранить сделку
Strategy:|Стратегия:
Emotions:|Эмоции:
No notes.|Нет заметок.
Delete|Удалить
Create your own plan and return to recording your trade.|Создайте свой план и вернитесь к записи сделки.
Return to trade|Вернуться к сделке
Edit account|Редактировать счёт
New trading account|Новый торговый счёт
Separate balance, trades and statistics for each account.|Отдельные баланс, сделки и статистика для каждого счёта.
Delete account|Удалить счёт
will be removed from active accounts. Its trades and photos will be preserved, and you can restore the account.|будет убран из активных счетов. Сделки и фото сохранятся; счёт можно восстановить.
trade|сделка
Deleting…|Удаление…
Deleted accounts|Удалённые счета
Restore an account with all its trades and screenshots.|Восстановите счёт со всеми сделками и скриншотами.
Restore|Восстановить
Your trade times are recorded in the selected timezone.|Время сделок записывается в выбранном часовом поясе.
Save|Сохранить
Group|Группа
Trades|Сделки
Analysis will appear after your first trades.|Анализ появится после первых сделок.
No opening balance|Нет начального баланса
Expand trading accounts|Развернуть торговые счета
Select account|Выбрать счёт
Add / restore account|Добавить / восстановить счёт
Loading…|Загрузка…
Choose a trading account|Выберите торговый счёт
Selected|Выбран
Delete {v0} account|Удалить счёт {v0}
Edit selected account|Редактировать выбранный счёт
Deleted accounts (|Удалённые счета (
Today|Сегодня
Selected:|Выбрано:
Hour|Часы
Minute|Минуты
24-hour format|24-часовой формат
Done|Готово
{v0}: view levels and ranks|{v0}: уровни и звания
Trader levels and ranks|Уровни и звания трейдера
Every achievement adds experience. Your total XP unlocks new levels.|Каждое достижение добавляет опыт. Общий XP открывает новые уровни.
Ranks and levels list|Список званий и уровней
Your rank|Ваше звание
XP minimum|Минимум XP
XP required to unlock each level|XP для открытия каждого уровня
Total experience|Общий опыт
Level|Уровень
Rank|Звание
Required XP|Требуется XP
Current|Текущий
You can earn a total of|Всего можно получить
XP from the current achievements. The table shows the total XP required for each level.|XP за текущие достижения. В таблице указан общий XP для каждого уровня.
Record, review and build experience.|Записывайте, анализируйте и накапливайте опыт.
Checking…|Проверка…
Check progress|Проверить прогресс
Retry|Повторить
Loading achievements…|Загрузка достижений…
Press Check progress to load achievements.|Нажмите «Проверить прогресс», чтобы загрузить достижения.
To next level|До следующего уровня
Progress to next level|Прогресс до следующего уровня
Trade records|Записи сделок
Best streak · days|Лучшая серия · дней
All daily rules completed|Все правила дня выполнены
Achievements unlocked|Достижения открыты
Next goal ·|Следующая цель ·
Your saved achievements · progress across all accounts|Ваши достижения · прогресс по всем счетам
Completed|Выполнено
All|Все
Achievement status|Статус достижения
All statuses|Все статусы
Earned|Получено
Goals|Цели
Earned on|Получено
Work on this goal|Перейти к цели
No achievements match this filter yet.|Пока нет достижений по этому фильтру.
Each achievement awards XP once. Earned XP remains after editing records or deleting accounts. Streaks count consecutive calendar days, including saved daily plans.|Каждое достижение даёт XP один раз. Полученный XP сохраняется после редактирования записей и удаления счетов. Серии учитывают последовательные календарные дни, включая сохранённые планы дня.
Your strategy has unsaved changes. Continue?|В стратегии есть несохранённые изменения. Продолжить?
A condition can have up to 100 characters.|Условие может содержать до 100 символов.
This condition is already added.|Это условие уже добавлено.
You can add up to 16 conditions.|Можно добавить до 16 условий.
Delete this strategy? Its plan and results will remain in previously recorded trades.|Удалить стратегию? Её план и результаты останутся в ранее записанных сделках.
New strategy|Новая стратегия
Create your first strategy. You choose its name and every condition.|Создайте первую стратегию. Название и все условия выбираете вы.
Edit strategy|Редактировать стратегию
A clear plan to check before each entry.|Чёткий план для проверки перед каждым входом.
Strategy name|Название стратегии
e.g. My London setup|например, Мой лондонский сетап
Description|Описание
Optional|Необязательно
When and why do you use this strategy?|Когда и почему вы используете эту стратегию?
Pre-entry checklist|Чек-лист перед входом
These conditions will be available as checkboxes in your trade form.|Эти условия можно будет отметить в форме сделки.
New strategy condition|Новое условие стратегии
Write your own condition…|Напишите своё условие…
Add|Добавить
Condition {v0}|Условие {v0}
Delete condition {v0}|Удалить условие {v0}
Add your own rules, or save just the strategy name.|Добавьте свои правила или сохраните только название стратегии.
Strategy saved.|Стратегия сохранена.
Save changes|Сохранить изменения
Create strategy|Создать стратегию
Account type|Тип счёта
Account name|Название счёта
e.g. Lucid — Funded|например, Lucid — Funded
Currency|Валюта
Currency must match the existing trades.|Валюта должна совпадать с валютой имеющихся сделок.
Opening balance|Начальный баланс
e.g. 10000|например, 10000
Your account balance when starting this journal.|Баланс счёта на момент начала ведения журнала.
Goal, account size, details…|Цель, размер счёта, детали…
My account|Мой счёт
Each account gets a separate journal. Trades and statistics reflect your selected account.|Для каждого счёта есть отдельный журнал. Сделки и статистика относятся к выбранному счёту.
Create account|Создать аккаунт
No opening balance set|Начальный баланс не указан
{v0}{v1}% return for this period|{v0}{v1}% доходности за период
{v0} wins · {v1} losses · {v2} breakeven|{v0} прибыльных · {v1} убыточных · {v2} безубыточных
{v0} trading days|{v0} торговых дней
Average of {v0} winning trades|Среднее по {v0} прибыльным сделкам
Average of {v0} losing trades|Среднее по {v0} убыточным сделкам
Gross profit ÷ gross loss|Валовая прибыль ÷ валовой убыток
Average net result per trade|Средний чистый результат на сделку
Daily · {v0} days · not annualized|Дневной · {v0} дней · без пересчёта на год
No records yet|Записей пока нет
No winning trades yet|Прибыльных сделок пока нет
Set opening balance|Указать начальный баланс
Risk and trade quality|Риск и качество сделок
Open record|Открыть запись
Records in the selected period|Рекорды выбранного периода
{v0} trades · {v1}% Win|{v0} сделок · {v1}% прибыльных
Which weekdays work best for you?|Какие дни недели наиболее прибыльны для вас?
Weekday performance chart; exact values are in the table below|График по дням недели; точные значения в таблице ниже
Weekday|День недели
No records|Нет записей
Losing|Убыточный
Profitable|Прибыльный
Breakeven|Безубыток
Highest total P&L:|Максимальный суммарный P&L:
Cumulative P&L|Накопленный P&L
Account equity|Капитал счёта
Set a balance to show percentage|Укажите баланс для расчёта процентов
Profitable days / trading days|Прибыльные дни / торговые дни
How metrics are calculated|Как рассчитываются показатели
P&L sums recorded net results. Win Rate = positive-P&L trades / all trades. A Partial result counts as one record; edit the same trade for its final outcome.|P&L — сумма записанных чистых результатов. Процент побед = прибыльные сделки / все сделки. Частичный результат считается одной записью; отредактируйте эту сделку для итогового результата.
Expectancy = Total P&L / Total Trades. Smallest Win includes only positive results. Best Week groups Monday through Sunday. All records use only trades in the selected period.|Ожидание = общий P&L / число сделок. Минимальная прибыль учитывает только положительные результаты. Лучшая неделя — с понедельника по воскресенье. Все рекорды учитывают только сделки выбранного периода.
Sharpe Ratio: each calendar day's closed-trade P&L is divided by that day's opening equity. Average daily return is divided by its sample standard deviation (n−1). Non-trading days have zero P&L; the risk-free rate is 0%. The ratio is daily and not annualized. Positive equity and at least two days with trades are required. Deposits, withdrawals and open positions are not tracked in this journal.|Коэффициент Шарпа: P&L закрытых сделок каждого календарного дня делится на капитал в начале дня. Средняя дневная доходность делится на выборочное стандартное отклонение (n−1). В дни без сделок P&L равен нулю; безрисковая ставка — 0%. Коэффициент дневной, без пересчёта на год. Нужны положительный капитал и минимум два дня со сделками. Пополнения, снятия и открытые позиции в журнале не учитываются.
Without losses, Profit Factor / Avg Win-Loss may be infinite. Missing denominators or required data are shown as —. Trades with multiple emotions appear in each corresponding emotion group.|При отсутствии убытков профит-фактор и отношение средней прибыли к убытку могут быть бесконечными. При отсутствии данных или знаменателя показано —. Сделки с несколькими эмоциями учитываются в каждой соответствующей группе.
No records in this period yet.|В этом периоде пока нет записей.
Previous month|Предыдущий месяц
Next month|Следующий месяц
Sun|Вс
Mon|Пн
Tue|Вт
Wed|Ср
Thu|Чт
Fri|Пт
Sat|Сб
Open a new record|Открыть новую запись
Loading photo…|Загрузка фото…
No image on the clipboard. Copy a screenshot and press Ctrl+V.|В буфере обмена нет изображения. Скопируйте скриншот и нажмите Ctrl+V.
Could not read the clipboard. Press Ctrl+V / ⌘V in the form.|Не удалось прочитать буфер обмена. Нажмите Ctrl+V / ⌘V в форме.
Copy an image and press Ctrl+V / ⌘V in this form. You can also select several files at once. PNG, JPG, WebP · up to 8 MB each.|Скопируйте изображение и нажмите Ctrl+V / ⌘V в форме. Можно выбрать несколько файлов сразу. PNG, JPG, WebP · до 8 МБ каждый.
Stage for new photos|Этап для новых фото
Paste|Вставить
Choose photos|Выбрать фото
Upload multiple screenshots|Загрузить несколько скриншотов
Remove {v0} photo|Убрать фото {v0}
· new|· новое
Paste your first screenshot|Вставьте первый скриншот
Screenshots ·|Скриншоты ·
Full size|Полный размер
No screenshots|Нет скриншотов
Switch to dark mode|Включить тёмную тему
Switch to light mode|Включить светлую тему
First step|Первый шаг
Record your first trade.|Запишите первую сделку.
A habit begins|Начало привычки
Save 5 trade records.|Сохраните 5 сделок.
The power of data|Сила данных
Collect 10 trade records.|Запишите 10 сделок.
My history|Моя история
Collect 25 trade records.|Запишите 25 сделок.
Your own archive|Свой архив
Save 50 trade records.|Сохраните 50 сделок.
Collect 100 trade records.|Запишите 100 сделок.
The reason behind the result|Причина результата
Add a note of at least 20 characters to one trade.|Добавьте заметку длиной минимум 20 символов к одной сделке.
Observant analyst|Внимательный аналитик
Add notes of at least 20 characters to 5 trades.|Добавьте заметки длиной минимум 20 символов к 5 сделкам.
A collection of lessons|Коллекция уроков
Describe your observations in 20 trade records.|Опишите наблюдения в 20 сделках.
Deep analysis|Глубокий анализ
Write a note of at least 150 characters on one trade.|Напишите заметку длиной минимум 150 символов к одной сделке.
First frame|Первый кадр
Add a screenshot to one trade.|Добавьте скриншот к одной сделке.
Visual journal|Визуальный журнал
Add screenshots to 5 trades.|Добавьте скриншоты к 5 сделкам.
Chart archive|Архив графиков
Save visual context for 20 trades.|Сохраните визуальный контекст для 20 сделок.
Before and after|До и после
Add before-entry and after-exit photos to one trade.|Добавьте фото до входа и после выхода к одной сделке.
The full picture|Полная картина
Save screenshots of both stages for 5 trades.|Сохраните скриншоты обоих этапов для 5 сделок.
My first plan|Мой первый план
Create your own strategy with at least one condition.|Создайте стратегию хотя бы с одним условием.
Create 3 strategies with your own conditions.|Создайте 3 стратегии со своими условиями.
A plan in action|План в действии
Assign your own strategy to one trade.|Выберите свою стратегию для одной сделки.
Committed to the plan|Верность плану
Record 5 trades with a selected strategy.|Запишите 5 сделок с выбранной стратегией.
Every condition|Все условия
Complete every condition of the selected strategy on one trade.|Выполните все условия выбранной стратегии в одной сделке.
Practicing discipline|Практика дисциплины
Complete the full strategy checklist on 5 trades.|Выполните полный чек-лист стратегии в 5 сделках.
Recognizing emotions|Распознавание эмоций
Select at least two emotions and add a 20-character note on one trade.|Отметьте минимум две эмоции и добавьте заметку из 20 символов к одной сделке.
Select at least two emotions and add a 20-character note on 10 trades.|Отметьте минимум две эмоции и добавьте заметку из 20 символов к 10 сделкам.
The day starts with a goal|День начинается с цели
Save a daily plan of at least 20 characters.|Сохраните план дня длиной минимум 20 символов.
A map of goals|Карта целей
Save plans for 5 different days.|Сохраните планы для 5 разных дней.
From intention to habit|От намерения к привычке
Create plans for 20 different days.|Создайте планы для 20 разных дней.
Daily rules followed|Правила дня соблюдены
Check every rule in one saved daily plan.|Отметьте все правила в одном сохранённом плане дня.
Check every rule in plans for 5 different days.|Отметьте все правила в планах для 5 разных дней.
Finding your rhythm|В поисках ритма
Save a trade or daily plan on 3 consecutive calendar days.|Сохраните сделку или план дня 3 календарных дня подряд.
One week of commitment|Неделя постоянства
Fill in your journal or daily plan on 7 consecutive calendar days.|Заполняйте журнал или план дня 7 календарных дней подряд.
Save a record or plan on 30 consecutive calendar days.|Сохраняйте запись или план 30 календарных дней подряд.
30 days of experience|30 дней опыта
Fill in your journal on 30 different days; they need not be consecutive.|Заполните журнал в 30 разных дней; они не обязаны идти подряд.
Analysis library|Библиотека анализа
Add observations of at least 20 characters to 50 trades.|Добавьте наблюдения длиной минимум 20 символов к 50 сделкам.
A seeker of details|Исследователь деталей
Write at least 150 characters of analysis on 10 trades.|Напишите анализ длиной минимум 150 символов для 10 сделок.
Research master|Мастер исследования
Add analysis of at least 150 characters to 25 trades.|Добавьте анализ длиной минимум 150 символов к 25 сделкам.
Chart collector|Коллекционер графиков
Save screenshots on 50 trades.|Сохраните скриншоты для 50 сделок.
From chart to insight|От графика к пониманию
Save before-entry and after-exit photos on 20 trades.|Сохраните фото до входа и после выхода для 20 сделок.
The everyday plan|Ежедневный план
Save 20 trades with your own strategy.|Сохраните 20 сделок со своей стратегией.
Assign your own strategy to 50 trades.|Выберите свою стратегию для 50 сделок.
Committed to the process|Верность процессу
Complete every strategy condition on 20 trades.|Выполните все условия стратегии в 20 сделках.
Inner observation|Внутреннее наблюдение
Select at least two emotions and add a 20-character note on 5 trades.|Отметьте минимум две эмоции и добавьте заметку из 20 символов к 5 сделкам.
A map of emotions|Карта эмоций
Select at least two emotions and add a 20-character note on 25 trades.|Отметьте минимум две эмоции и добавьте заметку из 20 символов к 25 сделкам.
The goal becomes a habit|Цель становится привычкой
Save a plan of at least 20 characters for 50 different days.|Сохраните план длиной минимум 20 символов для 50 разных дней.
Guardian of the rules|Хранитель правил
Check every rule in plans for 20 different days.|Отметьте все правила в планах для 20 разных дней.
A two-week rhythm|Двухнедельный ритм
Save a trade or daily plan on 14 consecutive calendar days.|Сохраняйте сделку или план дня 14 календарных дней подряд.
Steady progress|Устойчивый прогресс
Fill in your journal or daily plan on 60 different days.|Заполните журнал или план дня в 60 разных дней.
The 90-day journey|Путь длиной 90 дней
Fill in your journal or daily plan on 90 different days.|Заполните журнал или план дня в 90 разных дней.
A trade's complete story|Полная история сделки
Add photos of both stages, 150 characters of analysis, at least two emotions and a completed strategy checklist to one trade.|Добавьте к одной сделке фото обоих этапов, анализ из 150 символов, минимум две эмоции и полностью выполненный чек-лист стратегии.
Journal|Журнал
Reviews and photos|Анализ и фото
Strategy|Стратегия
Psychology|Психология
Daily goals|Цели дня
Consistency|Стабильность
Recruit|Новобранец
Start your trading journal.|Начните вести торговый журнал.
Private|Рядовой
Your first records build your experience.|Первые записи формируют ваш опыт.
Corporal|Капрал
Save the context alongside your results.|Сохраняйте контекст вместе с результатами.
Sergeant|Сержант
Planning and observation become a habit.|Планирование и наблюдение становятся привычкой.
Staff Sergeant|Старший сержант
Your journal is part of your daily process.|Журнал — часть вашего ежедневного процесса.
Second Lieutenant|Младший лейтенант
Review your entry, risk and emotions.|Анализируйте вход, риск и эмоции.
Lieutenant|Лейтенант
Build a consistent history of your setups.|Создавайте последовательную историю сетапов.
Captain|Капитан
Build your own plans and a habit of analysis.|Создавайте свои планы и привычку анализировать.
Major|Майор
Create a rich archive of saved observations.|Создайте обширный архив наблюдений.
Lieutenant Colonel|Подполковник
Keep detailed reviews and lessons learned.|Сохраняйте подробный анализ и извлечённые уроки.
Colonel|Полковник
You have built a substantial archive of experience.|Вы создали значительный архив опыта.
Invalid date|Некорректная дата
Checklist conditions must not be duplicated.|Условия чек-листа не должны повторяться.
Win P&L must be positive, Loss negative, and Breakeven zero.|P&L прибыльной сделки должен быть положительным, убыточной — отрицательным, безубыточной — нулевым.
Avoid trading on emotions|Не торговать на эмоциях
Keep to my planned risk|Соблюдать запланированный риск
Wait for my setup|Дождаться своего сетапа
No setup|Без сетапа
Discipline|Дисциплина
Calm|Спокойствие
Patience|Терпение
Anxiety|Тревога
Greed|Жадность
Revenge|Желание отыграться
Before entry|До входа
After exit|После выхода
Additional|Дополнительно
No strategy|Без стратегии
Monday|Понедельник
Tuesday|Вторник
Wednesday|Среда
Thursday|Четверг
Friday|Пятница
Saturday|Суббота
Sunday|Воскресенье
Set a positive opening balance.|Укажите положительный начальный баланс.
At least two calendar days are required.|Нужно минимум два календарных дня.
At least two days with recorded trades are required.|Нужно минимум два дня с записанными сделками.
The balance reached zero or below during this period.|В этом периоде баланс достиг нуля или стал отрицательным.
The ending balance must be positive.|Конечный баланс должен быть положительным.
Daily returns have zero variability.|Дневная доходность не меняется.
This account is deleted. Restore it first.|Этот счёт удалён. Сначала восстановите его.
The currency of an account with trades cannot be changed. Create another account.|Нельзя изменить валюту счёта со сделками. Создайте другой счёт.
This account changed in another window. Refresh the page.|Счёт изменён в другом окне. Обновите страницу.
This daily plan changed in another window. Refresh the page.|План дня изменён в другом окне. Обновите страницу.
Main account|Основной счёт
Screenshot size must not exceed 8 MB.|Размер скриншота не должен превышать 8 МБ.
Upload your screenshot as a file.|Загрузите скриншот как файл.
Select a screenshot and its stage.|Выберите скриншот и его этап.
Trade not found.|Сделка не найдена.
This photo ID is already in use.|Этот идентификатор фото уже используется.
Screenshot size must be between 1 byte and 8 MB.|Размер скриншота должен быть от 1 байта до 8 МБ.
Only PNG, JPG or WebP screenshots are supported.|Поддерживаются только скриншоты PNG, JPG и WebP.
Settings changed in another window. Refresh the page.|Настройки изменены в другом окне. Обновите страницу.
This strategy changed in another window. Refresh the page.|Стратегия изменена в другом окне. Обновите страницу.
Account not found. Restore it or select an active account.|Счёт не найден. Восстановите его или выберите активный.
Strategy not found. Select one of your own strategies.|Стратегия не найдена. Выберите свою стратегию.
Select only conditions from the chosen strategy.|Выбирайте только условия выбранной стратегии.
This record changed in another window or is already saved. Refresh the journal.|Запись изменена в другом окне или уже сохранена. Обновите журнал.
Invalid account revision.|Некорректная версия счёта.
Account not found or changed in another window. Refresh the page.|Счёт не найден или изменён в другом окне. Обновите страницу.
Screenshot not found.|Скриншот не найден.
This file is temporarily unavailable.|Этот файл временно недоступен.
Strategy not found or changed. Refresh the page.|Стратегия не найдена или изменена. Обновите страницу.
Language|Язык
Interface language|Язык интерфейса
ICT checklist ideas|Идеи для чек-листа ICT
Choose conditions that fit your model|Выберите условия для вашей модели
Select a condition to add it to your checklist. You can edit or remove its text.|Выберите условие, чтобы добавить его в чек-лист. Текст можно изменить или удалить.
ICT condition category|Категория условий ICT
Added|Добавлено
You choose the conditions · up to 16|Вы выбираете условия · до 16
Live|Реальный
Demo|Демо
Backtesting|Бэктестинг
Funded|Финансируемый
Your first trade — the first step toward progress.|Первая сделка — первый шаг к прогрессу.
Request failed. Please try again.|Запрос не выполнен. Повторите попытку.
Set opening equity|Указать начальный капитал
% in this period|% за этот период
Ratio {v0} : 1|Отношение {v0} : 1
Market Explorer|Исследователь рынка
Setup Observer|Наблюдатель сетапов
Journal Analyst|Аналитик журнала
Plan Practitioner|Практик плана
Disciplined Trader|Дисциплинированный трейдер
Risk Manager|Риск-менеджер
Setup Specialist|Специалист по сетапам
Strategy Architect|Архитектор стратегии
Systematic Trader|Системный трейдер
Process Mentor|Наставник процесса
Journal Master|Мастер журнала
Achievements|Достижения
Inner Space|Внутреннее пространство
Progress over time|Прогресс во времени
YOUR WORKSPACE|ВАШЕ ПРОСТРАНСТВО
Dashboard|Главная панель
TOOLS|ИНСТРУМЕНТЫ
Statistics|Статистика
Trading Dashboard|Торговая панель
Trade Journal|Журнал сделок
Trading Calendar|Торговый календарь
Trading Playbook|Торговый план
Statistics & Analytics|Статистика и аналитика
TOTAL P&L|ОБЩИЙ P&L
WIN RATE|ПРОЦЕНТ ПОБЕД
TOTAL TRADES|ВСЕГО СДЕЛОК
AVG WIN / LOSS|СР. ПРИБЫЛЬ / УБЫТОК
YOUR DAILY EDGE|ВАШ ПЛАН НА ДЕНЬ
Performance Overview|Обзор результатов
Performance Score|Оценка результатов
YOUR PERFORMANCE SCORE|ВАША ОЦЕНКА РЕЗУЛЬТАТОВ
Daily Note|Заметка дня
Qty|Кол-во
Risk / R|Риск / R
Trade Basics|Основные данные сделки
Trade Type|Направление сделки
Buy|Покупка
Sell|Продажа
Win|Прибыль
Loss|Убыток
Partial|Частичная
Quantity|Количество
Net P&L ·|Чистый P&L ·
Risk ·|Риск ·
Risk|Риск
Realized R:R|Фактический R:R
Trading Session|Торговая сессия
Entry Time|Время входа
Exit Time|Время выхода
Strategy & Mindset|Стратегия и психология
Trade Notes|Заметки к сделке
Timezone|Часовой пояс
Win %|Прибыльных %
TRADING ACCOUNTS|ТОРГОВЫЕ СЧЕТА
YOUR JOURNEY|ВАШ ПУТЬ
Total XP|Всего XP
Trophy Wall|Коллекция достижений
YOUR TRADING PLAYBOOK|ВАШ ТОРГОВЫЙ ПЛАН
Advanced Analytics|Расширенная аналитика
Best Performance|Лучшие результаты
Day of the Week Performance|Результаты по дням недели
Avg / Trade|Среднее / сделка
Performance Curve|График результатов
Risk & Consistency|Риск и стабильность
Max Drawdown|Максимальная просадка
Avg Win / Loss|Ср. прибыль / убыток
Recovery Factor|Фактор восстановления
Expectancy · R|Ожидание · R
Session Performance|Результаты по сессиям
Psychology & Mindset|Психология и настрой
All Time|Всё время
Equity|Капитал
Daily P&L|Дневной P&L
Win rate|Процент побед
Win Rate|Процент побед
Total P&L|Общий P&L
Total Trades|Всего сделок
Avg Win|Средняя прибыль
Avg Loss|Средний убыток
Profit Factor|Профит-фактор
Expectancy|Ожидание на сделку
Sharpe Ratio|Коэффициент Шарпа
Best Trade|Лучшая сделка
Smallest Win|Минимальная прибыль
Best Day|Лучший день
Best Week|Лучшая неделя
Best Month|Лучший месяц
Best Year|Лучший год
Best Session|Лучшая сессия
Score|Оценка
Profit factor|Профит-фактор
Avg win/loss|Ср. прибыль / убыток
Recovery|Восстановление
Drawdown|Просадка
Asia|Азия
London|Лондон
New York|Нью-Йорк
London / New York|Лондон / Нью-Йорк
Other|Другое
Paper Trading|Симуляция торговли
Live account|Реальный счёт
Practice account|Учебный счёт
Historical testing|Тестирование на истории
Funded account|Финансируемый счёт
Simulated trading|Симуляция торговли
Bronze|Бронза
Silver|Серебро
Gold|Золото
Platinum|Платина
TradingView Screenshots|Скриншоты TradingView
WIN|ПРИБЫЛЬ
Century Club|Клуб ста записей
Playbook Builder|Создатель стратегий
Mindset Tracker|Наблюдатель эмоций
Rule Keeper|Хранитель правил
30-Day Streak|Серия из 30 дней
All accounts|Все счета
Portfolio|Портфель
Combined performance across active accounts|Общие результаты активных счетов
Account comparison|Сравнение счетов
Select an account to explore its results|Выберите счёт для просмотра результатов
Return|Доходность
Each account keeps its own currency. Archived accounts are excluded from the portfolio.|Каждый счёт сохраняет свою валюту. Архивные счета не входят в портфель.
Amounts are grouped by currency; no exchange rates are assumed.|Суммы сгруппированы по валюте; конвертация не применяется.
Opening balances are missing for accounts with trades. Return percentages and Sharpe need these balances.|У некоторых счетов со сделками не указан начальный баланс. Он нужен для доходности и коэффициента Шарпа.
Set balances|Указать балансы
Challenge|Челлендж
Evaluation account|Оценочный счёт
Mindset, reflection and a moment to pause.|Настрой, размышления и время для паузы.
Your inner space|Ваше внутреннее пространство
Pause, notice your mindset and write down what matters before your next trade.|Остановитесь, оцените свой настрой и запишите важное перед следующей сделкой.
Inner Space sections|Разделы внутреннего пространства
Mood check|Оценка настроения
Reflection|Размышления
Breathing|Дыхание
Insights|Наблюдения
Check-in date|Дата записи
Reload entries|Обновить записи
Loading your check-ins…|Загрузка записей…
How are you feeling today?|Как вы чувствуете себя сегодня?
There is no right answer. Choose what feels closest.|Правильного ответа нет. Выберите наиболее близкое состояние.
Low|Пониженное
A difficult day|Трудный день
Uneasy|Тревожно
Something feels off|Что-то беспокоит
Balanced|Сбалансированно
Steady and neutral|Стабильно и нейтрально
Positive|Позитивно
Feeling good|Хорошее самочувствие
Great|Отлично
Clear and energized|Ясность и энергия
What is your trading mindset?|Каков ваш торговый настрой?
Select all that describe you right now.|Отметьте всё, что описывает ваше состояние сейчас.
Confident|Уверенность
Focused|Сосредоточенность
Patient|Терпение
Anxious|Тревога
Revenge urge|Желание отыграться
Tired|Усталость
Energy|Энергия
One intention for your next session|Одна цель на следующую сессию
What will you focus on, regardless of the outcome?|На чём сосредоточитесь независимо от результата?
A moment to reflect|Время для размышлений
Your private reflection is separate from your trade notes.|Ваш личный дневник хранится отдельно от заметок к сделкам.
How did your session feel?|Как прошла ваша сессия?
What went well? When did emotion influence your decisions?|Что получилось? Когда эмоции повлияли на решения?
One lesson to carry forward|Один урок на будущее
Write one change you want to practice next time.|Запишите одно изменение, которое попробуете в следующий раз.
Take a quiet pause|Сделайте спокойную паузу
Six gentle cycles: inhale for 4 seconds, pause for 4, exhale for 6. Breathe comfortably; stop if uncomfortable.|Шесть спокойных циклов: вдох 4 секунды, пауза 4, выдох 6. Дышите комфортно; прекратите при дискомфорте.
Inhale|Вдох
Hold gently|Мягкая пауза
Exhale|Выдох
Complete|Завершено
Ready|Готовы?
seconds|секунд
Pause|Пауза
Start|Начать
Reset|Сбросить
Completed today|Выполнено сегодня
Saved check-ins|Сохранённые записи
Average mood|Среднее настроение
Breathing practices|Дыхательные практики
Your recurring mindsets|Ваши частые состояния
Save your first check-in to begin seeing patterns.|Сохраните первую запись, чтобы увидеть закономерности.
Check-in history|История записей
No mindset selected|Состояние не выбрано
Your check-in is up to date.|Запись актуальна.
Save check-in|Сохранить запись
Your check-in is saved.|Ваша запись сохранена.
Breathing practice completed. Save your check-in to keep it.|Дыхательная практика завершена. Сохраните запись, чтобы учесть её.
Discard unsaved Inner Space changes?|Отменить несохранённые изменения внутреннего пространства?
Inner Space changed in another window. Reload your entries.|Записи внутреннего пространства изменены в другом окне. Обновите их.
Daily, weekly and monthly results for your selected accounts|Дневные, недельные и месячные результаты выбранных счетов
Days|Дни
Weeks|Недели
Months|Месяцы
Years|Годы
Newer|Новее
Older|Старее
Achievements & Progress|Достижения и прогресс
Bias|Направление
Liquidity|Ликвидность
Entry|Вход
Timing|Время
Higher-timeframe bias identified (Daily / H4 / H1)|Направление старшего таймфрейма определено (Daily / H4 / H1)
Draw on Liquidity — target liquidity marked|Draw on Liquidity — целевая ликвидность отмечена
Dealing range and equilibrium (50%) marked|Торговый диапазон и равновесие (50%) отмечены
Entry matches my premium / discount plan|Вход соответствует моему плану Premium / Discount
Previous-day high / low (PDH / PDL) marked|Максимум и минимум прошлого дня (PDH / PDL) отмечены
Previous-week high / low (PWH / PWL) marked|Максимум и минимум прошлой недели (PWH / PWL) отмечены
Equal highs / equal lows and BSL / SSL marked|Равные максимумы / минимумы и BSL / SSL отмечены
Asian / London session high / low marked|Максимум и минимум азиатской / лондонской сессии отмечены
Planned liquidity sweep observed|Запланированный захват ликвидности произошёл
Displacement observed in my setup direction|Displacement в направлении моего сетапа подтверждён
Market Structure Shift (MSS) confirmed|Смена структуры рынка (MSS) подтверждена
Fair Value Gap (FVG) marked|Fair Value Gap (FVG) отмечен
Price returned to the planned FVG|Цена вернулась в запланированный FVG
Order block marked and aligned with my model|Order Block отмечен и соответствует моей модели
Breaker / mitigation block matches my setup|Breaker / Mitigation Block соответствует моему сетапу
Entry matches my OTE model|Вход соответствует моей модели OTE
SMT divergence checked on NQ / ES|SMT-дивергенция проверена на NQ / ES
Entry is within my planned killzone / session|Вход в пределах запланированной Killzone / сессии
Economic calendar and high-impact news checked|Экономический календарь и важные новости проверены
Session times and timezone checked|Время сессии и часовой пояс проверены
Stop loss and setup invalidation level defined|Стоп-лосс и уровень отмены сетапа определены
Position size and risk are within my daily limit|Размер позиции и риск в пределах дневного лимита
Target and planned R:R defined|Цель и запланированный R:R определены
Entry follows my plan — I am not chasing price|Вход по плану — я не гонюсь за ценой
Open trade record|Открыть запись сделки
calculation|расчёт
open trade record|открыть запись сделки
Wins|Прибыльные
Losses|Убыточные
Win / Loss Analysis|Анализ прибыли / убытков
Outcomes in the selected period|Результаты выбранного периода
trades|сделок
Select an outcome to review its trades. Win rate includes breakeven trades in the total.|Выберите результат для просмотра сделок. Безубыточные сделки входят в общее число при расчёте процента побед.
Date range|Диапазон дат
Select end date|Выберите конечную дату
Click the first day, then the last day.|Нажмите на первый день, затем на последний.
This week|Текущая неделя
Next week|Следующая неделя
This month|Текущий месяц
Next month|Следующий месяц
Apply|Применить
Open trade|Открыть сделку
View day news|Новости дня
Choose what clicking a day opens|Выберите действие при нажатии на день
Saved week|Сохранённая неделя
events|событий
Impact|Важность
Event|Событие
Actual|Факт
Forecast|Прогноз
Previous|Предыдущее
All day|Весь день
Medium|Средняя
High|Высокая
Holiday|Выходной
Unknown|Неизвестно
No events match your filters in the saved data.|В сохранённых данных нет событий по вашим фильтрам.
This week has not been received from the source. The thisweek feed does not provide next week in advance.|Данные за эту неделю ещё не получены. Файл thisweek не предоставляет следующую неделю заранее.
High impact|Высокая важность
Medium impact|Средняя важность
Low impact|Низкая важность
Unrated|Без оценки
Could not load profile.|Не удалось загрузить профиль.
Could not sign out. Please try again.|Не удалось выйти. Повторите попытку.
Sign in|Войти
Get started|Начать
My profile|Мой профиль
Profile|Профиль
Profile & subscription|Профиль и подписка
Import trades|Импорт сделок
Home page|Главная страница
Signing out…|Выход…
Sign out|Выйти
Main navigation|Главное меню
Features|Возможности
How it works|Как это работает
FAQ|Вопросы
YOUR TRADING, IN FOCUS|ВАША ТОРГОВЛЯ В ФОКУСЕ
Preview section|Раздел примера
Net P&L|Чистый P&L
Total trades|Всего сделок
Sample period|Пример периода
Cumulative performance|Накопленный результат
Illustrative equity curve|Пример кривой капитала
2 trades|2 сделки
No trades|Нет сделок
Your setup. Your rules.|Ваш сетап. Ваши правила.
An example checklist you can adapt to your own trading plan.|Пример чек-листа, который можно адаптировать к своему торговому плану.
Higher timeframe bias|Направление старшего таймфрейма
Liquidity sweep|Захват ликвидности
Market structure shift|Смена структуры рынка
Fair value gap|Fair Value Gap
Defined risk & invalidation|Определённый риск и уровень отмены
Performance analytics|Аналитика результатов
Custom ICT checklists|Ваши чек-листы ICT
Mindset & discipline|Психология и дисциплина
SEE THE WHOLE PICTURE|ПОЛНАЯ КАРТИНА
More than a record.|Больше, чем записи.
A better understanding of you.|Лучшее понимание своей торговли.
Connect the numbers with the decisions behind them.|Свяжите цифры с решениями, которые за ними стоят.
Know what is working|Узнайте, что работает
P&L, win rate, expectancy and profit factor. Review results by day, session and strategy.|P&L, процент побед, ожидание и профит-фактор. Анализируйте результаты по дням, сессиям и стратегиям.
Revisit every decision|Пересмотрите каждое решение
Save before-and-after screenshots, paste your charts and keep the context with each trade.|Сохраняйте скриншоты до и после сделки, вставляйте графики и сохраняйте контекст.
Trade your own playbook|Торгуйте по своему плану
Build your strategies and checklists. Use optional ICT suggestions to define exactly what you look for.|Создавайте стратегии и чек-листы. Используйте подсказки ICT, чтобы уточнить условия своего сетапа.
Understand your mindset|Поймите свои эмоции
Track your emotions, write a daily reflection and recognize the habits behind your decisions.|Отмечайте эмоции, подводите итоги дня и находите привычки, влияющие на решения.
A REPEATABLE ROUTINE|ПОСЛЕДОВАТЕЛЬНЫЙ ПРОЦЕСС
Record. Review. Refine.|Записывайте. Анализируйте. Улучшайте.
Capture the trade|Запишите сделку
Symbol, risk, result and the screenshots that tell the full story.|Инструмент, риск, результат и скриншоты для полной картины.
Find the patterns|Найдите закономерности
Compare your trading days, setups and emotions in one place.|Сравнивайте торговые дни, сетапы и эмоции в одном месте.
Plan your next session|Планируйте следующую сессию
Use your daily notes and checklist to stay focused on your process.|Используйте заметки дня и чек-лист, чтобы следовать своему процессу.
Before you begin|Перед началом
Where is my existing journal?|Где мой существующий журнал?
Choose “Open my journal” to access your dashboard, accounts and saved trades. Your existing records stay in your journal.|Нажмите «Открыть мой журнал» для доступа к панели, счетам и сохранённым сделкам. Ваши записи остаются в журнале.
Can I create my own strategies?|Можно создавать свои стратегии?
Yes. Create your own strategy and checklist, then select it when recording a trade. ICT suggestions are optional.|Да. Создайте стратегию и чек-лист, затем выбирайте её при записи сделки. Подсказки ICT необязательны.
Is registration available to everyone?|Регистрация доступна всем?
This is a private preview. Account registration and subscription checkout are in test mode; real payments are not enabled.|Это личная версия. Регистрация и оплата подписки работают в тестовом режиме; реальные платежи не включены.
MAKE EVERY REVIEW COUNT|УЧИТЕСЬ НА КАЖДОМ АНАЛИЗЕ
Your next insight starts here.|Ваше следующее открытие начинается здесь.
Open my journal|Открыть мой журнал
Built around your process.|Создано для вашего торгового процесса.
`;
const additional = `
Trading accounts|Торговые счета
Your recorded results, separately for every account.|Ваши записанные результаты отдельно для каждого счёта.
Recorded balance|Учётный баланс
Open account journal|Открыть журнал счёта
Recorded balance = opening balance + saved net P&L. Each account stays in its own currency.|Учётный баланс = начальный баланс + сохранённый чистый P&L. Каждый счёт остаётся в своей валюте.
Settings|Настройки
Billing|Подписка и платежи
Recent achievements|Последние достижения
Manage your profile and application preferences.|Управляйте профилем и настройками приложения.
Profile information|Информация профиля
Update your name and profile photo or logo.|Обновите имя и фото профиля или логотип.
Profile photo|Фото профиля
Change photo|Изменить фото
Remove photo|Удалить фото
Full name|Полное имя
Save name|Сохранить имя
Email is managed by your sign-in account.|Электронная почта связана с аккаунтом для входа.
Use PNG, JPG or WebP, up to 8 MB.|PNG, JPG или WebP · до 8 МБ.
Choose a photo file.|Выберите файл фотографии.
Photo not found.|Фото не найдено.
Profile changed in another window. Reload and try again.|Профиль изменён в другом окне. Обновите страницу и повторите.
Appearance|Оформление
Switch theme|Изменить тему
Manage your subscription and password in your account portal.|Управляйте подпиской и паролем в разделе аккаунта.
PRIVATE TEST MODE|ЛИЧНЫЙ ТЕСТОВЫЙ РЕЖИМ
Administrator|Администратор
Refresh|Обновить
Private preview. No real payments or automatic charges. Public registration is not enabled yet.|Личная тестовая версия. Реальных платежей и автоматических списаний нет. Публичная регистрация ещё не включена.
YOUR OWN TRADING SPACE|ВАШЕ ЛИЧНОЕ ТОРГОВОЕ ПРОСТРАНСТВО
A clearer view of your trading.|Более ясный взгляд на вашу торговлю.
Record your trades, understand your patterns and build a repeatable process.|Записывайте сделки, изучайте закономерности и создавайте последовательный процесс.
Private journal and screenshots|Личный журнал и скриншоты
Calendar and advanced statistics|Календарь и расширенная статистика
Mindset tracking and achievements|Отслеживание эмоций и достижения
/ month|/ месяц
trial days · test plan|пробных дней · тестовый план
Use test credentials. Email verification and password-reset emails are not connected in this private preview.|Используйте тестовые данные. В этой личной версии письма подтверждения почты и восстановления пароля ещё не подключены.
Return to my existing journal|Вернуться к моему журналу
Start your private journal|Создайте свой личный журнал
Welcome back|С возвращением
Name|Имя
Email|Электронная почта
Password|Пароль
At least 12 characters.|Минимум 12 символов.
Please wait…|Подождите…
Create test account|Создать тестовый аккаунт
MEMBERSHIP|ПОДПИСКА
Journal Pro|Journal Pro
Suspended|Приостановлено
Expired|Срок истёк
Trial|Пробный период
Ends after this period|Завершится в конце периода
Active|Активна
Access until|Доступ до
Test renewal is manual. No bank card is stored or charged.|Тестовое продление выполняется вручную. Банковская карта не сохраняется; списаний нет.
Test monthly payment|Проверить ежемесячный платёж
Keep subscription|Сохранить подписку
Cancel subscription|Отменить подписку
Your personal space|Ваше личное пространство
Your trades, strategies and screenshots belong only to this account.|Ваши сделки, стратегии и скриншоты принадлежат только этому аккаунту.
An expired subscription keeps your records. Renew your test plan to open the journal again.|При истечении подписки записи сохраняются. Продлите тестовый план, чтобы снова открыть журнал.
Test checkout|Тестовая оплата
NO REAL CHARGE|БЕЗ РЕАЛЬНОГО СПИСАНИЯ
A successful simulation starts one calendar month of access today. It replaces any remaining trial.|Успешная симуляция даёт месяц доступа с сегодняшнего дня и заменяет оставшийся пробный период.
I understand this is a test and no money will be charged.|Я понимаю, что это тест и деньги не будут списаны.
Simulate successful payment|Симулировать успешный платёж
Simulate failed payment|Симулировать неудачный платёж
Test payment history|История тестовых платежей
Date|Дата
Simulated amount|Тестовая сумма
Test succeeded|Тест успешен
Test failed|Тест неудачен
No test payments yet.|Тестовых платежей пока нет.
Change password|Изменить пароль
Current password|Текущий пароль
New password|Новый пароль
Save password|Сохранить пароль
Your test account is ready.|Ваш тестовый аккаунт готов.
You are signed in.|Вы вошли в аккаунт.
Signed out.|Вы вышли из аккаунта.
Cancellation removed.|Отмена подписки отменена.
Cancelled. Access remains until the end of your current period.|Подписка отменена. Доступ сохранится до конца текущего периода.
Test payment succeeded. Your monthly access is active.|Тестовый платёж успешен. Доступ на месяц активен.
Payment failure simulated. No access extension or charge was made.|Симулирован неудачный платёж. Доступ не продлён; списаний нет.
Password changed. Other sessions were signed out.|Пароль изменён. Другие сеансы завершены.
WORKSPACE OWNER|ВЛАДЕЛЕЦ ПРОСТРАНСТВА
Test registration|Тестовая регистрация
Members, test subscriptions and your monthly plan.|Пользователи, тестовые подписки и ваш месячный план.
This dashboard contains simulated payments only. Actual revenue is zero.|Здесь только симулированные платежи. Реальный доход равен нулю.
Test members|Тестовые пользователи
With active access|С активным доступом
Actual revenue|Реальный доход
Monthly test plan|Месячный тестовый план
New prices apply to future test purchases. Existing access periods stay unchanged.|Новые цены применяются к будущим тестовым покупкам. Текущие сроки доступа не меняются.
Monthly price · GEL|Цена за месяц · GEL
Trial days|Пробные дни
Members|Пользователи
Search members|Поиск пользователей
Search name or email|Имя или электронная почта
Showing up to 200 newest members. Personal journals are not displayed here.|Показано до 200 последних пользователей. Личные журналы здесь не отображаются.
Member|Пользователь
Status|Статус
Plan|План
Manage|Управление
Restore access|Восстановить доступ
Suspend|Приостановить
Suspend access for this test member?|Приостановить доступ этому тестовому пользователю?
No members found.|Пользователи не найдены.
Recent test payments|Последние тестовые платежи
Latest 100|Последние 100
Saved.|Сохранено.
This email is already registered. Sign in instead.|Эта почта уже зарегистрирована. Войдите в аккаунт.
Incorrect email or password.|Неверная почта или пароль.
Too many attempts. Try again in 15 minutes.|Слишком много попыток. Повторите через 15 минут.
Sign in to manage your membership.|Войдите для управления подпиской.
Incorrect current password.|Неверный текущий пароль.
This test account is suspended. Contact the administrator.|Этот тестовый аккаунт приостановлен. Свяжитесь с администратором.
Subscription unavailable.|Подписка недоступна.
Membership changed in another window. Refresh and try again.|Подписка изменена в другом окне. Обновите страницу и повторите.
Your paid test period is still active.|Ваш оплаченный тестовый период ещё активен.
Administrator access required.|Нужен доступ администратора.
Plan changed in another window. Refresh and try again.|План изменён в другом окне. Обновите страницу и повторите.
Member not found.|Пользователь не найден.
Create an account or sign in to your journal.|Создайте аккаунт или войдите в журнал.
XP|XP
→ Level|→ Уровень
news|новости
Economic events|Экономические события
more events|ещё событий
Click to view details|Нажмите для подробностей
Economic calendar|Экономический календарь
events matching your filters|событий по вашим фильтрам
No saved events match this day and your filters.|Нет сохранённых событий за этот день по выбранным фильтрам.
— means unavailable. Scheduled times may change.|— означает отсутствие данных. Время публикации может измениться.
Economic news|Экономические новости
Release times|Время публикаций
Refresh calendar|Обновить календарь
Download CSV|Скачать CSV
Currencies|Валюты
None|Ничего
Expected impact|Ожидаемая важность
By week|По неделям
Selected day|Выбранный день
Available dates|Доступные даты
Day|День
Search news|Поиск новостей
Search event…|Поиск события…
Selected period|Выбранный период
Some selected dates may not yet be archived. Check available periods below; missing data does not mean no events.|Некоторые выбранные даты ещё могут отсутствовать в архиве. Проверьте доступные периоды ниже; отсутствие данных не означает отсутствие событий.
Archived periods|Периоды в архиве
Source week (New York)|Неделя источника (Нью-Йорк)
Last fetched|Последняя загрузка
Update failed or data is old. Showing the last loaded schedule; confirm changes at the source.|Обновление не удалось или данные устарели. Показано последнее расписание; проверьте изменения у источника.
The news source is temporarily unavailable. Use the Forex Factory link above.|Источник новостей временно недоступен. Используйте ссылку Forex Factory выше.
Loading economic events…|Загрузка экономических событий…
Time|Время
No matching events in the saved periods. Dates not collected yet are unavailable.|Нет подходящих событий в сохранённых периодах. Ещё не собранные даты недоступны.
Forex Factory current-week feed. Received weeks are archived; requests are cached for up to an hour. Actual values may be unavailable; — is not zero. Holiday dates follow the provider.|Лента текущей недели Forex Factory. Полученные недели сохраняются; запросы кэшируются до часа. Фактические значения могут отсутствовать; — не означает ноль. Даты выходных берутся у поставщика.
Maximum file size: 200 KB.|Максимальный размер файла: 200 КБ.
Could not read the file.|Не удалось прочитать файл.
Back to my journal|Вернуться к журналу
Bring your trades together|Соберите свои сделки вместе
Review your file before adding anything to your journal.|Проверьте файл перед добавлением записей в журнал.
Automatic sync is not connected. Provider API access is required.|Автоматическая синхронизация не подключена. Нужен доступ к API поставщика.
Not connected|Не подключено
Import Performance CSV|Импорт Performance CSV
Supports the Tradovate Performance export. Maximum 500 rows / 200 KB.|Поддерживается экспорт Tradovate Performance. Максимум 500 строк / 200 КБ.
Destination account|Счёт назначения
Select an account|Выберите счёт
File time zone (UTC offset)|Часовой пояс файла (смещение UTC)
Select the offset used in this export|Выберите смещение времени этого экспорта
Use the export’s offset on its trade dates. Split files if the UTC offset changes with daylight saving.|Укажите смещение на даты сделок. Разделите файлы, если смещение UTC меняется при переходе на летнее время.
Choose your CSV file|Выберите файл CSV
File selection only — nothing is saved yet.|Это только выбор файла — ничего ещё не сохранено.
The file does not contain risk, commissions, emotion or strategy. Enter actual risk below; commission defaults to 0 and must be reviewed. Each matched fill row becomes one trade, including partial closes. Rithmic exports are not yet supported.|В файле нет риска, комиссий, эмоций и стратегии. Укажите фактический риск ниже; комиссия по умолчанию равна 0 и требует проверки. Каждая строка исполнения становится одной сделкой, включая частичные закрытия. Экспорты Rithmic пока не поддерживаются.
Import complete|Импорт завершён
Skipped (duplicate or unavailable account)|Пропущено (дубликат или недоступный счёт)
Review before saving|Проверьте перед сохранением
New records|Новые записи
Duplicates skipped|Дубликаты пропущены
New net P&L|Новый чистый P&L
Apply the same risk to all new rows (optional)|Применить одинаковый риск ко всем новым строкам (необязательно)
Trade|Сделка
Entry → exit|Вход → выход
Risk USD|Риск USD
Commission USD|Комиссия USD
Risk row|Риск строки
Commission row|Комиссия строки
Already imported|Уже импортировано
Check: similar trade exists|Проверьте: есть похожая сделка
New|Новая
I checked the account, dates, original risk, commissions and possible duplicates.|Я проверил счёт, даты, исходный риск, комиссии и возможные дубликаты.
Sum of recorded net trade results in this period. Return % requires a starting balance.|Сумма чистых результатов сделок за период. Для доходности в % нужен начальный баланс.
Trades with positive P&L divided by all recorded trades, including breakeven.|Прибыльные сделки, делённые на все записанные сделки, включая безубыточные.
Number of recorded trades in this period. A partial close is one journal record.|Количество записанных сделок за период. Частичное закрытие — одна запись журнала.
Total positive P&L divided by winning trades.|Общий положительный P&L, делённый на число прибыльных сделок.
Total negative P&L divided by losing trades, shown as a negative amount.|Общий отрицательный P&L, делённый на число убыточных сделок; показан отрицательной суммой.
Gross profits divided by the absolute gross losses. No losses can produce infinity; no usable results show —.|Валовая прибыль, делённая на абсолютный валовой убыток. Без убытков возможно значение ∞; без данных показано —.
Net P&L divided by all trades: the average recorded result per trade, not a forecast.|Чистый P&L, делённый на все сделки: средний записанный результат, а не прогноз.
Mean daily equity return divided by its sample standard deviation. Not annualized; requires positive starting capital and at least two trading days.|Средняя дневная доходность капитала, делённая на выборочное стандартное отклонение. Без пересчёта на год; нужен положительный начальный капитал и минимум два торговых дня.
Highest net P&L in this period. Click to view the record and screenshots.|Самый высокий чистый P&L за период. Нажмите для просмотра записи и скриншотов.
Largest recorded loss in this period. No losing trades show —.|Наибольший записанный убыток за период. При отсутствии убыточных сделок показано —.
Smallest strictly positive result in this period.|Наименьший положительный результат за период.
No losing trades|Нет убыточных сделок
Worst Trade|Худшая сделка
Performance Timeline|Динамика результатов
Daily net result|Чистый результат за день
Cumulative win rate|Накопленный процент побед
Daily|По дням
Add a trade to see your performance timeline.|Добавьте сделку для просмотра динамики результатов.
Net result|Чистый результат
Trading days|Торговые дни
Max drawdown|Максимальная просадка
Sharpe Ratio · William F. Sharpe (1994)|Коэффициент Шарпа · William F. Sharpe (1994)
P&L|P&L
{v0} · {v1}|{v0} · {v1}
{v0} · {v1} {v2}|{v0} · {v1} {v2}
Performance|Результаты
Trade calendar|Календарь сделок
Your playbook|Ваш торговый план
YOUR TRADES. YOUR PROCESS. YOUR EDGE.|ВАШИ СДЕЛКИ. ВАШ ПРОЦЕСС. ВАШЕ ПРЕИМУЩЕСТВО.
Every trade tells a story.|У каждой сделки своя история.
Find your edge.|Найдите своё преимущество.
Turn your trading history into a clearer plan. Track performance, review your setups and build the discipline to follow your own rules.|Превратите историю сделок в чёткий план. Отслеживайте результаты, анализируйте сетапы и развивайте дисциплину, чтобы следовать своим правилам.
Explore the journal|Посмотреть журнал
Private preview · English, Georgian & Russian|Личная версия · английский, грузинский и русский
Interactive product preview with sample data|Интерактивный пример с демонстрационными данными
Illustrative data|Демонстрационные данные
Trader Focus|Фокус трейдера
Trader Focus sections|Разделы «Фокус трейдера»
YOUR EDGE STARTS INSIDE|ВАШЕ ПРЕИМУЩЕСТВО НАЧИНАЕТСЯ С ФОКУСА
Your process, mindset, and trading edge.|Ваш процесс, настрой и торговое преимущество.
Check your mindset, protect your process, and build a repeatable edge.|Оцените свой настрой, придерживайтесь процесса и укрепляйте своё преимущество.
Mindset check-in|Отметить настрой
Average energy|Средний уровень энергии
Most common mindset|Самый частый настрой
sessions tracked|учтено сессий
based on mood stickers|по отметкам настроения
self-reported|по вашей оценке
across saved check-ins|среди сохранённых отметок
A note for your process|Подсказка для вашего процесса
Mood|Настроение
Your process|Ваш процесс
Start with one check-in|Начните с одной отметки
A quick check-in helps you notice your state before it starts shaping a trade.|Короткая отметка помогает заметить своё состояние до того, как оно повлияет на сделку.
Anxiety is a signal, not an order. Return to your risk plan; sitting out is a valid decision.|Тревога — это сигнал, а не приказ. Вернитесь к плану риска; пропустить сделку — тоже решение.
A move you missed does not change your plan. Wait for the setup that belongs to you.|Упущенное движение не меняет ваш план. Дождитесь подходящего сетапа.
The next trade does not need to win back the last one. Let your rules guide the next decision.|Следующая сделка не обязана отыгрывать предыдущую. Пусть решением руководствуют ваши правила.
Rest can be the best risk control. You do not owe the market another trade today.|Отдых может стать лучшим способом управлять риском. Сегодня вы не обязаны открывать ещё одну сделку.
Protect your focus before you protect a position. A planned pause is part of the process.|Сначала сохраните фокус, затем позицию. Запланированная пауза — часть процесса.
One session does not define your ability. Review the quality of your decisions, one trade at a time.|Одна сессия не определяет ваши способности. Оценивайте качество решений по каждой сделке.
Patience is an edge. Keep your risk steady and let the right setup come to you.|Терпение — ваше преимущество. Соблюдайте план риска и дождитесь подходящего сетапа.
Mindset patterns|Закономерности настроя
How often each mindset appeared in your saved check-ins.|Как часто каждый настрой отмечался в сохранённых записях.
Your saved mindset snapshots.|Сохранённые заметки о вашем настрое.
Discard unsaved Trader Focus changes?|Отменить несохранённые изменения в разделе «Фокус трейдера»?
Trader Focus changed in another window. Reload your check-ins.|Записи в разделе «Фокус трейдера» изменились в другом окне. Обновите их.
`;
export const RU_MESSAGES:Record<string,string> = Object.fromEntries((entries.trim()+'\n'+additional.trim()).split('\n').map(line=>{const at=line.indexOf('|');return [line.slice(0,at),line.slice(at+1)];}));
