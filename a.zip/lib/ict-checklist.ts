import { translate,type JournalLanguage } from './journal-language.ts';
export type { JournalLanguage } from './journal-language.ts';
export const ICT_CATEGORIES=[{id:'context',ka:'მიმართულება',en:'Bias'},{id:'liquidity',ka:'ლიკვიდობა',en:'Liquidity'},{id:'entry',ka:'შესვლა',en:'Entry'},{id:'timing',ka:'დრო',en:'Timing'},{id:'risk',ka:'რისკი',en:'Risk'}] as const;
type Category=typeof ICT_CATEGORIES[number]['id'];
export const ICT_CONDITIONS:{id:string;category:Category;ka:string;en:string}[]=[
 {id:'htf-bias',category:'context',ka:'HTF მიმართულება განსაზღვრულია (Daily / H4 / H1)',en:'Higher-timeframe bias identified (Daily / H4 / H1)'},
 {id:'draw-liquidity',category:'context',ka:'Draw on Liquidity — მიზნობრივი ლიკვიდობა მონიშნულია',en:'Draw on Liquidity — target liquidity marked'},
 {id:'dealing-range',category:'context',ka:'Dealing Range და Equilibrium (50%) მონიშნულია',en:'Dealing range and equilibrium (50%) marked'},
 {id:'premium-discount',category:'context',ka:'შესვლა შეესაბამება ჩემს Premium / Discount გეგმას',en:'Entry matches my premium / discount plan'},
 {id:'previous-day',category:'liquidity',ka:'წინა დღის High / Low (PDH / PDL) მონიშნულია',en:'Previous-day high / low (PDH / PDL) marked'},
 {id:'previous-week',category:'liquidity',ka:'წინა კვირის High / Low (PWH / PWL) მონიშნულია',en:'Previous-week high / low (PWH / PWL) marked'},
 {id:'equal-levels',category:'liquidity',ka:'Equal Highs / Equal Lows და BSL / SSL მონიშნულია',en:'Equal highs / equal lows and BSL / SSL marked'},
 {id:'session-range',category:'liquidity',ka:'აზიის / ლონდონის სესიის High / Low მონიშნულია',en:'Asian / London session high / low marked'},
 {id:'liquidity-sweep',category:'liquidity',ka:'დაგეგმილი Liquidity Sweep დაფიქსირდა',en:'Planned liquidity sweep observed'},
 {id:'displacement',category:'entry',ka:'Displacement დაფიქსირდა ჩემი სეტაპის მიმართულებით',en:'Displacement observed in my setup direction'},
 {id:'mss',category:'entry',ka:'Market Structure Shift (MSS) დადასტურებულია',en:'Market Structure Shift (MSS) confirmed'},
 {id:'fvg',category:'entry',ka:'Fair Value Gap (FVG) მონიშნულია',en:'Fair Value Gap (FVG) marked'},
 {id:'fvg-return',category:'entry',ka:'ფასი დაბრუნდა დაგეგმილ FVG-ში',en:'Price returned to the planned FVG'},
 {id:'order-block',category:'entry',ka:'Order Block მონიშნულია და შეესაბამება ჩემს მოდელს',en:'Order block marked and aligned with my model'},
 {id:'breaker',category:'entry',ka:'Breaker / Mitigation Block შეესაბამება ჩემს სეტაპს',en:'Breaker / mitigation block matches my setup'},
 {id:'ote',category:'entry',ka:'შესვლა შეესაბამება ჩემს OTE მოდელს',en:'Entry matches my OTE model'},
 {id:'smt',category:'entry',ka:'SMT Divergence შემოწმებულია NQ / ES-ზე',en:'SMT divergence checked on NQ / ES'},
 {id:'killzone',category:'timing',ka:'შესვლა დაგეგმილ Killzone / სესიაშია',en:'Entry is within my planned killzone / session'},
 {id:'news',category:'timing',ka:'ეკონომიკური კალენდარი და მნიშვნელოვანი სიახლეები შემოწმებულია',en:'Economic calendar and high-impact news checked'},
 {id:'timezone',category:'timing',ka:'სესიის დრო და დროის სარტყელი შემოწმებულია',en:'Session times and timezone checked'},
 {id:'stop',category:'risk',ka:'Stop Loss და სეტაპის გაუქმების დონე განსაზღვრულია',en:'Stop loss and setup invalidation level defined'},
 {id:'risk-limit',category:'risk',ka:'პოზიციის ზომა და რისკი ჩემს დღიურ ლიმიტშია',en:'Position size and risk are within my daily limit'},
 {id:'target',category:'risk',ka:'მიზანი და დაგეგმილი R:R განსაზღვრულია',en:'Target and planned R:R defined'},
 {id:'no-chase',category:'risk',ka:'შესვლა გეგმის მიხედვითაა — არ მივდევ ფასს',en:'Entry follows my plan — I am not chasing price'},
];
export function hasICTCondition(checklist:string[],condition:typeof ICT_CONDITIONS[number]){return checklist.some(point=>point.trim()===condition.ka||point.trim()===condition.en||point.trim()===translate(condition.en,'ru'));}
export function addICTCondition(checklist:string[],id:string,language:JournalLanguage){
 const condition=ICT_CONDITIONS.find(c=>c.id===id);if(!condition)throw new Error('Unknown ICT condition');
 if(hasICTCondition(checklist,condition))return checklist;
 if(checklist.length>=16)throw new Error('შეგიძლია დაამატო მაქსიმუმ 16 პირობა.');
 return [...checklist,language==='ru'?translate(condition.en,'ru'):condition[language]];
}
