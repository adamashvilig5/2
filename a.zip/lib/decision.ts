import { z } from 'zod';
const id = z.string().min(1).max(80);
export const boardSchema = z.object({
  title: z.string().max(160),
  criteria: z.array(z.object({ id, name: z.string().max(80), weight: z.number().int().min(0).max(100) })).max(12),
  options: z.array(z.object({ id, name: z.string().max(100), notes: z.string().max(2000), scores: z.record(z.number().int().min(0).max(10).nullable()) })).max(8),
});
export type Board = z.infer<typeof boardSchema>;
export type SavedChoice = { optionId: string; optionName: string; rationale: string; score: number; savedAt: string; snapshot: Board };
export type RecordData = { board: Board; choice: SavedChoice | null; revision: number };
export const emptyBoard: Board = { title: '', criteria: [{id:'c1',name:'Cost',weight:40},{id:'c2',name:'Time',weight:30},{id:'c3',name:'Fit',weight:30}], options: [{id:'o1',name:'',notes:'',scores:{}},{id:'o2',name:'',notes:'',scores:{}}] };
export const exampleBoard: Board = { title: 'Choose a workspace', criteria: [{id:'c1',name:'Affordability',weight:40},{id:'c2',name:'Focus',weight:35},{id:'c3',name:'Flexibility',weight:25}], options: [{id:'o1',name:'Home office',notes:'No commute or monthly fee. More distractions during the day.',scores:{c1:10,c2:6,c3:9}},{id:'o2',name:'Coworking space',notes:'A dedicated place to focus. Monthly cost and a short commute.',scores:{c1:5,c2:9,c3:8}},{id:'o3',name:'Local café',notes:'Low commitment. Noise and seating vary.',scores:{c1:7,c2:4,c3:10}}] };
export function totalWeight(board: Board) { return board.criteria.reduce((n,c)=>n+c.weight,0); }
export function boardProblem(board: Board): string | null {
  if (!board.title.trim()) return 'Give your decision a title.';
  if (board.options.length < 2) return 'Add at least two options.';
  if (!board.criteria.length) return 'Add at least one criterion.';
  if (board.options.some(o=>!o.name.trim()) || board.criteria.some(c=>!c.name.trim())) return 'Name every option and criterion.';
  if (new Set(board.options.map(o=>o.name.trim().toLowerCase())).size !== board.options.length) return 'Give each option a different name.';
  if (new Set(board.criteria.map(c=>c.name.trim().toLowerCase())).size !== board.criteria.length) return 'Give each criterion a different name.';
  if (!totalWeight(board)) return 'Set at least one weight above zero.';
  if (board.options.some(o=>board.criteria.some(c=>c.weight>0 && o.scores[c.id]==null))) return 'Score each option for every criterion with a weight above zero.';
  return null;
}
export function scoreOption(board: Board, option: Board['options'][number]): number | null {
  const total=totalWeight(board);
  if (!total || board.criteria.some(c=>c.weight>0 && option.scores[c.id]==null)) return null;
  return board.criteria.reduce((sum,c)=>sum+(option.scores[c.id]??0)*c.weight,0)/total;
}
export function ranking(board: Board) { return board.options.map(option=>({option,score:scoreOption(board,option)})).sort((a,b)=>(b.score??-1)-(a.score??-1)); }
export function parseBoard(input: unknown): Board {
 const b=boardSchema.parse(input);
 for(const rows of [b.criteria,b.options]) if(new Set(rows.map(r=>r.id)).size!==rows.length) throw new Error('Duplicate IDs');
 for(const o of b.options) if(Object.keys(o.scores).some(k=>!b.criteria.some(c=>c.id===k))) throw new Error('Unknown criterion');
 return b;
}
