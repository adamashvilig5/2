export type EconomicEvent={id:string;title:string;currency:string;date:string;impact:'High'|'Medium'|'Low'|'Holiday'|'Unknown';forecast:string;previous:string;actual:string;allDay:boolean;fetchedAt?:string};
export const NEWS_URL='https://nfs.faireconomy.media/ff_calendar_thisweek.json';
export const MONTHLY_NEWS_URL='https://www.financecalendar.com/wp-json/fc/v1/calendar';
function easternEventTime(day:string,rawTime:unknown){if(typeof rawTime!=='string')return null;const m=/^(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?(?:\s*ET)?$/i.exec(rawTime.trim());if(!m)return null;let hour=Number(m[1]);const minute=Number(m[2]),second=Number(m[3]??0);if(m[4])hour=hour%12+(m[4].toUpperCase()==='PM'?12:0);const desired=Date.UTC(Number(day.slice(0,4)),Number(day.slice(5,7))-1,Number(day.slice(8,10)),hour,minute,second);const fmt=new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});const p=Object.fromEntries(fmt.formatToParts(new Date(desired)).map(x=>[x.type,x.value]));const represented=Date.UTC(Number(p.year),Number(p.month)-1,Number(p.day),Number(p.hour),Number(p.minute),Number(p.second));return new Date(desired-(represented-desired)).toISOString();}
export function parseEconomicEvents(raw:unknown):EconomicEvent[]{
 if(!Array.isArray(raw)||raw.length>2000||!raw.length)throw Error('Invalid calendar feed');
 const seen=new Set<string>();return raw.map(r=>{if(!r||typeof r.title!=='string'||typeof r.country!=='string'||typeof r.date!=='string'||!/(Z|[+-]\d{2}:\d{2})$/.test(r.date)||!Number.isFinite(Date.parse(r.date)))throw Error('Invalid calendar event');
 const impact=r.impact==='Non-Economic'?'Holiday':['High','Medium','Low','Holiday'].includes(r.impact)?r.impact:'Unknown';const id=[r.date,r.country,r.title].join('|');if(seen.has(id))return null;seen.add(id);return {id,title:r.title.slice(0,250),currency:r.country.slice(0,8),date:r.date,impact,forecast:String(r.forecast??'').slice(0,60),previous:String(r.previous??'').slice(0,60),actual:String(r.actual??'').slice(0,60),allDay:impact==='Holiday'} as EconomicEvent;}).filter((e):e is EconomicEvent=>e!==null).sort((a,b)=>Date.parse(a.date)-Date.parse(b.date));
}
/** Normalize Finance Calendar's date-range API into the calendar's shared event model. */
export function parseMonthlyEconomicEvents(raw:unknown):EconomicEvent[]{
 const rows=Array.isArray(raw)?raw:(raw&&typeof raw==='object'&&Array.isArray((raw as {events?:unknown}).events)?(raw as {events:unknown[]}).events:null);
 if(!rows||rows.length>500)throw Error('Invalid monthly calendar feed');
 const seen=new Set<string>();const events=rows.map(r=>{if(!r||typeof r!=='object')throw Error('Invalid monthly calendar event');const e=r as Record<string,unknown>;
 const title=typeof e.title==='string'?e.title:typeof e.name==='string'?e.name:'';
 const currency=typeof e.currency==='string'?e.currency:typeof e.country==='string'?e.country:typeof e.currency_code==='string'?e.currency_code:(/(\bUS\b|United States|FOMC|Federal Reserve|\bFed\b)/i.test(title)?'USD':/(Eurozone|Euro area|ECB|Germany|German)/i.test(title)?'EUR':/(\bUK\b|Britain|BoE|Bank of England|England)/i.test(title)?'GBP':/(Japan|BoJ|Bank of Japan)/i.test(title)?'JPY':/(Canada|BoC|Bank of Canada)/i.test(title)?'CAD':/(Australia|RBA|Bank of Australia)/i.test(title)?'AUD':/(New Zealand|RBNZ)/i.test(title)?'NZD':/(Swiss|SNB|Switzerland)/i.test(title)?'CHF':/(China|PBoC)/i.test(title)?'CNY':'ALL');
 const day=typeof e.date==='string'?e.date.slice(0,10):'';const date=typeof e.time_utc==='string'&&/(Z|[+-]\d{2}:?\d{2})$/.test(e.time_utc)?e.time_utc:typeof e.date==='string'&&/T.*(Z|[+-]\d{2}:\d{2})$/.test(e.date)?e.date:day?easternEventTime(day,e.time_et)??`${day}T12:00:00Z`:'';
 if(!title||!currency||!date||!Number.isFinite(Date.parse(date)))throw Error('Invalid monthly calendar event');
 const rawImpact=String(e.impact??'').toLowerCase(),impact: EconomicEvent['impact']=rawImpact==='high'?'High':rawImpact==='medium'?'Medium':rawImpact==='low'?'Low':rawImpact.includes('holiday')?'Holiday':'Unknown';
 const id=[date,currency,title].join('|');if(seen.has(id))return null;seen.add(id);
 return {id,title:title.slice(0,250),currency:currency.slice(0,8).toUpperCase(),date,impact,forecast:String(e.consensus??e.forecast??'').slice(0,60),previous:String(e.prior??e.previous??'').slice(0,60),actual:e.actual==null?'':String(e.actual).slice(0,60),allDay:e.all_day===true||impact==='Holiday'||(!e.time_utc&&!e.time_et)} as EconomicEvent;
 }).filter((e):e is EconomicEvent=>e!==null);
 const holidays=usFederalBankHolidays(rows).filter(holiday=>!events.some(event=>event.currency==='USD'&&event.impact==='Holiday'&&economicDay(event,'America/New_York')===economicDay(holiday,'America/New_York')));
 return [...events,...holidays].sort((a,b)=>Date.parse(a.date)-Date.parse(b.date));
}
/** Finance Calendar omits some US bank closures; supplement Columbus Day from the Federal Reserve calendar. */
function usFederalBankHolidays(rows:unknown[]):EconomicEvent[]{
 const days=rows.flatMap(row=>row&&typeof row==='object'&&typeof (row as Record<string,unknown>).date==='string'?[(row as Record<string,string>).date.slice(0,10)]:[]).filter(day=>/^\d{4}-\d{2}-\d{2}$/.test(day)).sort();
 if(!days.length)return[];const firstYear=Number(days[0].slice(0,4)),lastYear=Number(days.at(-1)!.slice(0,4)),holidays:EconomicEvent[]=[];
 for(let year=firstYear;year<=lastYear;year++){
  const firstOfOctober=new Date(Date.UTC(year,9,1)).getUTCDay(),firstMonday=1+((8-firstOfOctober)%7),date=new Date(Date.UTC(year,9,firstMonday+7)).toISOString().slice(0,10);
  if(date<days[0]||date>days.at(-1)!)continue;
  holidays.push({id:`${date}|USD|US Bank Holiday — Columbus Day`,title:'US Bank Holiday — Columbus Day / Indigenous Peoples’ Day',currency:'USD',date:`${date}T12:00:00.000Z`,impact:'Holiday',forecast:'',previous:'',actual:'',allDay:true});
 }
 return holidays;
}
export function economicDay(event:EconomicEvent,timezone:string){return event.allDay?event.date.slice(0,10):new Intl.DateTimeFormat('en-CA',{timeZone:timezone,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(event.date));}
export function economicWeek(events:EconomicEvent[]){const date=new Date(economicDay(events[0],'America/New_York')+'T12:00:00Z');date.setUTCDate(date.getUTCDate()-date.getUTCDay());const start=date.toISOString().slice(0,10);date.setUTCDate(date.getUTCDate()+6);return {start,end:date.toISOString().slice(0,10)};}
