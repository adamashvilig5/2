import type { Daily, Trade, Strategy } from './trading';
import type { InnerEntry } from './inner-space';

export type AchievementCategory='journal'|'risk'|'discipline'|'strategy'|'focus'|'consistency';
export type Award={id:string;xp:number;earnedAt:string};
export type TodayProcessTask={id:string;title:string;xp:number;done:boolean;earned:boolean};
type Metrics={trades:number;notes:number;deepReviews:number;photos:number;comparisons:number;strategies:number;planned:number;completePlans:number;mindset:number;dailyPlans:number;goalsDone:number;activeDays:number;bestStreak:number;currentStreak:number;fullReviews:number;reviewedTrades:number;checkins:number;riskPlanDays:number;stableRiskTrades:number};
type Definition={id:string;title:string;description:string;category:AchievementCategory;tier:'Bronze'|'Silver'|'Gold'|'Platinum';xp:number;target:number;metric:keyof Metrics};
export const ACHIEVEMENTS:Definition[]=[
 {id:'first-entry',title:'First Step',description:'Record your first trade.',category:'journal',tier:'Bronze',xp:100,target:1,metric:'trades'},
 {id:'five-entries',title:'Building a Habit',description:'Save 5 trade entries.',category:'journal',tier:'Bronze',xp:150,target:5,metric:'trades'},
 {id:'ten-entries',title:'Power of Data',description:'Collect 10 trade entries.',category:'journal',tier:'Silver',xp:200,target:10,metric:'trades'},
 {id:'twenty-five-entries',title:'My Track Record',description:'Collect 25 trade entries.',category:'journal',tier:'Silver',xp:350,target:25,metric:'trades'},
 {id:'fifty-entries',title:'Personal Archive',description:'Save 50 trade entries.',category:'journal',tier:'Gold',xp:500,target:50,metric:'trades'},
 {id:'hundred-entries',title:'Century Club',description:'Collect 100 trade entries.',category:'journal',tier:'Platinum',xp:800,target:100,metric:'trades'},
 {id:'first-note',title:'The Story Behind the Result',description:'Add a note of at least 20 characters to one trade.',category:'discipline',tier:'Bronze',xp:75,target:1,metric:'notes'},
 {id:'five-notes',title:'Observant Analyst',description:'Add a note of at least 20 characters to 5 trades.',category:'discipline',tier:'Silver',xp:200,target:5,metric:'notes'},
 {id:'twenty-notes',title:'Lessons Collected',description:'Write an observation in 20 trade entries.',category:'discipline',tier:'Gold',xp:450,target:20,metric:'notes'},
 {id:'deep-review',title:'Deep Analysis',description:'Write a note of at least 150 characters for one trade.',category:'discipline',tier:'Silver',xp:125,target:1,metric:'deepReviews'},
 {id:'first-photo',title:'First Snapshot',description:'Attach a screenshot to one trade.',category:'journal',tier:'Bronze',xp:100,target:1,metric:'photos'},
 {id:'five-photos',title:'Visual Journal',description:'Attach screenshots to 5 trades.',category:'journal',tier:'Silver',xp:250,target:5,metric:'photos'},
 {id:'twenty-photos',title:'Chart Archive',description:'Preserve visual context for 20 trades.',category:'journal',tier:'Gold',xp:500,target:20,metric:'photos'},
 {id:'first-comparison',title:'Before and After',description:'Attach both pre-trade and post-trade screenshots to one trade.',category:'journal',tier:'Silver',xp:150,target:1,metric:'comparisons'},
 {id:'five-comparisons',title:'Complete Picture',description:'Attach both stages of screenshots to 5 trades.',category:'journal',tier:'Gold',xp:400,target:5,metric:'comparisons'},
 {id:'first-strategy',title:'My First Plan',description:'Create a strategy with at least one rule.',category:'strategy',tier:'Bronze',xp:100,target:1,metric:'strategies'},
 {id:'three-strategies',title:'Playbook Builder',description:'Create 3 strategies with your own rules.',category:'strategy',tier:'Silver',xp:250,target:3,metric:'strategies'},
 {id:'first-planned',title:'Plan in Action',description:'Assign your strategy to one trade.',category:'strategy',tier:'Bronze',xp:100,target:1,metric:'planned'},
 {id:'five-planned',title:'Plan Follower',description:'Record 5 trades using a selected strategy.',category:'strategy',tier:'Silver',xp:250,target:5,metric:'planned'},
 {id:'first-checklist',title:'Every Rule Checked',description:'Complete every selected strategy rule on one trade.',category:'strategy',tier:'Silver',xp:150,target:1,metric:'completePlans'},
 {id:'five-checklists',title:'Discipline in Practice',description:'Complete the full strategy checklist on 5 trades.',category:'strategy',tier:'Gold',xp:400,target:5,metric:'completePlans'},
 {id:'first-mindset',title:'Name the Emotion',description:'Tag at least two emotions and add a 20-character note to one trade.',category:'focus',tier:'Bronze',xp:75,target:1,metric:'mindset'},
 {id:'ten-mindsets',title:'Mindset Observer',description:'Tag at least two emotions and add a 20-character note to 10 trades.',category:'focus',tier:'Gold',xp:350,target:10,metric:'mindset'},
 {id:'first-daily-plan',title:'Start with Intention',description:'Save a daily plan of at least 20 characters.',category:'discipline',tier:'Bronze',xp:100,target:1,metric:'dailyPlans'},
 {id:'five-daily-plans',title:'Map Your Goals',description:'Save a plan for 5 different days.',category:'discipline',tier:'Silver',xp:250,target:5,metric:'dailyPlans'},
 {id:'twenty-daily-plans',title:'From Intention to Habit',description:'Create a plan for 20 different days.',category:'discipline',tier:'Gold',xp:500,target:20,metric:'dailyPlans'},
 {id:'first-goals-done',title:'Daily Rules Kept',description:'Complete every rule in one saved daily plan.',category:'discipline',tier:'Silver',xp:150,target:1,metric:'goalsDone'},
 {id:'five-goals-done',title:'Goal Keeper',description:'Complete every rule in daily plans for 5 different days.',category:'discipline',tier:'Gold',xp:350,target:5,metric:'goalsDone'},
 {id:'three-day-streak',title:'Find Your Rhythm',description:'Save a trade or daily plan on 3 consecutive calendar days.',category:'consistency',tier:'Bronze',xp:200,target:3,metric:'bestStreak'},
 {id:'seven-day-streak',title:'A Week of Commitment',description:'Update your journal or daily plan on 7 consecutive days.',category:'consistency',tier:'Gold',xp:500,target:7,metric:'bestStreak'},
 {id:'thirty-day-streak',title:'Consistency Master',description:'Save a trade or plan on 30 consecutive calendar days.',category:'consistency',tier:'Platinum',xp:1200,target:30,metric:'bestStreak'},
 {id:'thirty-active-days',title:'30 Days of Experience',description:'Update your journal on 30 different days; they do not need to be consecutive.',category:'consistency',tier:'Gold',xp:600,target:30,metric:'activeDays'},
 {id:'fifty-notes',title:'Analysis Library',description:'Add an observation of at least 20 characters to 50 trades.',category:'discipline',tier:'Platinum',xp:750,target:50,metric:'notes'},
 {id:'ten-deep-reviews',title:'Detail Seeker',description:'Write an analysis of at least 150 characters for 10 trades.',category:'discipline',tier:'Gold',xp:350,target:10,metric:'deepReviews'},
 {id:'twenty-five-deep-reviews',title:'Research Expert',description:'Add an analysis of at least 150 characters to 25 trades.',category:'discipline',tier:'Platinum',xp:650,target:25,metric:'deepReviews'},
 {id:'fifty-photos',title:'Chart Collector',description:'Save a screenshot for 50 trades.',category:'journal',tier:'Platinum',xp:800,target:50,metric:'photos'},
 {id:'twenty-comparisons',title:'From Snapshot to Insight',description:'Attach both pre-trade and post-trade screenshots to 20 trades.',category:'journal',tier:'Platinum',xp:700,target:20,metric:'comparisons'},
 {id:'twenty-planned',title:'Strategy as a Habit',description:'Save 20 trades using your own strategy.',category:'strategy',tier:'Gold',xp:500,target:20,metric:'planned'},
 {id:'fifty-planned',title:'Playbook Master',description:'Assign your own strategy to 50 trades.',category:'strategy',tier:'Platinum',xp:750,target:50,metric:'planned'},
 {id:'twenty-checklists',title:'Committed to the Process',description:'Complete every strategy rule on 20 trades.',category:'strategy',tier:'Platinum',xp:700,target:20,metric:'completePlans'},
 {id:'five-mindsets',title:'Self-Awareness',description:'Tag at least two emotions and add a 20-character note to 5 trades.',category:'focus',tier:'Silver',xp:150,target:5,metric:'mindset'},
 {id:'twenty-five-mindsets',title:'Emotion Map',description:'Tag at least two emotions and add a 20-character note to 25 trades.',category:'focus',tier:'Platinum',xp:600,target:25,metric:'mindset'},
 {id:'fifty-daily-plans',title:'Goals Become Habits',description:'Save a plan of at least 20 characters for 50 different days.',category:'discipline',tier:'Platinum',xp:750,target:50,metric:'dailyPlans'},
 {id:'twenty-goals-done',title:'Rule Keeper',description:'Complete every rule in daily plans for 20 different days.',category:'discipline',tier:'Platinum',xp:600,target:20,metric:'goalsDone'},
 {id:'fourteen-day-streak',title:'Two-Week Rhythm',description:'Save a trade or daily plan on 14 consecutive calendar days.',category:'consistency',tier:'Gold',xp:800,target:14,metric:'bestStreak'},
 {id:'sixty-active-days',title:'Steady Progress',description:'Update your journal on 60 different days.',category:'consistency',tier:'Platinum',xp:900,target:60,metric:'activeDays'},
 {id:'ninety-active-days',title:'90-Day Journey',description:'Update your journal on 90 different days.',category:'consistency',tier:'Platinum',xp:1200,target:90,metric:'activeDays'},
 {id:'risk-protector',title:'Risk Protector',description:'Mark your planned risk rule in 5 daily plans.',category:'risk',tier:'Silver',xp:250,target:5,metric:'riskPlanDays'},
 {id:'consistent-risk',title:'Consistent Risk',description:'Keep risk size within ±20% of your historical median across 10 trades.',category:'risk',tier:'Gold',xp:350,target:10,metric:'stableRiskTrades'},
 {id:'review-habit',title:'Review Habit',description:'Complete a post-trade review for 10 saved trades.',category:'discipline',tier:'Silver',xp:250,target:10,metric:'reviewedTrades'},
 {id:'mindset-aware',title:'Mindset Aware',description:'Complete 7 Trader Focus check-ins.',category:'focus',tier:'Silver',xp:200,target:7,metric:'checkins'},
 {id:'first-full-review',title:'Complete Trade Story',description:'Add pre- and post-trade screenshots, a 150-character analysis, at least two emotions, and a completed strategy checklist to one trade.',category:'discipline',tier:'Gold',xp:250,target:1,metric:'fullReviews'},
];
export const CATEGORIES:{id:AchievementCategory;label:string}[]=[{id:'journal',label:'Journal'},{id:'risk',label:'Risk'},{id:'discipline',label:'Discipline'},{id:'strategy',label:'Strategy'},{id:'focus',label:'Focus'},{id:'consistency',label:'Consistency'}];

export function achievementMetrics(trades:Trade[],daily:Daily[],strategies:Strategy[],today:string,innerEntries:InnerEntry[]=[]):Metrics{
 const rows=trades.filter(t=>t.date<=today),plans=daily.filter(d=>d.date<=today);
 const activeDates=[...new Set([...rows.map(t=>t.date),...plans.filter(d=>d.note.trim().length>=20||d.rules.some(r=>r.checked)).map(d=>d.date)])].sort();
 let bestStreak=0,streak=0,previous:number|null=null;
 for(const date of activeDates){const current=Date.parse(date+'T00:00:00Z');streak=previous!==null&&current-previous===86400000?streak+1:1;bestStreak=Math.max(bestStreak,streak);previous=current;}
 const last=activeDates.at(-1),age=last?(Date.parse(today+'T00:00:00Z')-Date.parse(last+'T00:00:00Z'))/86400000:Infinity;
 const reviewedMindset=(t:Trade)=>(t.emotions?.length??(t.emotion?1:0))>=2&&t.notes.trim().length>=20;
 const fullReviews=rows.filter(t=>t.notes.trim().length>=150&&reviewedMindset(t)&&t.strategyId&&t.strategySnapshot?.checklist.length&&t.strategySnapshot.checklist.every(point=>t.strategyChecks?.includes(point))&&t.screenshots.some(s=>s.phase==='before')&&t.screenshots.some(s=>s.phase==='after')).length;
 const risks=rows.map(t=>t.risk).sort((a,b)=>a-b),medianRisk=risks.length?risks.length%2?risks[Math.floor(risks.length/2)]:(risks[risks.length/2-1]+risks[risks.length/2])/2:0;
 const stableRiskTrades=medianRisk>0?rows.filter(t=>Math.abs(t.risk-medianRisk)/medianRisk<=.2).length:0;
 const riskPlanDays=plans.filter(d=>d.rules.some(rule=>/risk|რისკ/i.test(rule.label)&&rule.checked)).length;
 return {trades:rows.length,notes:rows.filter(t=>t.notes.trim().length>=20).length,deepReviews:rows.filter(t=>t.notes.trim().length>=150).length,photos:rows.filter(t=>t.screenshots.length>0).length,comparisons:rows.filter(t=>t.screenshots.some(s=>s.phase==='before')&&t.screenshots.some(s=>s.phase==='after')).length,strategies:strategies.filter(s=>s.checklist.length>0).length,planned:rows.filter(t=>t.strategyId&&t.strategySnapshot).length,completePlans:rows.filter(t=>t.strategyId&&t.strategySnapshot?.checklist.length&&t.strategySnapshot.checklist.every(point=>t.strategyChecks?.includes(point))).length,mindset:rows.filter(reviewedMindset).length,dailyPlans:plans.filter(d=>d.note.trim().length>=20).length,goalsDone:plans.filter(d=>d.rules.length>0&&d.rules.every(r=>r.checked)).length,activeDays:activeDates.length,bestStreak,currentStreak:age<=1?streak:0,fullReviews,reviewedTrades:rows.filter(t=>t.review).length,checkins:innerEntries.filter(entry=>entry.date<=today&&entry.mood!==null).length,riskPlanDays,stableRiskTrades};
}
export const levelThreshold=(level:number)=>150*(level-1)+100*(level-1)**2;
export const LEVEL_RANKS=[
 {from:1,title:'Market Explorer',description:'Start building your trading journal.'},
 {from:2,title:'Setup Observer',description:'Your first entries begin to shape your experience.'},
 {from:3,title:'Journal Analyst',description:'You capture context alongside results.'},
 {from:4,title:'Plan Executor',description:'Planning and reflection become part of your routine.'},
 {from:5,title:'Disciplined Trader',description:'Your journal becomes part of your daily process.'},
 {from:6,title:'Risk Manager',description:'You review entries, risk, and emotions.'},
 {from:7,title:'Setup Specialist',description:'You consistently build a history of your setups.'},
 {from:8,title:'Strategy Architect',description:'You build your own plans and review habits.'},
 {from:10,title:'Systematic Trader',description:'You create a rich archive of saved observations.'},
 {from:12,title:'Process Mentor',description:'You capture detailed analysis and lessons learned.'},
 {from:14,title:'Journal Master',description:'You have built a substantial archive of experience.'},
];
export function rankForLevel(level:number){return [...LEVEL_RANKS].reverse().find(rank=>level>=rank.from)??LEVEL_RANKS[0];}
export function levelForXp(xp:number){
 let level=1;while(xp>=levelThreshold(level+1))level++;
 const start=levelThreshold(level),next=levelThreshold(level+1),current=xp-start,required=next-start;
 const title=rankForLevel(level).title;
 return {level,title,xp,current,required,next,remaining:next-xp,percent:Math.min(100,Math.round(current/required*100))};
}
export function achievementProgress(metrics:Metrics,awards:Award[],todayProcess:TodayProcessTask[]=[]){
 const earned=new Map(awards.map(a=>[a.id,a]));
 const items=ACHIEVEMENTS.map(a=>{const award=earned.get(a.id),current=Math.min(a.target,metrics[a.metric]);return {...a,current:award?a.target:current,percent:award?100:Math.floor(current/a.target*100),earnedAt:award?.earnedAt??null};});
 const xp=awards.reduce((sum,a)=>sum+a.xp,0);
 return {items,awards,level:levelForXp(xp),metrics,unlocked:items.filter(a=>a.earnedAt).length,total:items.length,todayProcess};
}
export type AchievementProgress=ReturnType<typeof achievementProgress>;
