import { z } from 'zod';
export const dateSchema=z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(s=>!Number.isNaN(Date.parse(s+'T00:00:00Z'))&&new Date(s+'T00:00:00Z').toISOString().slice(0,10)===s,'არასწორი თარიღი');
const timeSchema=z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/);
const amount=z.number().finite().min(-1e9).max(1e9);
export const accountIdSchema=z.union([z.literal('default'),z.string().uuid()]);
export const accountSchema=z.object({id:accountIdSchema,revision:z.number().int().min(0),name:z.string().trim().min(1).max(60),type:z.enum(['Live','Demo','Backtesting','Funded','Challenge','Paper Trading']),currency:z.enum(['USD','EUR','GBP','GEL']),startingBalance:z.number().finite().min(0).max(1e10).nullable(),description:z.string().trim().max(1000)});
export type Account=z.infer<typeof accountSchema>;
export const strategySchema=z.object({id:z.string().uuid(),revision:z.number().int().min(0),name:z.string().trim().min(1).max(60),description:z.string().trim().max(2000),checklist:z.array(z.string().trim().min(1).max(100)).max(16).refine(a=>new Set(a).size===a.length,'პირობები არ უნდა მეორდებოდეს.')});
export type Strategy=z.infer<typeof strategySchema>;
const strategySnapshotSchema=z.object({name:z.string().trim().min(1).max(60),checklist:z.array(z.string().trim().min(1).max(100)).max(16)});
const strategyConditionSchema=z.object({id:z.string().trim().min(1).max(100),label:z.string().trim().min(1).max(100),checked:z.boolean()});
const emotionAtEntrySchema=z.object({id:z.string().trim().min(1).max(80),label:z.string().trim().min(1).max(80),selected:z.boolean()});
const riskPlanSchema=z.object({plannedRiskPercent:z.number().finite().min(0).max(100).optional(),dailyLossLimit:z.number().finite().min(0).max(1e9).optional(),maximumTrades:z.number().int().min(1).max(100).optional()});
export const tradeSchema=z.object({id:z.string().uuid(),revision:z.number().int().min(0),accountId:accountIdSchema.optional(),strategyId:z.string().uuid().nullable().optional(),strategySnapshot:strategySnapshotSchema.nullable().optional(),strategyConditions:z.array(strategyConditionSchema).max(16).optional(),conditionsMet:z.number().int().min(0).max(16).optional(),conditionsTotal:z.number().int().min(0).max(16).optional(),conditionsCompletionRate:z.number().finite().min(0).max(100).optional(),emotionsAtEntry:z.array(emotionAtEntrySchema).max(20).optional(),selectedEmotionIds:z.array(z.string().trim().min(1).max(80)).max(10).optional(),preTradeReadinessScore:z.number().int().min(0).max(100).optional(),riskPlan:riskPlanSchema.optional(),rMultiple:amount.optional(),symbol:z.string().trim().min(1).max(24).transform(s=>s.toUpperCase()),side:z.enum(['Buy','Sell']),result:z.enum(['Win','Loss','Breakeven','Partial']),quantity:z.number().finite().positive().max(1e7),pnl:amount,risk:z.number().finite().positive().max(1e9),date:dateSchema,entryTime:timeSchema,exitTime:timeSchema,session:z.enum(['Asia','London','New York','London / New York','Other']),emotion:z.string().trim().min(1).max(80),emotions:z.array(z.string().trim().min(1).max(80)).max(10).optional(),strategyChecks:z.array(z.string().trim().min(1).max(100)).max(16).optional(),tags:z.array(z.string().trim().min(1).max(60)).max(8),notes:z.string().max(8000)}).superRefine((t,c)=>{if((t.result==='Win'&&t.pnl<=0)||(t.result==='Loss'&&t.pnl>=0)||(t.result==='Breakeven'&&t.pnl!==0))c.addIssue({code:z.ZodIssueCode.custom,message:'Win-ის P&L დადებითი უნდა იყოს, Loss-ის — უარყოფითი, Breakeven-ის — 0.',path:['pnl']});});
export const tradeReviewSchema=z.object({planAdherence:z.enum(['yes','partial','no']),executionChecks:z.array(z.enum(['setup','risk','entry','stop','impulse','exit'])).max(6),satisfiedConditionIds:z.array(z.string().trim().min(1).max(100)).max(16).optional(),executionQuality:z.enum(['excellent','good','partial','needs_review']).optional(),mistakes:z.array(z.enum(['clean','early','early_exit','moved_stop','overtraded','revenge','missed_confirmation','ignored_plan','other'])).max(8),lesson:z.string().trim().max(2000),readiness:z.number().int().min(0).max(100).nullable(),plannedRisk:z.number().finite().min(0).max(100).nullable(),reviewedAt:z.string().datetime()}).refine(v=>new Set(v.executionChecks).size===v.executionChecks.length,'Execution checks cannot repeat.').refine(v=>new Set(v.mistakes).size===v.mistakes.length,'Mistake tags cannot repeat.').refine(v=>new Set(v.satisfiedConditionIds??[]).size===(v.satisfiedConditionIds??[]).length,'Satisfied conditions cannot repeat.');
export type TradeReview=z.infer<typeof tradeReviewSchema>;
export type TradeInput=z.infer<typeof tradeSchema>;
export type Shot={id:string;phase:'before'|'after'|'context';filename:string};
export type StrategyCondition=z.infer<typeof strategyConditionSchema>;
export type EmotionAtEntry=z.infer<typeof emotionAtEntrySchema>;
export type Trade=TradeInput & {createdAt:string;updatedAt?:string;screenshots:Shot[];review?:TradeReview};
export type Settings={startingBalance:number|null;timezone:string;revision:number};
export const settingsSchema=z.object({startingBalance:z.number().finite().positive().max(1e10).nullable(),timezone:z.string().max(100).refine(s=>{try{new Intl.DateTimeFormat('en',{timeZone:s});return true;}catch{return false;}}),revision:z.number().int().min(0)});
export const rulesDefault=[{label:'ემოციებზე არ ვივაჭრო',checked:false},{label:'დავიცვა დაგეგმილი რისკი',checked:false},{label:'დაველოდო ჩემს სეტაპს',checked:false}];
export const dailySchema=z.object({date:dateSchema,note:z.string().max(4000),rules:z.array(z.object({label:z.string().trim().min(1).max(200),checked:z.boolean()})).max(10),revision:z.number().int().min(0)});
export type Daily=z.infer<typeof dailySchema>;
export function todayIn(timezone='America/New_York'){return new Intl.DateTimeFormat('en-CA',{timeZone:timezone,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());}
export function shiftDate(date:string,days:number){const d=new Date(date+'T00:00:00Z');d.setUTCDate(d.getUTCDate()+days);return d.toISOString().slice(0,10);}
export function tradeOrder(a:TradeInput,b:TradeInput){return (a.date+a.entryTime).localeCompare(b.date+b.entryTime)||a.id.localeCompare(b.id);}
export function periodTrades(trades:Trade[],days:number,today:string){const start=shiftDate(today,1-days);return trades.filter(t=>t.date>=start&&t.date<=today).sort(tradeOrder);}
export function openingEquity(trades:Trade[],days:number,today:string,balance:number|null){if(balance===null)return null;const start=shiftDate(today,1-days);return balance+trades.filter(t=>t.date<start).reduce((s,t)=>s+t.pnl,0);}
export function stats(trades:TradeInput[],opening:number|null){
 const sorted=[...trades].sort(tradeOrder),wins=sorted.filter(t=>t.pnl>0),losses=sorted.filter(t=>t.pnl<0);
 const grossWin=wins.reduce((s,t)=>s+t.pnl,0),grossLoss=-losses.reduce((s,t)=>s+t.pnl,0),pnl=grossWin-grossLoss;
 const avgWin=wins.length?grossWin/wins.length:0,avgLoss=losses.length?grossLoss/losses.length:0;
 let equity=opening??0,peak=equity,maxDrawdown=0,maxDrawdownPct=0;
 for(const t of sorted){equity+=t.pnl;peak=Math.max(peak,equity);maxDrawdown=Math.max(maxDrawdown,peak-equity);if(opening!==null&&peak>0)maxDrawdownPct=Math.max(maxDrawdownPct,(peak-equity)/peak*100);}
 const days=new Map<string,number>();for(const t of sorted)days.set(t.date,(days.get(t.date)??0)+t.pnl);
 const consistency=days.size?[...days.values()].filter(p=>p>0).length/days.size*100:0;
 const winRate=sorted.length?wins.length/sorted.length*100:0;
 const profitFactor=grossLoss?grossWin/grossLoss:grossWin?Infinity:null;
 const ratio=avgLoss?avgWin/avgLoss:avgWin?Infinity:null;
 const recovery=maxDrawdown?pnl/maxDrawdown:pnl>0?Infinity:null;
 const normalize=(v:number|null,cap:number)=>v===null?0:Math.min(100,Math.max(0,v/cap*100));
 const radar=[{label:'Win %',value:winRate},{label:'Profit factor',value:normalize(profitFactor,3)},{label:'Avg win/loss',value:normalize(ratio,3)},{label:'Recovery',value:normalize(recovery,5)},{label:'Drawdown',value:opening===null||opening<=0||!sorted.length?0:Math.max(0,100-maxDrawdownPct/20*100)},{label:'Consistency',value:consistency}];
 return {pnl,returnPct:opening!==null&&opening>0?pnl/opening*100:null,count:sorted.length,wins:wins.length,losses:losses.length,breakeven:sorted.length-wins.length-losses.length,winRate,avgWin,avgLoss,ratio,profitFactor,recovery,maxDrawdown,maxDrawdownPct:opening===null||opening<=0?null:maxDrawdownPct,consistency,radar,performanceScore:radar.reduce((s,r)=>s+r.value,0)/6};
}
export function equityCurve(all:Trade[],days:number,today:string,balance:number|null){
 const start=shiftDate(today,1-days),selected=periodTrades(all,days,today),byDay=new Map<string,Trade[]>();for(const t of selected)byDay.set(t.date,[...(byDay.get(t.date)??[]),t]);
 let equity=balance===null?all.filter(t=>t.date<start).reduce((s,t)=>s+t.pnl,0):openingEquity(all,days,today,balance)!;
 let wins=0,count=0;const data=[{date:shiftDate(start,-1),equity,pnl:0,winRate:0}];
 for(let i=0;i<days;i++){const date=shiftDate(start,i),rows=byDay.get(date)??[],pnl=rows.reduce((s,t)=>s+t.pnl,0);equity+=pnl;count+=rows.length;wins+=rows.filter(t=>t.pnl>0).length;data.push({date,equity,pnl,winRate:count?wins/count*100:0});}return data;
}
export function groupPerformance(trades:Trade[],kind:'tags'|'emotion'){const groups=new Map<string,Trade[]>();for(const t of trades){for(const label of kind==='tags'?(t.tags.length?t.tags:['სეტაპის გარეშე']):tradeEmotions(t))groups.set(label,[...(groups.get(label)??[]),t]);}return [...groups].map(([name,rows])=>({name,...stats(rows,null)})).sort((a,b)=>b.pnl-a.pnl);}
export const money=(n:number,currency='USD')=>new Intl.NumberFormat('en-US',{style:'currency',currency,minimumFractionDigits:2,maximumFractionDigits:2}).format(n);
export const ratioText=(n:number|null)=>n===null?'—':n===Infinity?'∞':n.toFixed(2);

export const MAX_SCREENSHOTS=10;
export const SYMBOL_OPTIONS=['MNQ','MES','NQ','ES','M2K','MYM','MGC','MCL'];
export const EMOTION_OPTIONS=['დისციპლინა','სიმშვიდე','მოთმინება','შფოთვა','სიხარბე','FOMO','შურისძიება'];
const EMOTION_CATALOG=[
 {id:'discipline',label:'Discipline',aliases:['discipline','დისციპლინა']},
 {id:'calm',label:'Calm',aliases:['calm','სიმშვიდე']},
 {id:'patience',label:'Patience',aliases:['patience','მოთმინება']},
 {id:'anxiety',label:'Anxiety',aliases:['anxiety','შფოთვა']},
 {id:'greed',label:'Greed',aliases:['greed','სიხარბე']},
 {id:'fomo',label:'FOMO',aliases:['fomo']},
 {id:'revenge',label:'Revenge',aliases:['revenge','შურისძიება']},
] as const;
export function structuredEmotionsAtEntry(emotions:string[]){
 const selected=new Set(emotions.map(value=>value.trim().toLocaleLowerCase('en-US')));
 const known=EMOTION_CATALOG.map(item=>({...item,selected:item.aliases.some(alias=>selected.has(alias))}));
 const knownAliases=new Set<string>(EMOTION_CATALOG.flatMap(item=>[...item.aliases]));
 const custom=emotions.map(value=>value.trim()).filter(value=>value&&!knownAliases.has(value.toLocaleLowerCase('en-US'))).map(label=>({id:label.toLocaleLowerCase('en-US').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,80)||'custom',label,selected:true}));
 return [...known.map(({id,label,selected})=>({id,label,selected})),...custom];
}
export function conditionId(label:string){return label.trim().toLocaleLowerCase('en-US').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'').slice(0,100)||'condition';}
export const phaseLabel=(phase:Shot['phase'])=>phase==='before'?'შესვლამდე':phase==='after'?'გასვლის შემდეგ':'დამატებითი';
export function tradeEmotions(t:Pick<TradeInput,'emotion'|'emotions'>){return t.emotions?.length?[...new Set(t.emotions)]:[t.emotion];}
export function monthSummary(trades:Trade[],month:string){return stats(trades.filter(t=>t.date.startsWith(month+'-')),null);}
export function monthCells(month:string){const first=month+'-01',date=new Date(first+'T00:00:00Z'),count=new Date(Date.UTC(date.getUTCFullYear(),date.getUTCMonth()+1,0)).getUTCDate(),start=shiftDate(first,-date.getUTCDay()),size=Math.ceil((date.getUTCDay()+count)/7)*7;return Array.from({length:size},(_,i)=>shiftDate(start,i));}
export function moveMonth(month:string,direction:number){const d=new Date(month+'-01T00:00:00Z');d.setUTCMonth(d.getUTCMonth()+direction);return d.toISOString().slice(0,7);}

export function accountTrades(trades:Trade[],id:string){return trades.filter(t=>(t.accountId??'default')===id);}
export function groupStrategies(trades:Trade[],strategies:Strategy[]){const groups=new Map<string,{name:string;rows:Trade[]}>();for(const t of trades){const key=t.strategyId??(t.tags.join(', ')||'none');const group=groups.get(key)??{name:strategies.find(s=>s.id===t.strategyId)?.name??t.strategySnapshot?.name??(t.tags.join(', ')||'სტრატეგიის გარეშე'),rows:[]};group.rows.push(t);groups.set(key,group);}return [...groups.values()].map(g=>({name:g.name,...stats(g.rows,null)})).sort((a,b)=>b.pnl-a.pnl);}
