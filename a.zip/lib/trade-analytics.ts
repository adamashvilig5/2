import { conditionId, stats, tradeEmotions, type Trade } from './trading.ts';

export type TradeFilters={start?:string;end?:string;strategy?:string;asset?:string;session?:string;emotion?:string;condition?:string;result?:string;executionQuality?:string};
export type Reliability={label:'Not enough data'|'Early pattern detected'|'Consistent pattern'|'Strong pattern based on your recent data';sampleSize:number;level:0|1|2|3};
export type AnalyticsRow={id:string;label:string;trades:number;wins:number;losses:number;winRate:number|null;netPnl:number;averagePnl:number|null;averageR:number|null;profitFactor:number|null;averageConditionsCompletionRate:number|null;planAdherence:number|null;executionQuality:number|null;sampleSize:number;reliability:Reliability};
export type TradeDataStatus='Complete'|'Partial'|'Awaiting result'|'Awaiting review';
export function tradeDataStatus(trade:Trade):TradeDataStatus{
 if(!Number.isFinite(trade.pnl)||!trade.result)return 'Awaiting result';
 if(!trade.review)return 'Awaiting review';
 if(!trade.strategyId||!trade.selectedEmotionIds?.length||!trade.review.executionChecks.length)return 'Partial';
 return 'Complete';
}

export function sampleReliability(sampleSize:number):Reliability{
 if(sampleSize<5)return {label:'Not enough data',sampleSize,level:0};
 if(sampleSize<10)return {label:'Early pattern detected',sampleSize,level:1};
 if(sampleSize<20)return {label:'Consistent pattern',sampleSize,level:2};
 return {label:'Strong pattern based on your recent data',sampleSize,level:3};
}

function conditions(trade:Trade){
 if(trade.strategyConditions?.length)return trade.strategyConditions;
 const checklist=trade.strategySnapshot?.checklist??[];
 const checked=new Set(trade.strategyChecks??[]);
 return checklist.map((label)=>({id:conditionId(label),label,checked:checked.has(label)}));
}
function quality(trade:Trade){
 if(trade.review?.executionQuality)return trade.review.executionQuality;
 const n=trade.review?.executionChecks.length??0;
 return n>=5?'excellent':n>=4?'good':n>=2?'partial':'needs_review';
}
function emotionIds(trade:Trade){
 const structured=trade.emotionsAtEntry?.filter(item=>item.selected).map(item=>item.id);
 return structured?.length?structured:tradeEmotions(trade).map(label=>label.toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,''));
}

export function getTrades(trades:Trade[],filters:TradeFilters={}){
 return trades.filter((trade)=>{
  if(filters.start&&trade.date<filters.start)return false;
  if(filters.end&&trade.date>filters.end)return false;
  if(filters.strategy&&filters.strategy!=='all'&&(filters.strategy==='__none__'?(trade.strategyId||trade.strategySnapshot):(trade.strategyId!==filters.strategy&&(trade.strategySnapshot?.name??'')!==filters.strategy)))return false;
  if(filters.asset&&filters.asset!=='all'&&trade.symbol!==filters.asset)return false;
  if(filters.session&&filters.session!=='all'&&trade.session!==filters.session)return false;
  if(filters.emotion&&filters.emotion!=='all'&&!emotionIds(trade).includes(filters.emotion))return false;
  if(filters.condition&&filters.condition!=='all'&&!conditions(trade).some((condition)=>condition.id===filters.condition))return false;
  if(filters.result&&filters.result!=='all'&&trade.result!==filters.result)return false;
  if(filters.executionQuality&&filters.executionQuality!=='all'&&quality(trade)!==filters.executionQuality)return false;
  return true;
 }).sort((a,b)=>(a.date+a.entryTime).localeCompare(b.date+b.entryTime));
}

function analyze(label:string,rows:Trade[]):AnalyticsRow{
 const total=stats(rows,null),closed=rows.filter(trade=>Number.isFinite(trade.pnl));
 const winRate=closed.length?closed.filter(trade=>trade.pnl>0).length/closed.length*100:null;
 const profitFactor=total.profitFactor;
 const rValues=closed.filter(trade=>trade.risk>0).map(trade=>trade.rMultiple??trade.pnl/trade.risk);
 const conditionRates=rows.filter(trade=>trade.conditionsTotal!==undefined&&trade.conditionsTotal>0).map(trade=>trade.conditionsCompletionRate??(trade.conditionsMet??0)/trade.conditionsTotal!*100);
 const reviews=rows.filter(trade=>trade.review);
 const adherence=reviews.length?reviews.reduce((sum,trade)=>sum+(trade.review!.planAdherence==='yes'?100:trade.review!.planAdherence==='partial'?50:0),0)/reviews.length:null;
 const qualityScore=reviews.length?reviews.reduce((sum,trade)=>sum+({excellent:100,good:80,partial:55,needs_review:25}[quality(trade)]),0)/reviews.length:null;
 return {id:label,label,trades:rows.length,wins:total.wins,losses:total.losses,winRate,netPnl:total.pnl,averagePnl:closed.length?total.pnl/closed.length:null,averageR:rValues.length?rValues.reduce((sum,value)=>sum+value,0)/rValues.length:null,profitFactor,averageConditionsCompletionRate:conditionRates.length?conditionRates.reduce((sum,value)=>sum+value,0)/conditionRates.length:null,planAdherence:adherence,executionQuality:qualityScore,sampleSize:rows.length,reliability:sampleReliability(rows.length)};
}

export function getTradeStatistics(trades:Trade[],filters:TradeFilters={}){return analyze('All trades',getTrades(trades,filters));}
export function getStrategyStatistics(trades:Trade[],filters:TradeFilters={}){
 const rows=getTrades(trades,filters),groups=new Map<string,Trade[]>();
 for(const trade of rows){const name=trade.strategySnapshot?.name??trade.tags[0]??'No strategy';groups.set(name,[...(groups.get(name)??[]),trade]);}
 return [...groups].map(([name,items])=>analyze(name,items)).sort((a,b)=>b.netPnl-a.netPnl);
}
export function getConditionStatistics(trades:Trade[],filters:TradeFilters={}){
 const rows=getTrades(trades,filters),catalog=new Map<string,{label:string;checked:Trade[];unchecked:Trade[]}>();
 for(const trade of rows){for(const condition of conditions(trade)){const item=catalog.get(condition.id)??{label:condition.label,checked:[],unchecked:[]};item[condition.checked?'checked':'unchecked'].push(trade);catalog.set(condition.id,item);}}
 return [...catalog].map(([id,item])=>({id,label:item.label,checked:analyze(item.label,item.checked),unchecked:analyze(item.label,item.unchecked),checkedCount:item.checked.length,uncheckedCount:item.unchecked.length,reliability:sampleReliability(Math.min(item.checked.length,item.unchecked.length))})).sort((a,b)=>b.checkedCount-a.checkedCount||a.label.localeCompare(b.label));
}
export function getEmotionStatistics(trades:Trade[],filters:TradeFilters={}){
 const rows=getTrades(trades,filters),groups=new Map<string,Trade[]>(),labels=new Map<string,string>();
 for(const trade of rows){for(const emotion of trade.emotionsAtEntry?.filter(item=>item.selected)??tradeEmotions(trade).map((label)=>({id:label.toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,''),label,selected:true}))){groups.set(emotion.id,[...(groups.get(emotion.id)??[]),trade]);labels.set(emotion.id,emotion.label);}}
 return [...groups].map(([id,items])=>({...analyze(labels.get(id)??id,items),id})).sort((a,b)=>b.trades-a.trades||b.netPnl-a.netPnl);
}
export function getStrategyConditionCombinations(trades:Trade[],filters:TradeFilters={}){
 const rows=getTrades(trades,filters),groups=new Map<string,{name:string;rows:Trade[]}>();
 for(const trade of rows){const selected=conditions(trade).filter(item=>item.checked).map(item=>item.label);if(!trade.strategySnapshot||selected.length<2)continue;const labels=selected.slice(0,4).sort(),key=`${trade.strategySnapshot.name} · ${labels.join(' + ')}`;const item=groups.get(key)??{name:key,rows:[]};item.rows.push(trade);groups.set(key,item);}
 return [...groups.values()].map(({name,rows:items})=>analyze(name,items)).filter(item=>item.sampleSize>=5).sort((a,b)=>b.winRate!-a.winRate!).slice(0,12);
}

export type TradingInsight={id:string;title:string;explanation:string;supportingNumbers:string[];sampleSize:number;reliability:Reliability;recommendedAction:string;filter:Partial<TradeFilters>};
export function getTradingInsights(trades:Trade[],filters:TradeFilters={}):TradingInsight[]{
 const rows=getTrades(trades,filters),result:TradingInsight[]=[];
 const add=(id:string,title:string,explanation:string,sourceRows:Trade[],numbers:string[],action:string,filter:Partial<TradeFilters>,confidenceSampleSize=sourceRows.length)=>result.push({id,title,explanation,supportingNumbers:numbers,sampleSize:sourceRows.length,reliability:sampleReliability(confidenceSampleSize),recommendedAction:action,filter});
 const fomo=rows.filter(trade=>emotionIds(trade).includes('fomo')),withoutFomo=rows.filter(trade=>!emotionIds(trade).includes('fomo'));
 if(fomo.length){const fomoWin=fomo.filter(trade=>trade.pnl>0).length/Math.max(1,fomo.length)*100,baseWin=withoutFomo.length?withoutFomo.filter(trade=>trade.pnl>0).length/withoutFomo.length*100:0;add('fomo','FOMO and your execution',`${fomoWin.toFixed(0)}% win rate with FOMO compared with ${baseWin.toFixed(0)}% without it.`,fomo,[`${fomo.length} trades with FOMO`,`${withoutFomo.length} trades without FOMO`,`Win-rate difference ${(fomoWin-baseWin)>=0?'+':''}${(fomoWin-baseWin).toFixed(0)} pts`],'Use your pre-trade reset when FOMO appears.',{emotion:'fomo'},Math.min(fomo.length,withoutFomo.length));}
 for(const item of getConditionStatistics(rows).filter(entry=>entry.checkedCount&&entry.uncheckedCount)){const difference=(item.checked.winRate??0)-(item.unchecked.winRate??0),conditionRows=rows.filter(trade=>conditions(trade).some(condition=>condition.id===item.id));if(Math.abs(difference)>=8)add(`condition:${item.id}`,`${item.label}: possible relationship`,`Win rate was ${(item.checked.winRate??0).toFixed(0)}% when checked and ${(item.unchecked.winRate??0).toFixed(0)}% when not checked.`,conditionRows,[`${item.checkedCount} checked · ${item.uncheckedCount} unchecked`,`Average R when checked ${item.checked.averageR===null?'—':`${item.checked.averageR>=0?'+':''}${item.checked.averageR.toFixed(2)}R`}`],'Review both groups before changing your rules.',{condition:item.id},Math.min(item.checkedCount,item.uncheckedCount));}
 const highReadiness=rows.filter(trade=>(trade.preTradeReadinessScore??trade.review?.readiness??-1)>=75),lowReadiness=rows.filter(trade=>(trade.preTradeReadinessScore??trade.review?.readiness??-1)<75&&(trade.preTradeReadinessScore!==undefined||trade.review?.readiness!==null&&trade.review?.readiness!==undefined));
 if(highReadiness.length&&lowReadiness.length){const rate=(items:Trade[])=>items.filter(item=>item.pnl>0).length/items.length*100;add('readiness','Readiness and results',`Win rate was ${rate(highReadiness).toFixed(0)}% at readiness 75+ and ${rate(lowReadiness).toFixed(0)}% below 75.`,[...highReadiness,...lowReadiness],[`${highReadiness.length} trades at readiness 75+`,`${lowReadiness.length} trades below 75`],'Keep recording readiness and compare the decision quality, not profit alone.',{},Math.min(highReadiness.length,lowReadiness.length));}
 return result;
}

export function getTradeById(trades:Trade[],id:string){return trades.find(trade=>trade.id===id)??null;}
export function getProcessQuality(trade:Trade){
 const conditionScore=trade.conditionsTotal?trade.conditionsCompletionRate??(trade.conditionsMet??0)/trade.conditionsTotal*100:null;
 const review=trade.review,planScore=review?review.planAdherence==='yes'?100:review.planAdherence==='partial'?50:0:null;
 const riskScore=review?review.executionChecks.includes('risk')&&review.executionChecks.includes('stop')?100:review.executionChecks.includes('risk')||review.executionChecks.includes('stop')?50:0:null;
 const noRevenge=review?review.mistakes.includes('revenge')?0:100:null;
 const executionScore=review?(quality(trade)==='excellent'?100:quality(trade)==='good'?80:quality(trade)==='partial'?55:25):null;
 const values=[conditionScore,riskScore,planScore,executionScore,noRevenge,review?100:null].filter((value):value is number=>value!==null);
 return values.length?Math.round(values.reduce((sum,value)=>sum+value,0)/values.length):null;
}
