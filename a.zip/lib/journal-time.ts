export const TIME_PATTERN=/^([01]\d|2[0-3]):[0-5]\d$/;
export type TimeFormat='24h'|'12h';
export function formatJournalTime(value:string,format:TimeFormat){
 if(!TIME_PATTERN.test(value))return value;
 const [hour,minute]=value.split(':').map(Number);
 return format==='24h'?value:`${String(hour%12||12).padStart(2,'0')}:${String(minute).padStart(2,'0')} ${hour<12?'AM':'PM'}`;
}
export function hourFrom12(hour:number,period:'AM'|'PM'){
 if(!Number.isInteger(hour)||hour<1||hour>12)throw new RangeError('Invalid 12-hour time');
 return hour%12+(period==='PM'?12:0);
}
export function replaceTimePart(value:string,part:'hour'|'minute',number:number){
 if(!TIME_PATTERN.test(value)||!Number.isInteger(number)||number<0||number>(part==='hour'?23:59))throw new RangeError('Invalid journal time');
 const [hour,minute]=value.split(':');return part==='hour'?`${String(number).padStart(2,'0')}:${minute}`:`${hour}:${String(number).padStart(2,'0')}`;
}
