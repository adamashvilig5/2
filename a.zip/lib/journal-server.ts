import { journalIdentity } from '@/lib/member-server';
import { getJournalDb } from '@/db';
import { conditionId,structuredEmotionsAtEntry,type Trade,type Shot } from './trading';
export const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store'}});
export const auth=journalIdentity;
export async function body(request:Request){if(Number(request.headers.get('content-length')??0)>32000)throw json({error:'ჩანაწერი ძალიან დიდია.'},413);const raw=await request.text();if(raw.length>32000)throw json({error:'ჩანაწერი ძალიან დიდია.'},413);try{return JSON.parse(raw);}catch{throw json({error:'მონაცემების ფორმატი არასწორია.'},400);}}
export function failure(e:unknown){if(e instanceof Response)return e;if(e instanceof Error&&e.name==='ZodError'){const parsed=JSON.parse(e.message) as {message:string}[];return json({error:parsed[0]?.message??'შეამოწმე შეყვანილი მონაცემები.'},400);}console.error('Journal request failed',e);return json({error:'შენახვა დროებით მიუწვდომელია. მონაცემები შენარჩუნებულია — სცადე ხელახლა.'},503);}
export type TradeRow={id:string;data_json:string;revision:number;created_at:string;updated_at?:string};
export function fromRow(row:TradeRow,screenshots:Shot[]=[]):Trade{
 const stored=JSON.parse(row.data_json) as Trade,emotions=stored.emotions?.length?stored.emotions:[stored.emotion];
 const conditions=stored.strategyConditions??(stored.strategySnapshot?.checklist??[]).map(label=>({id:conditionId(label),label,checked:(stored.strategyChecks??[]).includes(label)}));
 const conditionsMet=stored.conditionsMet??conditions.filter(condition=>condition.checked).length,conditionsTotal=stored.conditionsTotal??conditions.length;
 const emotionsAtEntry=stored.emotionsAtEntry??structuredEmotionsAtEntry(emotions);
 const review=stored.review?{...stored.review,executionQuality:stored.review.executionQuality??(stored.review.executionChecks.length>=5?'excellent':stored.review.executionChecks.length>=4?'good':stored.review.executionChecks.length>=2?'partial':'needs_review')}:undefined;
 return {...stored,strategyConditions:conditions,conditionsMet,conditionsTotal,conditionsCompletionRate:stored.conditionsCompletionRate??(conditionsTotal?Math.round(conditionsMet/conditionsTotal*100):0),emotionsAtEntry,selectedEmotionIds:stored.selectedEmotionIds??emotionsAtEntry.filter(item=>item.selected).map(item=>item.id),rMultiple:stored.rMultiple??stored.pnl/stored.risk,id:row.id,revision:row.revision,createdAt:stored.createdAt??row.created_at,updatedAt:stored.updatedAt??row.updated_at,screenshots,review};
}
export async function findTrade(owner:string,id:string){return getJournalDb().prepare('SELECT id, data_json, revision, created_at, updated_at FROM trades WHERE id = ? AND owner_id = ?').bind(id,owner).first<TradeRow>();}
