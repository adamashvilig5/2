import { EN_MESSAGES } from './journal-messages.ts';
export type JournalLanguage='ka'|'en'|'ru';
export const journalLocale=(_language:JournalLanguage)=>'en-US';
export function translate(source:string,_language:JournalLanguage,values:Record<string,string|number>={}){
 const key=source.trim(),prefix=source.match(/^\s*/)?.[0]??'',suffix=source.match(/\s*$/)?.[0]??'';
 const result=prefix+(EN_MESSAGES[key]??key)+suffix;
 return result.replace(/\{(\w+)\}/g,(token,key)=>Object.hasOwn(values,key)?String(values[key]):token);
}
