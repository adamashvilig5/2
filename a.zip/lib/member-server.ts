import {headers} from 'next/headers';
import {getChatGPTUser} from '@/app/chatgpt-auth';
import {getJournalDb} from '@/db';
import {SITE_OWNER_ID,SESSION_COOKIE,defaultPlan,hasAccess,type Member,type Subscription} from './membership';
export const reply=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export async function gate(request?:Request){if(request){const origin=request.headers.get('origin');if(origin&&origin!==new URL(request.url).origin)throw reply({error:'Invalid request origin.'},403);}const member=await currentMember();if(member)return {userId:member.id,displayName:member.name,email:member.email,fullName:member.name};const user=await getChatGPTUser();if(!user)throw reply({error:'Create an account or sign in to access your trading journal.'},401);return user;}
export async function digest(value:string){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)))).map(n=>n.toString(16).padStart(2,'0')).join('');}
export async function passwordHash(password:string,salt=crypto.randomUUID()){
 const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);
 const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:new TextEncoder().encode(salt),iterations:100000,hash:'SHA-256'},key,256);
 return salt+':'+Array.from(new Uint8Array(bits)).map(n=>n.toString(16).padStart(2,'0')).join('');
}
export async function passwordMatches(password:string,stored:string){const computed=await passwordHash(password,stored.split(':')[0]);let diff=computed.length^stored.length;for(let i=0;i<computed.length;i++)diff|=computed.charCodeAt(i)^(stored.charCodeAt(i)||0);return diff===0;}
export async function hasMemberCookie(){return ((await headers()).get('cookie')??'').split(';').some(s=>s.trim().startsWith(SESSION_COOKIE+'='));}
export async function currentMember(gateId?:string){const cookie=(await headers()).get('cookie')??'',token=cookie.split(';').map(s=>s.trim()).find(s=>s.startsWith(SESSION_COOKIE+'='))?.slice(SESSION_COOKIE.length+1);if(!token)return null;
 const query=gateId?'SELECT m.id,m.email,m.name,m.created_at,m.suspended FROM member_sessions s JOIN members m ON m.id = s.member_id WHERE s.token_hash = ? AND s.gate_id = ? AND s.expires_at > ?':'SELECT m.id,m.email,m.name,m.created_at,m.suspended FROM member_sessions s JOIN members m ON m.id = s.member_id WHERE s.token_hash = ? AND s.expires_at > ?';const values=gateId?[await digest(token),gateId,new Date().toISOString()]:[await digest(token),new Date().toISOString()];const row=await getJournalDb().prepare(query).bind(...values).first<Member>();return row??null;}
export async function subscriptionFor(id:string){return getJournalDb().prepare('SELECT * FROM subscriptions WHERE member_id = ?').bind(id).first<Subscription>();}
export async function getPlan(){const configured=await getJournalDb().prepare("SELECT revision FROM membership_config WHERE id = 'default'").first<{revision:number}>();return {...defaultPlan,revision:configured?.revision??0};}
export async function sessionCookie(memberId:string,gateId=memberId,sameSite:'Strict'|'Lax'='Strict'){const token=crypto.randomUUID()+crypto.randomUUID(),expires=new Date(Date.now()+7*86400000).toISOString();await getJournalDb().prepare('INSERT INTO member_sessions (token_hash,member_id,gate_id,expires_at) VALUES (?, ?, ?, ?)').bind(await digest(token),memberId,gateId,expires).run();return `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=${sameSite}; Max-Age=604800`;}
export async function journalIdentity(request?:Request){const user=await gate(request),member=await currentMember();if(member){if(!hasAccess(member,await subscriptionFor(member.id)))throw reply({error:'Your subscription is inactive. Open Membership to manage access.'},402);return member.id;}
 if(await hasMemberCookie())throw reply({error:'Session expired. Open Membership and sign in again.'},401);
 if(user.userId===SITE_OWNER_ID)return user.userId;throw reply({error:'Create an account or sign in to your journal.'},401);
}
export async function requireAdmin(request?:Request){const user=await gate(request);if(user.userId!==SITE_OWNER_ID||await hasMemberCookie())throw reply({error:'Administrator access required.'},403);return user;}
export async function limitAttempts(request:Request,gateId:string){const db=getJournalDb(),now=Math.floor(Date.now()/900000),key=await digest(gateId+':'+(request.headers.get('cf-connecting-ip')??'private'));
 const row=await db.prepare('INSERT INTO auth_attempts (key,window_start,attempts) VALUES (?, ?, 1) ON CONFLICT(key) DO UPDATE SET attempts = CASE WHEN window_start = excluded.window_start THEN attempts + 1 ELSE 1 END, window_start = excluded.window_start RETURNING attempts').bind(key,now).first<{attempts:number}>();if((row?.attempts??0)>30)throw reply({error:'Too many attempts. Try again in 15 minutes.'},429);
}
