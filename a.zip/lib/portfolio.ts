import { accountTrades,stats,type Account,type Trade } from './trading.ts';
export const ALL_ACCOUNTS='all';
export function accountScope(trades:Trade[],accounts:Account[],selected:string,preferredCurrency='USD'){
 const portfolio=selected===ALL_ACCOUNTS,active=portfolio?undefined:accounts.find(a=>a.id===selected)??accounts[0];
 const currencies=[...new Set(accounts.map(a=>a.currency))];
 const currency=active?.currency??(currencies.includes(preferredCurrency as Account['currency'])?preferredCurrency:currencies[0]??'USD');
 const included=portfolio?accounts.filter(a=>a.currency===currency):active?[active]:[];
 const ids=new Set(included.map(a=>a.id)),rows=trades.filter(t=>ids.has(t.accountId??'default'));
 const missingBalances=included.filter(a=>a.startingBalance===null&&rows.some(t=>(t.accountId??'default')===a.id));
 const known=included.filter(a=>a.startingBalance!==null);
 const startingBalance=missingBalances.length||!known.length?null:known.reduce((sum,a)=>sum+a.startingBalance!,0);
 return {portfolio,active,currency,currencies,accounts:included,trades:rows,startingBalance,missingBalances};
}
export function accountPerformance(trades:Trade[],accounts:Account[],start:string,end:string){
 return accounts.map(account=>{const all=accountTrades(trades,account.id),rows=all.filter(t=>t.date>=start&&t.date<=end),opening=account.startingBalance===null?null:account.startingBalance+all.filter(t=>t.date<start).reduce((sum,t)=>sum+t.pnl,0);return {account,rows,...stats(rows,opening)};});
}
