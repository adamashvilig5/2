import { env } from 'cloudflare:workers';
export function getDecisionDb(): D1Database {
 if (!env.DB) throw new Error('Decision storage is unavailable');
 return env.DB;
}
export const getJournalDb=getDecisionDb;
export function getScreenshotsBucket():R2Bucket {
 if(!env.BUCKET)throw new Error('Screenshot storage is unavailable');
 return env.BUCKET;
}
