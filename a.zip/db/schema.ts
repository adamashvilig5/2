import { sqliteTable, text, integer, index, uniqueIndex, primaryKey } from 'drizzle-orm/sqlite-core';
export const decisions = sqliteTable('decisions', {
 ownerId: text('owner_id').primaryKey(),
 boardJson: text('board_json').notNull(),
 choiceJson: text('choice_json'),
 revision: integer('revision').notNull().default(1),
 updatedAt: text('updated_at').notNull(),
});

export const trades = sqliteTable('trades', {
 id:text('id').primaryKey(),ownerId:text('owner_id').notNull(),tradeDate:text('trade_date').notNull(),dataJson:text('data_json').notNull(),revision:integer('revision').notNull().default(1),createdAt:text('created_at').notNull(),updatedAt:text('updated_at').notNull(),
},t=>[index('idx_trades_owner_date').on(t.ownerId,t.tradeDate)]);
export const screenshots=sqliteTable('screenshots',{
 id:text('id').primaryKey(),ownerId:text('owner_id').notNull(),tradeId:text('trade_id').notNull(),phase:text('phase').notNull(),objectKey:text('object_key').notNull(),filename:text('filename').notNull(),mime:text('mime').notNull(),
},t=>[index('idx_screenshots_owner_trade').on(t.ownerId,t.tradeId)]);
export const journalSettings=sqliteTable('journal_settings',{
 ownerId:text('owner_id').primaryKey(),dataJson:text('data_json').notNull(),revision:integer('revision').notNull().default(1),
});
export const dailyNotes=sqliteTable('daily_notes',{
 ownerId:text('owner_id').notNull(),date:text('date').notNull(),dataJson:text('data_json').notNull(),revision:integer('revision').notNull().default(1),
},t=>[primaryKey({columns:[t.ownerId,t.date]})]);
export const tradingAccounts=sqliteTable('trading_accounts',{
 ownerId:text('owner_id').notNull(),id:text('id').notNull(),dataJson:text('data_json').notNull(),revision:integer('revision').notNull().default(1),archived:integer('archived').notNull().default(0),createdAt:text('created_at').notNull(),
},t=>[primaryKey({columns:[t.ownerId,t.id]})]);
export const tradingStrategies=sqliteTable('trading_strategies',{
 ownerId:text('owner_id').notNull(),id:text('id').notNull(),dataJson:text('data_json').notNull(),revision:integer('revision').notNull().default(1),archived:integer('archived').notNull().default(0),createdAt:text('created_at').notNull(),
},t=>[primaryKey({columns:[t.ownerId,t.id]})]);
export const achievementAwards=sqliteTable('achievement_awards',{
 ownerId:text('owner_id').notNull(),achievementId:text('achievement_id').notNull(),xp:integer('xp').notNull(),earnedAt:text('earned_at').notNull(),
},t=>[primaryKey({columns:[t.ownerId,t.achievementId]})]);
export const innerSpaceEntries=sqliteTable('inner_space_entries',{
 ownerId:text('owner_id').notNull(),date:text('date').notNull(),dataJson:text('data_json').notNull(),revision:integer('revision').notNull().default(1),
},t=>[primaryKey({columns:[t.ownerId,t.date]})]);

export const members=sqliteTable('members',{
 id:text('id').primaryKey(),email:text('email').notNull().unique(),name:text('name').notNull(),passwordHash:text('password_hash').notNull(),createdAt:text('created_at').notNull(),suspended:integer('suspended').notNull().default(0),
});
export const memberSessions=sqliteTable('member_sessions',{
 tokenHash:text('token_hash').primaryKey(),memberId:text('member_id').notNull(),gateId:text('gate_id').notNull(),expiresAt:text('expires_at').notNull(),
},t=>[index('idx_sessions_member').on(t.memberId)]);
export const subscriptions=sqliteTable('subscriptions',{
 memberId:text('member_id').primaryKey(),status:text('status').notNull(),periodEnd:text('period_end').notNull(),cancelAtEnd:integer('cancel_at_end').notNull().default(0),priceCents:integer('price_cents').notNull(),revision:integer('revision').notNull().default(1),
});
export const billingEvents=sqliteTable('billing_events',{
 id:text('id').primaryKey(),memberId:text('member_id').notNull(),kind:text('kind').notNull(),amountCents:integer('amount_cents').notNull(),createdAt:text('created_at').notNull(),
},t=>[index('idx_billing_member').on(t.memberId)]);
export const membershipConfig=sqliteTable('membership_config',{
 id:text('id').primaryKey(),priceCents:integer('price_cents').notNull(),trialDays:integer('trial_days').notNull(),revision:integer('revision').notNull().default(1),
});
export const authAttempts=sqliteTable('auth_attempts',{
 key:text('key').primaryKey(),windowStart:integer('window_start').notNull(),attempts:integer('attempts').notNull(),
});
export const passwordResetTokens=sqliteTable('password_reset_tokens',{
 tokenHash:text('token_hash').primaryKey(),memberId:text('member_id').notNull(),expiresAt:text('expires_at').notNull(),createdAt:text('created_at').notNull(),
},t=>[index('idx_password_reset_member').on(t.memberId)]);
