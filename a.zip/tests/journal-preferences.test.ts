import test from 'node:test';
import assert from 'node:assert/strict';
import { replaceTimePart,TIME_PATTERN,formatJournalTime,hourFrom12 } from '../lib/journal-time.ts';
import { ICT_CONDITIONS,addICTCondition,hasICTCondition } from '../lib/ict-checklist.ts';
import { translate } from '../lib/journal-language.ts';
import { ACHIEVEMENTS,LEVEL_RANKS,levelThreshold,levelForXp } from '../lib/achievements.ts';
import { strategySchema,tradeSchema } from '../lib/trading.ts';

test('24-hour time selection supports every minute, midnight, and overnight exits',()=>{
 for(let hour=0;hour<24;hour++)for(let minute=0;minute<60;minute++){
  const time=replaceTimePart(replaceTimePart('09:30','hour',hour),'minute',minute);
  assert.match(time,TIME_PATTERN);assert.equal(time,`${String(hour).padStart(2,'0')}:${String(minute).padStart(2,'0')}`);
 }
 assert.equal(replaceTimePart('23:59','hour',0),'00:59');assert.equal(replaceTimePart('23:59','minute',0),'23:00');
 for(const bad of ['24:00','09:60','9:30',''])assert.throws(()=>replaceTimePart(bad,'hour',1));
 assert.throws(()=>replaceTimePart('09:30','minute',60));assert.throws(()=>replaceTimePart('09:30','hour',-1));
 const parsed=tradeSchema.safeParse({id:crypto.randomUUID(),revision:0,accountId:'default',symbol:'MNQ',side:'Buy',result:'Win',quantity:1,pnl:100,risk:50,date:'2026-10-01',entryTime:'23:59',exitTime:'00:01',session:'New York',emotion:'დისციპლინა',emotions:['დისციპლინა'],strategyChecks:[],tags:[],notes:''});
 assert.ok(parsed.success);
});

test('12-hour display and selection round-trip every time without shifting noon or midnight',()=>{
 for(let h=0;h<24;h++)for(let m=0;m<60;m++){
  const value=`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
  const display=formatJournalTime(value,'12h'),[clock,period]=display.split(' '),[hour,minute]=clock.split(':').map(Number);
  assert.equal(replaceTimePart(replaceTimePart(value,'hour',hourFrom12(hour,period as 'AM'|'PM')),'minute',minute),value);
  assert.equal(formatJournalTime(value,'24h'),value);
 }
 assert.equal(formatJournalTime('00:00','12h'),'12:00 AM');
 assert.equal(formatJournalTime('12:00','12h'),'12:00 PM');
 assert.equal(formatJournalTime('23:59','12h'),'11:59 PM');
 assert.equal(hourFrom12(12,'AM'),0);assert.equal(hourFrom12(12,'PM'),12);
});

test('ICT ideas add editable conditions without replacing user rules or duplicating across languages',()=>{
 assert.equal(ICT_CONDITIONS.length,24);assert.equal(new Set(ICT_CONDITIONS.map(c=>c.id)).size,24);
 const own=['My own risk rule'],first=addICTCondition(own,'fvg','ka'),same=addICTCondition(first,'fvg','en');
 assert.deepEqual(own,['My own risk rule']);assert.strictEqual(same,first);assert.equal(first[0],own[0]);assert.ok(hasICTCondition(first,ICT_CONDITIONS.find(c=>c.id==='fvg')!));
 for(const language of ['ka','en'] as const){const checklist=ICT_CONDITIONS.slice(0,16).reduce((list,c)=>addICTCondition(list,c.id,language),[] as string[]);assert.ok(strategySchema.safeParse({id:crypto.randomUUID(),revision:0,name:'My ICT plan',description:'',checklist}).success);assert.throws(()=>addICTCondition(checklist,ICT_CONDITIONS[16].id,language));}
 assert.throws(()=>addICTCondition([],'unknown','ka'));
});

test('localization covers all achievements and ranks without changing XP or user content',()=>{
 for(const achievement of ACHIEVEMENTS){assert.ok(!/[\u10a0-\u10ff]/.test(translate(achievement.title,'en')));assert.ok(!/[\u10a0-\u10ff]/.test(translate(achievement.description,'en')));}
 for(const rank of LEVEL_RANKS){assert.ok(!/[\u10a0-\u10ff]/.test(translate(rank.title,'en')));assert.equal(levelForXp(levelThreshold(rank.from)).title,rank.title);}
 assert.equal(translate(' ბოლო {v0} დღე ','en',{v0:30}),' Last 30 days ');
 assert.equal(translate('Entry Time','ka'),'შესვლის დრო');assert.equal(translate('დისციპლინა','en'),'Discipline');
 assert.equal(translate('My own MNQ strategy','en'),'My own MNQ strategy');
 assert.equal(translate('რეკრუტი','en'),'Recruit');assert.equal(translate('Recruit','ka'),'რეკრუტი');
});
