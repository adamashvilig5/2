import {memberTestCookie} from './member-test-fixture.ts';
import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFileSync,realpathSync,readdirSync} from 'node:fs';
import {resolve} from 'node:path';
const require=createRequire(realpathSync('node_modules/wrangler/package.json'));
const {Miniflare}=require('miniflare');
test('permanent account deletion removes only its records and files, prevents restoration, and supports safe retry',async()=>{
 const mf=new Miniflare({modulesRoot:resolve('dist/server'),modules:[{type:'ESModule',path:resolve('dist/server/index.js')},...readdirSync('dist/server',{recursive:true}).filter((f):f is string=>typeof f==='string'&&f!=='index.js'&&/\.(m?js)$/.test(f)).map(f=>({type:'ESModule',path:resolve('dist/server',f)}))],compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],r2Buckets:['BUCKET']});
 try{
  const db=await mf.getD1Database('DB');
  for(const path of readdirSync('drizzle').filter(p=>p.endsWith('.sql')).sort())for(const sql of readFileSync('drizzle/'+path,'utf8').split('--> statement-breakpoint').filter(s=>s.trim()))await db.prepare(sql).run();
  const call=async(path:string,method='GET',body?:unknown,owner='owner-a',origin?:string)=>{
   const headers:Record<string,string>={'Content-Type':'application/json'};
   if(owner){headers.cookie=await memberTestCookie(db,owner);headers['oai-authenticated-user-id']=owner;headers['oai-authenticated-user-email']=owner+'@example.com';}
   if(origin)headers.origin=origin;
   const response=await mf.dispatchFetch('https://journal.example'+path,{method,headers,...(body?{body:JSON.stringify(body)}:{})});
   return {status:response.status,data:await response.json() as any};
  };

  const account={id:crypto.randomUUID(),revision:0,name:'Delete me',type:'Challenge',currency:'USD',startingBalance:50000,description:''};
  assert.equal((await call('/api/accounts','POST',account)).status,200);
  const otherAccount={...account,id:crypto.randomUUID(),name:'Keep me'};
  assert.equal((await call('/api/accounts','POST',otherAccount)).status,200);
  const trade={id:crypto.randomUUID(),revision:0,accountId:account.id,symbol:'MNQ',side:'Buy',result:'Win',quantity:1,pnl:100,risk:50,date:'2026-10-01',entryTime:'09:30',exitTime:'10:00',session:'New York',emotion:'დისციპლინა',emotions:['დისციპლინა'],strategyChecks:[],tags:[],notes:''};
  assert.equal((await call('/api/trades','POST',trade)).status,200);
  const kept={...trade,id:crypto.randomUUID(),accountId:otherAccount.id};
  assert.equal((await call('/api/trades','POST',kept)).status,200);
  const bucket=await mf.getR2Bucket('BUCKET');
  for(const [row,key] of [[trade,'remove.png'],[kept,'keep.png']] as const){
   await bucket.put(key,'picture');
   await db.prepare('INSERT INTO screenshots (id,owner_id,trade_id,phase,object_key,filename,mime) VALUES (?, ?, ?, ?, ?, ?, ?)').bind(crypto.randomUUID(),'owner-a',row.id,'before',key,key,'image/png').run();
  }
  const url='/api/accounts/'+account.id+'/purge';
  assert.equal((await call(url,'POST',{revision:1,confirm:true})).status,409); // Active accounts cannot be purged.
  assert.equal((await call('/api/accounts/'+account.id,'DELETE',{revision:1})).status,200);
  assert.equal((await call(url,'POST',{revision:2,confirm:true},'')).status,401);
  assert.equal((await call(url,'POST',{revision:2,confirm:true},'owner-b')).status,409);
  assert.equal((await call(url,'POST',{revision:2,confirm:true},'owner-a','https://other.example')).status,403);
  assert.equal((await call(url,'POST',{revision:2})).status,400);
  assert.equal((await call(url,'POST',{revision:1,confirm:true})).status,409);
  assert.equal((await bucket.list()).objects.length,2);
  assert.equal((await call(url,'POST',{revision:2,confirm:true})).status,200);
  assert.equal(await bucket.get('remove.png'),null);assert.ok(await bucket.get('keep.png'));
  const journal=(await call('/api/journal?date=2026-10-01')).data;
  assert.equal(journal.archivedAccounts.some((a:any)=>a.id===account.id),false);
  assert.equal(journal.accounts.some((a:any)=>a.id===account.id),false);
  assert.equal(journal.trades.some((t:any)=>t.id===trade.id),false);
  assert.equal(journal.trades.find((t:any)=>t.id===kept.id).screenshots.length,1);
  assert.equal((await call(url,'POST',{revision:2,confirm:true})).status,200); // A lost response can be retried.
  assert.equal((await call('/api/accounts/'+account.id,'PATCH',{revision:4})).status,409);
  assert.equal((await call('/api/accounts','POST',account)).status,409);
  // Default-account deletion leaves no synthetic account after a reload, including legacy trades without accountId.
  const legacy={...trade,id:crypto.randomUUID(),accountId:undefined};
  assert.equal((await call('/api/trades','POST',legacy)).status,200);
  assert.equal((await call('/api/accounts/default','DELETE',{revision:0})).status,200);
  // Simulate retry after storage cleanup was interrupted; restore must remain locked.
  await db.prepare("UPDATE trading_accounts SET archived = 2, revision = 2 WHERE owner_id = 'owner-a' AND id = 'default'").run();
  assert.equal((await call('/api/accounts/default','PATCH',{revision:2})).status,409);
  assert.equal((await call('/api/accounts/default/purge','POST',{revision:1,confirm:true})).status,200);
  const final=(await call('/api/journal?date=2026-10-01')).data;
  assert.deepEqual(final.accounts.map((a:any)=>a.id),[otherAccount.id]);assert.deepEqual(final.archivedAccounts,[]);
  assert.deepEqual(final.trades.map((t:any)=>t.id),[kept.id]);
  assert.equal((await call('/api/journal?date=2026-10-01','GET',undefined,'owner-b')).data.accounts[0].id,'default');
 }finally{await mf.dispose();}
});
