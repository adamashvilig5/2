import {memberTestCookie} from './member-test-fixture.ts';
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync,realpathSync,readdirSync } from 'node:fs';
import { resolve } from 'node:path';
const require=createRequire(realpathSync('node_modules/wrangler/package.json'));
const {Miniflare}=require('miniflare');
test('production achievements award XP once from private saved evidence and survive deletion',async()=>{
 const mf=new Miniflare({modulesRoot:resolve('dist/server'),modules:[{type:'ESModule',path:resolve('dist/server/index.js')},...readdirSync('dist/server',{recursive:true}).filter((f):f is string=>typeof f==='string'&&f!=='index.js'&&/\.(m?js)$/.test(f)).map(f=>({type:'ESModule',path:resolve('dist/server',f)}))],compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],r2Buckets:['BUCKET']});
 try{
  const db=await mf.getD1Database('DB');for(const path of readdirSync('drizzle').filter(p=>p.endsWith('.sql')).sort())for(const sql of readFileSync('drizzle/'+path,'utf8').split('--> statement-breakpoint').filter(s=>s.trim()))await db.prepare(sql).run();
  const call=async(path:string,method='POST',body?:unknown,owner='owner-a',origin?:string)=>{const headers:Record<string,string>={};if(owner){headers.cookie=await memberTestCookie(db,owner);headers['oai-authenticated-user-id']=owner;headers['oai-authenticated-user-email']=owner+'@example.com';}if(origin)headers.origin=origin;let encodedBody:any=body?JSON.stringify(body):undefined;if(body instanceof FormData){const native=new Request('https://journal.example'+path,{method,body});headers['Content-Type']=native.headers.get('Content-Type')!;encodedBody=await native.arrayBuffer();}else if(body)headers['Content-Type']='application/json';const res=await mf.dispatchFetch('https://journal.example'+path,{method,headers,...(body?{body:encodedBody}:{})});return {status:res.status,data:await res.json() as any};};
  assert.equal((await call('/api/achievements','POST',undefined,'')).status,401);assert.equal((await call('/api/achievements','POST',undefined,'owner-a','https://evil.example')).status,403);
  const empty=await call('/api/achievements');assert.equal(empty.status,200);assert.equal(empty.data.progress.total,48);assert.equal(empty.data.progress.level.xp,0);
  assert.equal((await call('/api/achievements','POST',{xp:1000000,earned:['first-entry']})).data.progress.level.xp,0);
  const trade={id:crypto.randomUUID(),revision:0,accountId:'default',symbol:'MNQ',side:'Buy',result:'Win',quantity:1,pnl:100,risk:100,date:'2026-09-30',entryTime:'09:30',exitTime:'10:00',session:'New York',emotion:'დისციპლინა',emotions:['დისციპლინა','მოთმინება'],tags:[],notes:'I waited for my confirmation and followed my plan.'};
  assert.equal((await call('/api/trades','POST',trade)).status,200);
  const concurrent=await Promise.all([call('/api/achievements'),call('/api/achievements'),call('/api/achievements')]);assert.ok(concurrent.every(r=>r.status===200));
  assert.equal(concurrent.reduce((sum,r)=>sum+r.data.newAwards.filter((a:any)=>a.id==='first-entry').length,0),1);
  let progress=(await call('/api/achievements')).data.progress;assert.equal(progress.level.xp,250);assert.equal(progress.level.level,2);assert.equal(progress.awards.length,3);
  assert.equal((await call('/api/achievements','POST',undefined,'owner-b')).data.progress.level.xp,0);
  assert.equal((await call('/api/trades','POST',{...trade,revision:1,pnl:125})).status,200);assert.equal((await call('/api/achievements')).data.progress.level.xp,250);
  const strategy={id:crypto.randomUUID(),revision:0,name:'My own checklist',description:'',checklist:['Confirmation','Risk fixed']};assert.equal((await call('/api/strategies','POST',strategy)).status,200);
  assert.equal((await call('/api/trades','POST',{...trade,revision:2,strategyId:strategy.id,strategyChecks:strategy.checklist})).status,200);
  progress=(await call('/api/achievements')).data.progress;assert.equal(progress.level.xp,600);assert.equal(progress.metrics.completePlans,1);
  const daily={date:'2026-09-30',revision:0,note:'Today I will keep my risk fixed and wait for confirmation.',rules:[{label:'Respect risk',checked:true},{label:'Wait for setup',checked:true}]};assert.equal((await call('/api/daily','PUT',daily)).status,200);
  progress=(await call('/api/achievements')).data.progress;assert.equal(progress.level.xp,850);assert.equal(progress.level.level,3);assert.equal(progress.metrics.goalsDone,1);
  const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jWZkAAAAASUVORK5CYII=','base64');
  for(const phase of ['before','after']){const form=new FormData();form.set('tradeId',trade.id);form.set('phase',phase);form.set('file',new File([png],phase+'.png',{type:'image/png'}));assert.equal((await call('/api/screenshots','POST',form)).status,200);}
  const photos=await call('/api/achievements');assert.equal(photos.data.progress.level.xp,1100);assert.equal(photos.data.progress.metrics.comparisons,1);
  assert.equal((await call('/api/trades','POST',{...trade,revision:3,strategyId:strategy.id,strategyChecks:strategy.checklist,notes:'A detailed explanation of my entry, planned risk, exit and emotional state. '.repeat(3)})).status,200);
  const full=await call('/api/achievements');assert.equal(full.data.progress.level.xp,1475);assert.equal(full.data.progress.metrics.fullReviews,1);assert.ok(full.data.newAwards.some((a:any)=>a.id==='first-full-review'));
  assert.deepEqual((await call('/api/achievements')).data.newAwards,[]);
  assert.equal((await call('/api/accounts/default','DELETE',{revision:0})).status,200);assert.equal((await call('/api/achievements')).data.progress.level.xp,1475);
  assert.equal((await call('/api/trades/'+trade.id,'DELETE')).status,200);
  const retained=await call('/api/achievements');assert.equal(retained.data.progress.level.xp,1475);assert.equal(retained.data.progress.items.find((a:any)=>a.id==='first-photo').percent,100);assert.equal(retained.data.progress.items.find((a:any)=>a.id==='first-full-review').percent,100);assert.deepEqual(retained.data.newAwards,[]);
  assert.equal((await call('/api/accounts/default','PATCH',{revision:1})).status,200);assert.equal((await call('/api/achievements')).data.progress.level.xp,1475);
  const ledger=await db.prepare('SELECT owner_id, achievement_id, COUNT(*) AS count FROM achievement_awards GROUP BY owner_id, achievement_id').all();assert.ok(ledger.results.every((r:any)=>r.count===1));assert.ok(ledger.results.every((r:any)=>r.owner_id==='owner-a'));
 }finally{await mf.dispose();}
});
