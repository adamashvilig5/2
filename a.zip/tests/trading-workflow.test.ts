import {memberTestCookie} from './member-test-fixture.ts';
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync,realpathSync,readdirSync } from 'node:fs';
import { resolve } from 'node:path';
const require=createRequire(realpathSync('node_modules/wrangler/package.json'));
const {Miniflare}=require('miniflare');
test('production journal: create, edit, private screenshots, notes, settings, conflicts and deletion',async()=>{
 const mf=new Miniflare({modulesRoot:resolve('dist/server'),modules:[{type:'ESModule',path:resolve('dist/server/index.js')},...readdirSync('dist/server',{recursive:true}).filter((f):f is string=>typeof f==='string'&&f!=='index.js'&&/\.(m?js)$/.test(f)).map(f=>({type:'ESModule',path:resolve('dist/server',f)}))],compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],r2Buckets:['BUCKET']});
 try{
  const db=await mf.getD1Database('DB');
  for(const path of readdirSync('drizzle').filter(p=>p.endsWith('.sql')).sort())for(const sql of readFileSync('drizzle/'+path,'utf8').split('--> statement-breakpoint').filter(s=>s.trim()))await db.prepare(sql).run();
  const call=async(path:string,method='GET',body?:unknown,owner='journal-owner')=>{
   const headers:Record<string,string>={};if(owner){headers.cookie=await memberTestCookie(db,owner);headers['oai-authenticated-user-id']=owner;headers['oai-authenticated-user-email']=owner+'@example.com';}
   let encodedBody:any=body?JSON.stringify(body):undefined;
   if(body instanceof FormData){const native=new Request('https://journal.example'+path,{method,body});headers['Content-Type']=native.headers.get('Content-Type')!;encodedBody=await native.arrayBuffer();}else if(body)headers['Content-Type']='application/json';
   const res=await mf.dispatchFetch('https://journal.example'+path,{method,headers,...(body?{body:encodedBody}:{})});
   return {res,status:res.status,data:res.headers.get('Content-Type')?.includes('application/json')?await res.json() as any:null};
  };
  const url='/api/journal?date=2026-10-01';assert.equal((await call(url,'GET',undefined,'')).status,401);
  const initial=await call(url);assert.equal(initial.status,200);assert.equal(initial.data.trades.length,0);assert.equal(initial.data.settings.startingBalance,null);
  const settings=await call('/api/settings','PUT',{startingBalance:25000,timezone:'Asia/Tbilisi',revision:0});assert.equal(settings.status,200);
  const trade={id:crypto.randomUUID(),revision:0,symbol:'mnq',side:'Buy',result:'Win',quantity:100,pnl:550,risk:100,date:'2026-10-01',entryTime:'09:30',exitTime:'16:00',session:'New York',emotion:'დისციპლინა',emotions:['დისციპლინა','მოთმინება'],strategyChecks:['Entry confirmation','Risk within plan'],tags:['Breakout'],notes:'Followed the plan.'};
  const saved=await call('/api/trades','POST',trade);assert.equal(saved.status,200);assert.equal(saved.data.trade.symbol,'MNQ');assert.equal(saved.data.trade.revision,1);
  assert.equal((await call('/api/trades','POST',trade)).status,409);
  assert.equal((await call('/api/trades','POST',{...trade,id:crypto.randomUUID(),risk:0})).status,400);
  assert.equal((await call('/api/trades','POST',{...trade,id:crypto.randomUUID(),pnl:-10})).status,400);
  const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jWZkAAAAASUVORK5CYII=','base64');
  const upload=async(phase:string,bytes:Uint8Array=png,owner='journal-owner')=>{const fd=new FormData();fd.set('tradeId',trade.id);fd.set('phase',phase);fd.set('file',new File([new Uint8Array(bytes).buffer],'chart.png',{type:'image/png'}));return call('/api/screenshots','POST',fd,owner);};
  assert.equal((await upload('before',png,'other-owner')).status,404);
  const before=await upload('before'),after=await upload('after');assert.equal(before.status,200);assert.equal(after.status,200);
  const imageUrl='/api/screenshots/'+before.data.screenshot.id;
  assert.equal((await call(imageUrl,'GET',undefined,'other-owner')).status,404);
  const image=await call(imageUrl);assert.equal(image.status,200);assert.equal(image.res.headers.get('Content-Type'),'image/png');assert.match(image.res.headers.get('Cache-Control')!,/no-store/);assert.deepEqual(Buffer.from(await image.res.arrayBuffer()),png);
  assert.equal((await upload('after',new TextEncoder().encode('<script>alert(1)</script>'))).status,400);
  assert.equal((await upload('after',new Uint8Array(8*1024*1024+1))).status,413);
  const replace=await upload('before');assert.equal(replace.status,200);assert.equal((await call(imageUrl)).status,200);
  assert.equal((await upload('context')).status,200);assert.equal((await upload('after')).status,200);
  const bucket=await mf.getR2Bucket('BUCKET');assert.equal((await bucket.list()).objects.length,5);
  const daily=await call('/api/daily','PUT',{date:'2026-10-01',note:'Risk <= $100. Wait for my setup.',rules:[{label:'Respect risk',checked:true}],revision:0});assert.equal(daily.status,200);
  const reloaded=await call(url);assert.equal(reloaded.data.trades.length,1);assert.equal(reloaded.data.trades[0].screenshots.length,5);assert.deepEqual(reloaded.data.trades[0].emotions,['დისციპლინა','მოთმინება']);assert.equal(reloaded.data.trades[0].strategyChecks.length,2);assert.equal(reloaded.data.settings.startingBalance,25000);assert.equal(reloaded.data.daily.rules[0].checked,true);
  const other=await call(url,'GET',undefined,'other-owner');assert.equal(other.data.trades.length,0);assert.equal(other.data.daily.note,'');assert.equal(other.data.settings.startingBalance,null);
  const edit={...trade,revision:1,pnl:250};const concurrent=await Promise.all([call('/api/trades','POST',edit),call('/api/trades','POST',edit)]);assert.deepEqual(concurrent.map(r=>r.status).sort(),[200,409]);
  const updated=await call(url);assert.equal(updated.data.trades[0].pnl,250);assert.equal(updated.data.trades[0].screenshots.length,5);
  const retryId=crypto.randomUUID();const retryPhoto=async()=>{const fd=new FormData();fd.set('tradeId',trade.id);fd.set('phase','context');fd.set('id',retryId);fd.set('file',new File([png],'clipboard.png',{type:'image/png'}));return call('/api/screenshots','POST',fd);};
  const firstRetry=await retryPhoto(),secondRetry=await retryPhoto();assert.equal(firstRetry.status,200);assert.equal(secondRetry.data.screenshot.id,firstRetry.data.screenshot.id);assert.equal((await bucket.list()).objects.length,6);
  for(let i=0;i<4;i++)assert.equal((await upload('context')).status,200);
  assert.equal((await upload('context')).status,409);assert.equal((await bucket.list()).objects.length,10);
  assert.equal((await call('/api/screenshots/'+retryId,'DELETE',undefined,'other-owner')).status,404);
  assert.equal((await call('/api/screenshots/'+retryId,'DELETE')).status,200);assert.equal((await bucket.list()).objects.length,9);
  assert.equal((await upload('before')).status,200);
  assert.equal((await call('/api/trades/'+trade.id,'DELETE',undefined,'other-owner')).status,404);
  assert.equal((await call('/api/trades/'+trade.id,'DELETE')).status,200);assert.equal((await call(url)).data.trades.length,0);assert.equal((await bucket.list()).objects.length,0);
  const planQuery=await db.prepare('EXPLAIN QUERY PLAN SELECT id FROM trades WHERE owner_id = ? ORDER BY trade_date').bind('journal-owner').all();assert.match(JSON.stringify(planQuery),/idx_trades_owner_date/);
 }finally{await mf.dispose();}
});
