import {SITE_OWNER_ID} from '../lib/membership.ts';
import {memberTestCookie} from './member-test-fixture.ts';
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync, realpathSync, readdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { exampleBoard, emptyBoard } from '../lib/decision.ts';
const require=createRequire(realpathSync('node_modules/wrangler/package.json'));
const { Miniflare }=require('miniflare');
test('production Worker: private records, scoring, persisted choice, validation and conflicts',async()=>{
 const mf=new Miniflare({modulesRoot:resolve('dist/server'),modules:[{type:'ESModule',path:resolve('dist/server/index.js')},...readdirSync('dist/server',{recursive:true}).filter(f=>typeof f==='string'&&f!=='index.js'&&/\.(m?js)$/.test(f)).map(f=>({type:'ESModule',path:resolve('dist/server',f as string)}))],compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:['DB']});
 try{
  const db=await mf.getD1Database('DB');for(const file of readdirSync('drizzle').filter(p=>p.endsWith('.sql')).sort())for(const sql of readFileSync('drizzle/'+file,'utf8').split('--> statement-breakpoint').filter(s=>s.trim()))await db.prepare(sql).run();
  const request=async(method:string,body?:unknown,owner='test-owner',origin?:string)=>{
   const headers:Record<string,string>={'Content-Type':'application/json'};
   if(owner){headers.cookie=await memberTestCookie(db,owner);headers['oai-authenticated-user-id']=owner;headers['oai-authenticated-user-email']=owner+'@example.com';}
   if(origin)headers.Origin=origin;
   const response=await mf.dispatchFetch('https://board.example/api/board',{method,headers,...(body?{body:JSON.stringify(body)}:{})});
   return {status:response.status,data:await response.json() as any};
  };
  assert.equal((await request('GET',undefined,'')).status,401);
  assert.deepEqual((await request('GET')).data,{board:null,choice:null,revision:0});
  assert.equal((await request('PUT',{board:emptyBoard,revision:0,preferredOptionId:'o1',rationale:''})).status,400);
  assert.equal((await request('PUT',{board:exampleBoard,revision:0},'test-owner','https://other.example')).status,403);
  const saved=await request('PUT',{board:exampleBoard,revision:0});assert.equal(saved.status,200);assert.equal(saved.data.revision,1);
  const chosen=await request('PUT',{board:exampleBoard,revision:1,preferredOptionId:'o2',rationale:'Focus matters more than cost.'});
  assert.equal(chosen.status,200);assert.equal(chosen.data.choice.optionName,'Coworking space');assert.equal(chosen.data.choice.score,7.15);
  const reloaded=await request('GET');assert.deepEqual(reloaded.data.board,exampleBoard);assert.equal(reloaded.data.choice.rationale,'Focus matters more than cost.');
  assert.deepEqual((await request('GET',undefined,'other-owner')).data,{board:null,choice:null,revision:0});
  const edited=structuredClone(exampleBoard);edited.criteria[0].weight=0;
  const results=await Promise.all([request('PUT',{board:edited,revision:2}),request('PUT',{board:edited,revision:2})]);
  assert.deepEqual(results.map(r=>r.status).sort(),[200,409]);
  const latest=await request('GET');assert.equal(latest.data.revision,3);assert.equal(latest.data.choice.snapshot.criteria[0].weight,40);assert.equal(latest.data.board.criteria[0].weight,0);
  const invalid=structuredClone(exampleBoard);invalid.options[0].scores.c1=11;
  assert.equal((await request('PUT',{board:invalid,revision:3})).status,400);
  const guest=await mf.dispatchFetch('https://board.example/',{redirect:'manual'});assert.equal(guest.status,307);assert.equal(guest.headers.get('location'),'/membership');
  const html=await mf.dispatchFetch('https://board.example/',{headers:{'oai-authenticated-user-id':SITE_OWNER_ID,'oai-authenticated-user-email':'owner@example.com'}});assert.equal(html.status,200);const content=await html.text();assert.match(content,/Trade Journal/);assert.match(content,/ჟურნალი იტვირთება/);
 }finally{await mf.dispose();}
});
