import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFileSync,realpathSync,readdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {SITE_OWNER_ID} from '../lib/membership.ts';

const require=createRequire(realpathSync('node_modules/wrangler/package.json'));
const {Miniflare}=require('miniflare');

test('new accounts choose Demo or fixed-price Pro, and Demo trade limit cannot be reset by deleting its trade',async()=>{
 const mf=new Miniflare({modulesRoot:resolve('dist/server'),modules:[{type:'ESModule',path:resolve('dist/server/index.js')},...readdirSync('dist/server',{recursive:true}).filter((file):file is string=>typeof file==='string'&&file!=='index.js'&&/\.(m?js)$/.test(file)).map(file=>({type:'ESModule',path:resolve('dist/server',file)}))],compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],r2Buckets:['BUCKET']});
 try{
  const db=await mf.getD1Database('DB');
  for(const file of readdirSync('drizzle').filter((name:string)=>name.endsWith('.sql')).sort())for(const sql of readFileSync('drizzle/'+file,'utf8').split('--> statement-breakpoint').filter(statement=>statement.trim()))await db.prepare(sql).run();
  const call=async(path:string,body?:unknown,cookie='',method=body?'POST':'GET')=>{
   const headers:Record<string,string>={'Content-Type':'application/json',cookie,'oai-authenticated-user-id':SITE_OWNER_ID,'oai-authenticated-user-email':SITE_OWNER_ID+'@example.com'};
   const response=await mf.dispatchFetch('https://journal.example'+path,{method,headers,...(body?{body:JSON.stringify(body)}:{})});
   return {status:response.status,data:await response.json() as {error?:string;code?:string;member?:{id:string};subscription?:{status:string;price_cents:number;revision:number}|null;access?:boolean;plan?:{price_cents:number;trial_days:number;currency?:string}},cookie:response.headers.get('set-cookie')??''};
  };
  const signup=await call('/api/membership',{action:'register',email:'demo@example.com',password:'a-long-test-password',name:'Demo User'});
  assert.equal(signup.status,200);
  const cookie=signup.cookie.split(';')[0];
  const fresh=await call('/api/membership',undefined,cookie);
  assert.equal(fresh.data.access,false);assert.equal(fresh.data.subscription,null);assert.equal(fresh.data.plan?.price_cents,2000);assert.equal(fresh.data.plan?.trial_days,0);assert.equal(fresh.data.plan?.currency,'USD');
  assert.equal((await call('/api/membership',{action:'select_plan',plan:'demo'},cookie)).status,200);
  const selected=await call('/api/membership',undefined,cookie);
  assert.equal(selected.data.access,true);assert.equal(selected.data.subscription?.status,'demo');assert.equal(selected.data.subscription?.price_cents,0);
  const trade={id:crypto.randomUUID(),revision:0,symbol:'MNQ',side:'Buy',result:'Win',quantity:1,pnl:50,risk:25,date:'2026-10-01',entryTime:'09:30',exitTime:'10:00',session:'New York',emotion:'Discipline',emotions:['Discipline'],strategyChecks:[],tags:[],notes:'Demo trade'};
  assert.equal((await call('/api/trades',trade,cookie)).status,200);
  const consumed=await call('/api/membership',undefined,cookie);
  assert.equal(consumed.data.subscription?.status,'demo_used');assert.equal(consumed.data.access,true);
  const blocked=await call('/api/trades',{...trade,id:crypto.randomUUID()},cookie);
  assert.equal(blocked.status,403);assert.equal(blocked.data.code,'DEMO_LIMIT_REACHED');
  assert.equal((await call('/api/trades/'+trade.id,undefined,cookie,'DELETE')).status,200);
  const stillBlocked=await call('/api/trades',{...trade,id:crypto.randomUUID()},cookie);
  assert.equal(stillBlocked.status,403);assert.equal(stillBlocked.data.code,'DEMO_LIMIT_REACHED');
  const proSignup=await call('/api/membership',{action:'register',email:'pro@example.com',password:'another-long-test-password',name:'Pro User'});
  const proCookie=proSignup.cookie.split(';')[0];
  assert.equal((await call('/api/membership',{action:'select_plan',plan:'pro'},proCookie)).status,200);
  const pro=await call('/api/membership',undefined,proCookie);
  assert.equal(pro.data.access,false);assert.equal(pro.data.subscription?.status,'inactive');assert.equal(pro.data.subscription?.price_cents,2000);assert.equal(pro.data.subscription?.revision,1);
 }finally{await mf.dispose();}
});
