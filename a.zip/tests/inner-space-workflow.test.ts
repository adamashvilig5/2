import {memberTestCookie} from './member-test-fixture.ts';
import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFileSync,realpathSync,readdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {blankInnerEntry} from '../lib/inner-space.ts';
const require=createRequire(realpathSync('node_modules/wrangler/package.json'));
const {Miniflare}=require('miniflare');
test('Inner Space saves and reloads privately, guards conflicts, and Challenge accounts persist',async()=>{
 const mf=new Miniflare({modulesRoot:resolve('dist/server'),modules:[{type:'ESModule',path:resolve('dist/server/index.js')},...readdirSync('dist/server',{recursive:true}).filter((f):f is string=>typeof f==='string'&&f!=='index.js'&&/\.(m?js)$/.test(f)).map(f=>({type:'ESModule',path:resolve('dist/server',f)}))],compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],r2Buckets:['BUCKET']});
 try{
  const db=await mf.getD1Database('DB');
  for(const path of readdirSync('drizzle').filter(p=>p.endsWith('.sql')).sort())for(const sql of readFileSync('drizzle/'+path,'utf8').split('--> statement-breakpoint').filter(s=>s.trim()))await db.prepare(sql).run();
  const call=async(path:string,method='GET',body?:unknown,owner='owner-a',origin?:string)=>{
   const headers:Record<string,string>={'Content-Type':'application/json'};
   if(owner){headers.cookie=await memberTestCookie(db,owner);headers['oai-authenticated-user-id']=owner;headers['oai-authenticated-user-email']=owner+'@example.com';}
   if(origin)headers.origin=origin;
   const response=await mf.dispatchFetch('https://journal.example'+path,{method,headers,...(body?{body:JSON.stringify(body)}:{})});
   return {status:response.status,data:await response.json() as any};
  };
  const url='/api/inner-space',entry={...blankInnerEntry('2026-10-01'),mood:4,mindset:['focused'],note:'ჩემი პირადი ჩანაწერი',lesson:'Wait for confirmation',intention:'Respect risk',breathingSessions:1};
  assert.equal((await call(url,'GET',undefined,'')).status,401);
  assert.equal((await call(url,'PUT',entry,'owner-a','https://untrusted.example')).status,403);
  assert.equal((await call(url,'PUT',{...entry,mood:6})).status,400);
  const saved=await call(url,'PUT',entry);assert.equal(saved.status,200);assert.equal(saved.data.entry.revision,1);
  assert.equal((await call(url,'PUT',entry)).status,409);
  assert.deepEqual((await call(url)).data.entries,[{...entry,revision:1}]);
  assert.deepEqual((await call(url,'GET',undefined,'owner-b')).data.entries,[]);
  assert.equal((await call(url,'PUT',{...entry,revision:1},'owner-b')).status,409);
  const updated={...entry,revision:1,mood:5,breathingSessions:2};
  assert.equal((await call(url,'PUT',updated)).status,200);
  assert.equal((await call(url,'PUT',{...updated,note:'Stale overwrite'})).status,409);
  assert.deepEqual((await call(url)).data.entries,[{...updated,revision:2}]);
  const account={id:crypto.randomUUID(),revision:0,name:'My Challenge',type:'Challenge',currency:'USD',startingBalance:50000,description:'Evaluation'};
  assert.equal((await call('/api/accounts','POST',account)).status,200);
  const journal=await call('/api/journal?date=2026-10-01');
  assert.equal(journal.data.accounts.find((a:any)=>a.id===account.id).type,'Challenge');
  assert.equal((await call('/api/journal?date=2026-10-01','GET',undefined,'owner-b')).data.accounts.some((a:any)=>a.id===account.id),false);
 }finally{await mf.dispose();}
});
