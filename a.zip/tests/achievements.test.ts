import test from 'node:test';
import assert from 'node:assert/strict';
import { ACHIEVEMENTS,LEVEL_RANKS,achievementMetrics,achievementProgress,levelForXp,levelThreshold,rankForLevel } from '../lib/achievements.ts';
import type { Trade,Daily,Strategy } from '../lib/trading.ts';
const trade=(date='2026-10-01',patch:Partial<Trade>={}):Trade=>({id:crypto.randomUUID(),revision:1,accountId:'default',symbol:'MNQ',side:'Buy',result:'Win',quantity:1,pnl:100,risk:100,date,entryTime:'09:30',exitTime:'10:00',session:'New York',emotion:'დისციპლინა',emotions:['დისციპლინა'],tags:[],notes:'',screenshots:[],createdAt:'2026-10-01',...patch});
const daily=(date:string,patch:Partial<Daily>={}):Daily=>({date,note:'',rules:[],revision:1,...patch});
test('48 distinct achievements and level thresholds show exact, bounded progress',()=>{
 assert.equal(ACHIEVEMENTS.length,48);assert.equal(new Set(ACHIEVEMENTS.map(a=>a.id)).size,48);
 assert.equal(levelForXp(0).level,1);assert.equal(levelForXp(249).level,1);assert.equal(levelForXp(250).level,2);assert.equal(levelForXp(699).level,2);assert.equal(levelForXp(700).level,3);assert.equal(levelForXp(700).current,0);assert.equal(levelForXp(700).remaining,650);
 const metrics=achievementMetrics([],[],[],'2026-10-01'),progress=achievementProgress(metrics,[]);
 assert.equal(progress.unlocked,0);assert.equal(progress.level.xp,0);assert.ok(progress.items.every(a=>a.current===0&&a.percent===0));
 const earned=achievementProgress(metrics,[{id:'first-entry',xp:100,earnedAt:'2026-10-01T00:00:00Z'}]);assert.equal(earned.level.xp,100);assert.equal(earned.items[0].percent,100);
});
test('badges require saved evidence, complete nonempty plans, and dates no later than today',()=>{
 const strategy={id:crypto.randomUUID(),name:'My plan',description:'',revision:1,checklist:['A','B']} as Strategy;
 const complete=trade('2026-10-01',{notes:'A detailed review of this entry and its psychology.',emotions:['დისციპლინა','მოთმინება'],strategyId:strategy.id,strategySnapshot:{name:strategy.name,checklist:strategy.checklist},strategyChecks:['A','B'],screenshots:[{id:'1',phase:'before',filename:'before.png'},{id:'2',phase:'after',filename:'after.png'}]});
 const incomplete=trade('2026-09-30',{strategyId:strategy.id,strategySnapshot:{name:strategy.name,checklist:strategy.checklist},strategyChecks:['A']});
 const empty=trade('2026-09-29',{strategyId:strategy.id,strategySnapshot:{name:strategy.name,checklist:[]},strategyChecks:[]});
 const actual=achievementMetrics([complete,incomplete,empty,{...complete,id:crypto.randomUUID(),date:'2026-10-02'}],[daily('2026-10-01',{note:'My daily goal is to follow my plan.',rules:[{label:'Keep risk',checked:true}]}),daily('2026-09-30'),daily('2026-10-02',{note:'A future plan should not earn XP.',rules:[{label:'Risk',checked:true}]})],[strategy,{...strategy,id:crypto.randomUUID(),checklist:[]}],'2026-10-01');
 assert.equal(actual.trades,3);assert.equal(actual.notes,1);assert.equal(actual.photos,1);assert.equal(actual.comparisons,1);assert.equal(actual.completePlans,1);assert.equal(actual.strategies,1);assert.equal(actual.dailyPlans,1);assert.equal(actual.goalsDone,1);assert.equal(actual.mindset,1);assert.equal(actual.bestStreak,3);assert.equal(actual.currentStreak,3);
});
test('journaling streaks include daily plans, handle weekends and month boundaries, and reset after gaps',()=>{
 const plans=['2026-09-29','2026-09-30','2026-10-01'].map(date=>daily(date,{note:'A saved daily plan with clear goals.'}));
 const metrics=achievementMetrics([],plans,[],'2026-10-02');assert.equal(metrics.bestStreak,3);assert.equal(metrics.currentStreak,3);
 assert.equal(achievementMetrics([],plans,[],'2026-10-03').currentStreak,0);
 assert.equal(achievementMetrics([trade('2026-09-25'),trade('2026-09-26'),trade('2026-09-27')],[],[],'2026-10-01').bestStreak,3);
 assert.equal(achievementMetrics([trade('2026-09-29'),trade('2026-10-01')],[],[],'2026-10-01').bestStreak,1);
});
test('rank labels and XP requirements agree at every promotion boundary',()=>{
 const promotions=LEVEL_RANKS.map(rank=>({level:rank.from,title:rank.title,xp:levelThreshold(rank.from)}));
 assert.equal(promotions[0].title,'ბაზრის მკვლევარი');assert.equal(promotions.at(-1)?.title,'ჟურნალის ოსტატი');assert.equal(promotions.length,11);
 for(const promotion of promotions){assert.equal(levelThreshold(promotion.level),promotion.xp);assert.equal(rankForLevel(promotion.level).title,promotion.title);assert.equal(levelForXp(promotion.xp).title,promotion.title);assert.equal(levelForXp(promotion.xp).level,promotion.level);if(promotion.level>1)assert.equal(levelForXp(promotion.xp-1).level,promotion.level-1);}
});
test('new full-review badge needs analysis, emotions, both photo phases, and a complete nonempty strategy',()=>{
 const complete=trade('2026-10-01',{notes:'A detailed explanation of the entry, the planned risk and the exit. '.repeat(3),emotions:['დისციპლინა','მოთმინება'],strategyId:crypto.randomUUID(),strategySnapshot:{name:'My setup',checklist:['Confirmation','Risk']},strategyChecks:['Confirmation','Risk'],screenshots:[{id:'1',phase:'before',filename:'before.png'},{id:'2',phase:'after',filename:'after.png'}]});
 assert.equal(achievementMetrics([complete],[],[],'2026-10-01').fullReviews,1);
 for(const patch of [{notes:'Short review'},{emotions:['დისციპლინა']},{strategyChecks:['Confirmation']},{strategySnapshot:{name:'Empty',checklist:[]}},{screenshots:complete.screenshots.slice(0,1)}])assert.equal(achievementMetrics([{...complete,...patch}],[],[],'2026-10-01').fullReviews,0);
 const more=Array.from({length:20},()=>({...complete,id:crypto.randomUUID()})),metrics=achievementMetrics(more,[],[],'2026-10-01'),progress=achievementProgress(metrics,[]);
 assert.equal(progress.items.find(a=>a.id==='twenty-checklists')?.current,20);assert.equal(progress.items.find(a=>a.id==='twenty-comparisons')?.current,20);assert.equal(progress.items.find(a=>a.id==='twenty-five-deep-reviews')?.current,20);
});
