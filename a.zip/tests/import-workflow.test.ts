import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {realpathSync,readdirSync,readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {memberTestCookie} from './member-test-fixture.ts';
const require=createRequire(realpathSync('node_modules/wrangler/package.json')),{Miniflare}=require('miniflare');
const csv='symbol,buyFillId,sellFillId,qty,buyPrice,sellPrice,pnl,boughtTimestamp,soldTimestamp\nMNQZ6,101,102,10,100,101,$20.00,10/01/2026 02:44:04,10/01/2026 02:43:50\n';
test('CSV preview, net P&L, validation, retry deduplication and owner isolation',async()=>{
 const mf=new Miniflare({modulesRoot:resolve('dist/server'),modules:[{type:'ESModule',path:resolve('dist/server/index.js')},...readdirSync('dist/server',{recursive:true}).filter((f):f is string=>typeof f==='string'&&f!=='index.js'&&/\.(m?js)$/.test(f)).map(f=>({type:'ESModule',path:resolve('dist/server',f)}))],compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],r2Buckets:['BUCKET']});
 try{const db=await mf.getD1Database('DB');for(const file of readdirSync('drizzle').filter(p=>p.endsWith('.sql')).sort())for(const sql of readFileSync('drizzle/'+file,'utf8').split('--> statement-breakpoint').filter(s=>s.trim()))await db.prepare(sql).run();
 const cookies={a:await memberTestCookie(db,'a'),b:await memberTestCookie(db,'b')};
 const call=async(body:unknown,user:'a'|'b'='a',origin='https://journal.example')=>{const r=await mf.dispatchFetch('https://journal.example/api/imports',{method:'POST',headers:{'content-type':'application/json','oai-authenticated-user-id':user,'oai-authenticated-user-email':user+'@example.com',cookie:cookies[user],origin},body:JSON.stringify(body)});return {status:r.status,data:await r.json() as any};};
 const input={csv,accountId:'default',offset:-240,action:'preview'};const pre=await call(input);assert.equal(pre.status,200);assert.equal(pre.data.rows[0].side,'Sell');assert.equal(pre.data.rows[0].duplicate,false);assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM trades').first()).n,0);
 const values=[{key:pre.data.rows[0].key,risk:50,commission:2}],commit={...input,action:'commit',confirmed:true,values};assert.equal((await call({...commit,confirmed:false})).status,400);assert.equal((await call({...commit,values:[]})).status,400);assert.equal((await call(commit,'a','https://evil.example')).status,403);
 assert.equal((await call(commit)).data.added,1);const stored=JSON.parse((await db.prepare("SELECT data_json FROM trades WHERE owner_id='a'").first()).data_json);assert.equal(stored.pnl,18);assert.equal(stored.risk,50);assert.equal(stored.emotion,'Not recorded');assert.equal(stored.entryTime,'02:43');assert.equal((await call(commit)).data.added,0);assert.equal((await call(input)).data.rows[0].duplicate,true);
 assert.equal((await call(input,'b')).data.rows[0].duplicate,false);assert.equal((await call(commit,'b')).data.added,1);
 assert.equal((await call({...input,accountId:crypto.randomUUID()})).status,400);assert.equal((await call({...input,csv:csv.replace('10/01/2026','02/30/2026')})).status,400);
 }finally{await mf.dispose();}
});
