import test from 'node:test';
import assert from 'node:assert/strict';
import { advancedStatistics,dailySharpe,weekdayPerformance,weekStart,calendarAction } from '../lib/advanced-statistics.ts';
import type { Trade } from '../lib/trading.ts';
const row=(pnl:number,date:string,session:Trade['session']='New York'):Trade=>({id:crypto.randomUUID(),revision:1,symbol:'MNQ',side:'Buy',result:pnl>0?'Win':pnl<0?'Loss':'Breakeven',quantity:1,pnl,risk:100,date,entryTime:'09:30',exitTime:'10:00',session,emotion:'დისციპლინა',tags:[],notes:'',createdAt:'',screenshots:[]});
test('expectancy and records aggregate selected trades, with Monday–Sunday weeks across years',()=>{
 const rows=[row(200,'2025-12-31','London'),row(-100,'2026-01-01','London'),row(50,'2026-01-02'),row(0,'2026-01-02'),row(500,'2026-01-05'),row(9999,'2026-02-01')];
 const report=advancedStatistics(rows,1000,'2025-12-31','2026-01-31');
 assert.equal(report.metrics.count,5);assert.equal(report.metrics.pnl,650);assert.equal(report.metrics.winRate,60);assert.equal(report.expectancy,130);assert.equal(report.expectancyR,1.3);
 assert.equal(report.worstTrade!.pnl,-100);assert.equal(report.bestTrade!.pnl,500);assert.equal(report.smallestWin!.pnl,50);assert.equal(report.records.day!.key,'2026-01-05');assert.equal(report.records.week!.key,'2026-01-05');assert.equal(report.records.month!.key,'2026-01');assert.equal(report.records.month!.pnl,450);assert.equal(report.records.year!.key,'2026');assert.equal(report.records.session!.key,'New York');assert.equal(report.records.session!.pnl,550);
 assert.equal(weekStart('2026-01-01'),'2025-12-29');assert.equal(weekStart('2026-01-04'),'2025-12-29');assert.equal(weekStart('2026-01-05'),'2026-01-05');
 const losses=advancedStatistics([row(-200,'2026-01-01'),row(-50,'2026-01-02')],1000,'2026-01-01','2026-01-02');assert.equal(losses.bestTrade!.pnl,-50);assert.equal(losses.records.day!.pnl,-50);assert.equal(losses.smallestWin,null);
 const empty=advancedStatistics([],null,'2026-01-01','2026-01-31');assert.equal(empty.worstTrade,null);assert.equal(advancedStatistics([row(5,'2026-01-01')],null,'2026-01-01','2026-01-31').worstTrade,null);assert.equal(empty.expectancy,null);assert.equal(empty.bestTrade,null);assert.equal(empty.records.week,null);
});
test('weekday totals retain zero outcomes and weekend trades without timezone shifts',()=>{
 const rows=[row(500,'2026-09-28'),row(-100,'2026-09-28'),row(-80,'2026-09-29'),row(0,'2026-09-30'),row(10,'2026-10-02'),row(99,'2026-10-03'),row(-40,'2026-10-04')];
 const days=weekdayPerformance(rows);assert.equal(days.length,7);assert.equal(days[0].label,'ორშაბათი');assert.equal(days[0].pnl,400);assert.equal(days[0].count,2);assert.equal(days[0].winRate,50);assert.equal(days[1].pnl,-80);assert.equal(days[2].count,1);assert.equal(days[2].pnl,0);assert.equal(days[3].count,0);assert.equal(days[4].pnl,10);assert.equal(days[5].pnl,99);assert.equal(days[6].pnl,-40);assert.equal(days.reduce((sum,d)=>sum+d.count,0),rows.length);
});
test('Sharpe uses daily equity returns and sample deviation; zero days and missing capital are explicit',()=>{
 const rows=[row(100,'2026-10-01'),row(-55,'2026-10-02')],result=dailySharpe(rows,1000,'2026-10-01','2026-10-03');
 const returns=[.1,-.05,0],mean=returns.reduce((a,b)=>a+b)/3,sd=Math.sqrt(returns.reduce((sum,v)=>sum+(v-mean)**2,0)/2);
 assert.ok(Math.abs(result.value!-mean/sd)<1e-12);assert.equal(result.observations,3);assert.equal(result.activeDays,2);
 assert.equal(dailySharpe(rows,null,'2026-10-01','2026-10-03').value,null);
 assert.equal(dailySharpe(rows,0,'2026-10-01','2026-10-03').value,null);
 assert.equal(dailySharpe([rows[0]],1000,'2026-10-01','2026-10-03').value,null);
 assert.equal(dailySharpe([row(0,'2026-10-01'),row(0,'2026-10-02')],1000,'2026-10-01','2026-10-02').value,null);
 assert.equal(dailySharpe([row(-1000,'2026-10-01'),row(10,'2026-10-02')],1000,'2026-10-01','2026-10-03').value,null);
});
test('calendar opens a single record, multiple-record list, or a date-filled entry form',()=>{
 const a=row(10,'2026-10-01'),b=row(-20,'2026-10-01');
 assert.equal(calendarAction([a],'2026-10-01','2026-10-01').kind,'review');
 assert.deepEqual(calendarAction([a,b],'2026-10-01','2026-10-01').rows.length,2);
 assert.equal(calendarAction([a,b],'2026-10-01','2026-10-01').kind,'list');
 assert.equal(calendarAction([a],'2026-09-30','2026-10-01').kind,'new');
 assert.equal(calendarAction([a],'2026-10-02','2026-10-01').kind,'list');
});
