import { registerHooks } from 'node:module';
import { readFileSync,existsSync } from 'node:fs';
import { fileURLToPath,pathToFileURL } from 'node:url';
import { resolve,dirname,extname } from 'node:path';
import ts from 'typescript';
const root=resolve('.');
registerHooks({
 resolve(specifier,context,nextResolve){
  if(context.parentURL?.includes('/node_modules/')&&!specifier.startsWith('@/'))return nextResolve(specifier,context);
  let path=specifier.startsWith('@/')?resolve(root,specifier.slice(2)):specifier.startsWith('.')&&context.parentURL?.startsWith('file:')?resolve(dirname(fileURLToPath(context.parentURL)),specifier):null;
  if(path&&!extname(path))path=['.ts','.tsx','.mjs'].map(extension=>path+extension).find(existsSync)??path;
  return path&&existsSync(path)?nextResolve(pathToFileURL(path).href,context):nextResolve(specifier,context);
 },
 load(url,context,nextLoad){
  if(url.endsWith('.tsx'))return {format:'module',shortCircuit:true,source:ts.transpileModule('import React from "react";\n'+readFileSync(fileURLToPath(url),'utf8'),{compilerOptions:{jsx:ts.JsxEmit.React,module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText};
  return nextLoad(url,context);
 }
});
