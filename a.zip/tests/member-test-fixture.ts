// Database fixtures for existing journal API tests. The production server still validates sessions and subscriptions.
export async function memberTestCookie(db:any,id:string){
 const token='test-member-'+id,hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(token)))).map(v=>v.toString(16).padStart(2,'0')).join('');
 await db.prepare("INSERT OR IGNORE INTO members (id,email,name,password_hash,created_at) VALUES (?, ?, ?, 'unused-fixture', '2026-01-01')").bind(id,id+'@example.com',id).run();
 await db.prepare("INSERT OR IGNORE INTO subscriptions (member_id,status,period_end,price_cents) VALUES (?, 'active', '2099-01-01', 1900)").bind(id).run();
 await db.prepare("INSERT OR IGNORE INTO member_sessions (token_hash,member_id,gate_id,expires_at) VALUES (?, ?, ?, '2099-01-01')").bind(hash,id,id).run();
 return 'journal_member_session='+token;
}
