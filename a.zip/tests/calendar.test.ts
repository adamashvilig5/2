import test from 'node:test';
import assert from 'node:assert/strict';
import { monthCells,moveMonth,monthSummary,groupPerformance,type Trade } from '../lib/trading.ts';
const row=(pnl:number,date:string):Trade=>({id:crypto.randomUUID(),revision:1,symbol:'MNQ',side:'Buy',result:pnl>0?'Win':'Loss',quantity:1,pnl,risk:100,date,entryTime:'09:30',exitTime:'10:00',session:'New York',emotion:'დისციპლინა',emotions:['დისციპლინა','მოთმინება'],strategyChecks:['Entry confirmation'],tags:['Breakout'],notes:'',createdAt:'',screenshots:[]});
test('monthly calendar aligns Sunday columns, leap days, and month navigation',()=>{
 const october=monthCells('2026-10');assert.equal(october[0],'2026-09-27');assert.equal(october.at(-1),'2026-10-31');assert.equal(october.length,35);
 assert.ok(monthCells('2028-02').includes('2028-02-29'));assert.equal(moveMonth('2026-12',1),'2027-01');assert.equal(moveMonth('2026-01',-1),'2025-12');
});
test('monthly totals exclude other months; multiple emotions retain independent statistics',()=>{
 const rows=[row(550,'2026-10-01'),row(-100,'2026-10-02'),row(900,'2026-09-30')];const summary=monthSummary(rows,'2026-10');assert.equal(summary.count,2);assert.equal(summary.pnl,450);assert.equal(summary.winRate,50);
 const groups=groupPerformance(rows,'emotion');assert.equal(groups.length,2);assert.equal(groups[0].count,3);assert.equal(groups[1].pnl,1350);
 const legacy={...row(50,'2026-10-03'),emotions:undefined};assert.equal(groupPerformance([legacy],'emotion')[0].name,'დისციპლინა');
});
