import test from 'node:test';
import assert from 'node:assert/strict';
import {accountScope,accountPerformance,ALL_ACCOUNTS} from '../lib/portfolio.ts';
import {stats,type Account,type Trade} from '../lib/trading.ts';
import {aggregatePerformance} from '../lib/advanced-statistics.ts';
import {innerSpaceSchema,blankInnerEntry,innerAnalytics} from '../lib/inner-space.ts';
const account=(id:string,currency:Account['currency']='USD',balance:number|null=10000):Account=>({id,revision:1,name:id,type:'Challenge',currency,startingBalance:balance,description:''});
const trade=(accountId:string,pnl:number,date='2026-10-01'):Trade=>({id:crypto.randomUUID(),accountId,revision:1,symbol:'MNQ',side:'Buy',result:pnl>0?'Win':pnl<0?'Loss':'Breakeven',quantity:1,pnl,risk:100,date,entryTime:'09:30',exitTime:'10:00',session:'New York',emotion:'დისციპლინა',tags:[],notes:'',screenshots:[],createdAt:date});
test('portfolio combines trade-weighted performance and switches every dataset to one account',()=>{
 const accounts=[account('a'),account('b')],rows=[trade('a',300),trade('b',200),trade('b',-100),trade('b',-50),trade('archived',99999)];
 const all=accountScope(rows,accounts,ALL_ACCOUNTS),metrics=stats(all.trades,all.startingBalance);
 assert.equal(metrics.pnl,350);assert.equal(metrics.count,4);assert.equal(metrics.winRate,50);assert.equal(all.startingBalance,20000);
 assert.equal(stats(accountScope(rows,accounts,'a').trades,10000).winRate,100);assert.equal(accountScope(rows,accounts,'b').trades.length,3);
 assert.equal(aggregatePerformance(all.trades,'day')[0].pnl,350);
});
test('currency and missing-capital rules keep portfolio money and percentages meaningful',()=>{
 const accounts=[account('a'),account('b','EUR'),account('default','USD',null)],rows=[trade('a',100),trade('b',900)];
 assert.equal(accountScope(rows,accounts,ALL_ACCOUNTS,'USD').trades.length,1);assert.equal(accountScope(rows,accounts,ALL_ACCOUNTS,'EUR').trades[0].pnl,900);
 assert.equal(accountScope(rows,accounts,ALL_ACCOUNTS).startingBalance,10000);
 assert.equal(accountScope([...rows,trade('default',10)],accounts,ALL_ACCOUNTS).startingBalance,null);
 assert.equal(accountScope(rows,accounts,'b').currency,'EUR');assert.equal(accountScope(rows,accounts,ALL_ACCOUNTS,'GEL').currency,'USD');
});
test('account comparisons use opening capital before the filter and periods keep all trades',()=>{
 const rows=[trade('a',1000,'2026-09-01'),trade('a',220,'2026-10-01'),trade('b',-100,'2026-10-01')],accounts=[account('a'),account('b')];
 const result=accountPerformance(rows,accounts,'2026-10-01','2026-10-01');assert.equal(result[0].returnPct,2);assert.equal(result[0].count,1);assert.equal(result[1].pnl,-100);
 assert.equal(aggregatePerformance(rows,'month').reduce((sum,row)=>sum+row.count,0),3);assert.equal(aggregatePerformance(rows,'week').reduce((sum,row)=>sum+row.pnl,0),1120);
});
test('Inner Space validates private check-ins and averages only assessed moods',()=>{
 const first={...blankInnerEntry('2026-10-01'),mood:4,mindset:['focused'] as const,breathingSessions:2},second=blankInnerEntry('2026-09-30');
 const parsed=innerSpaceSchema.parse(first),report=innerAnalytics([parsed,second]);assert.equal(report.averageMood,4);assert.equal(report.entries,2);assert.equal(report.breathingSessions,2);assert.equal(report.mindsets[0].id,'focused');
 assert.equal(innerSpaceSchema.safeParse({...first,mood:6}).success,false);assert.equal(innerSpaceSchema.safeParse({...first,mindset:['focused','focused']}).success,false);
});
