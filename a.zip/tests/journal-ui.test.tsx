import test from 'node:test';
import assert from 'node:assert/strict';
import { renderToStaticMarkup } from 'react-dom/server';
import { JournalLanguageProvider } from '../app/journal-language.tsx';
import { StrategyManager,AccountEditor } from '../app/journal-managers.tsx';
import JournalTimePicker from '../app/journal-time-picker.tsx';
import TradeCalendar from '../app/trade-calendar.tsx';
import AchievementsPage from '../app/achievements-page.tsx';
import StatisticsPage from '../app/statistics-page.tsx';
import { achievementMetrics,achievementProgress } from '../lib/achievements.ts';
import type { Strategy } from '../lib/trading.ts';

test('English strategy editor offers ICT ideas while preserving user-authored strategy text',()=>{
 const strategy:Strategy={id:crypto.randomUUID(),revision:1,name:'ჩემი პირადი სტრატეგია',description:'ჩემი შენიშვნა',checklist:['ჩემი საკუთარი პირობა']};
 const html=renderToStaticMarkup(<JournalLanguageProvider initialLanguage="en"><StrategyManager strategies={[strategy]} onSave={async s=>s} onDelete={async()=>{}}/></JournalLanguageProvider>);
 assert.match(html,/ICT checklist ideas/);assert.match(html,/Fair Value Gap/);assert.match(html,/Pre-entry checklist/);assert.match(html,/value="ჩემი პირადი სტრატეგია"/);assert.match(html,/value="ჩემი საკუთარი პირობა"/);assert.doesNotMatch(html,/შესვლამდე შესამოწმებელი პირობები/);
});
test('English account editor translates types, retaining canonical type and currency values',()=>{
 const html=renderToStaticMarkup(<JournalLanguageProvider initialLanguage="en"><AccountEditor account={null} hasTrades={false} onSave={async()=>{}} onCancel={()=>{}}/></JournalLanguageProvider>);
 assert.match(html,/Account type/);assert.match(html,/Create account/);assert.match(html,/Practice account/);assert.match(html,/Challenge/);assert.match(html,/Evaluation account/);assert.match(html,/<option selected="">USD<\/option>/);assert.doesNotMatch(html,/ანგარიშის ტიპი/);
});
test('time button replaces native time inputs and English calendar localizes weekday labels',()=>{
 const html=renderToStaticMarkup(<JournalLanguageProvider initialLanguage="en"><JournalTimePicker value="23:59" label="Exit Time" onChange={()=>{}}/><TradeCalendar trades={[]} today="2026-10-01" onOpenDay={()=>{}}/></JournalLanguageProvider>);
 assert.match(html,/23:59/);assert.match(html,/October 2026/);assert.match(html,/>Mon</);assert.doesNotMatch(html,/type="time"/);assert.doesNotMatch(html,/ორშ|წინა თვე/);
});
test('achievements use professional trader ranks and translate descriptions for English',()=>{
 const progress=achievementProgress(achievementMetrics([],[],[],'2026-10-01'),[]);
 const html=renderToStaticMarkup(<JournalLanguageProvider initialLanguage="en"><AchievementsPage progress={progress} busy={false} error="" onRefresh={()=>{}} onAction={()=>{}}/></JournalLanguageProvider>);
 assert.match(html,/Market Explorer/);assert.match(html,/Record your first trade/);assert.match(html,/First step/);assert.doesNotMatch(html,/პირველი ნაბიჯი|რეკრუტი/);
});
test('English analytics localizes weekday tables, metrics, and missing-data explanations',()=>{
 const html=renderToStaticMarkup(<JournalLanguageProvider initialLanguage="en"><StatisticsPage trades={[]} opening={null} start="2026-09-01" end="2026-10-01" currency="USD" strategies={[]} curve={[]} onReview={()=>{}} onSetBalance={()=>{}} onExplore={()=>{}}/></JournalLanguageProvider>);
 assert.match(html,/Day of the Week Performance/);assert.match(html,/Monday/);assert.match(html,/Set a positive opening balance/);assert.match(html,/No records in this period/);assert.doesNotMatch(html,/ორშაბათი|ბალანსის მითითება|შედეგი/);
});

test('Georgian achievements headings display მიღწევები',()=>{
 const progress=achievementProgress(achievementMetrics([],[],[],'2026-10-01'),[]);
 const html=renderToStaticMarkup(<JournalLanguageProvider initialLanguage="ka"><AchievementsPage progress={progress} busy={false} error="" onRefresh={()=>{}} onAction={()=>{}}/></JournalLanguageProvider>);
 assert.match(html,/>მიღწევები</);assert.doesNotMatch(html,/>Achievements</);
});
