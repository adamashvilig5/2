import test from 'node:test';
import assert from 'node:assert/strict';
import { stats,equityCurve,periodTrades,openingEquity,tradeSchema,dateSchema,type Trade } from '../lib/trading.ts';
const trade=(pnl:number,date='2026-10-01',extras:Partial<Trade>={}):Trade=>({id:crypto.randomUUID(),revision:1,symbol:'MNQ',side:'Buy',result:pnl>0?'Win':pnl<0?'Loss':'Breakeven',quantity:1,pnl,risk:100,date,entryTime:'09:30',exitTime:'10:00',session:'New York',emotion:'დისციპლინა',tags:['Breakout'],notes:'',createdAt:new Date().toISOString(),screenshots:[],...extras});
test('P&L, partial outcomes, win rate, payoff and drawdown derive from real amounts',()=>{
 const rows=[trade(300,'2026-09-28'),trade(-100,'2026-09-29'),trade(0,'2026-09-30'),trade(50,'2026-10-01',{result:'Partial'})];
 const m=stats(rows,1000);assert.equal(m.pnl,250);assert.equal(m.returnPct,25);assert.equal(m.winRate,50);assert.equal(m.count,4);assert.equal(m.avgWin,175);assert.equal(m.avgLoss,100);assert.equal(m.ratio,1.75);assert.equal(m.profitFactor,3.5);assert.equal(m.maxDrawdown,100);assert.equal(m.recovery,2.5);assert.equal(m.consistency,50);assert.equal(m.maxDrawdownPct,100/1300*100);
});
test('period equity carries previous trades and includes the last calendar day',()=>{
 const rows=[trade(200,'2026-09-01'),trade(-50,'2026-09-25'),trade(100,'2026-10-01'),trade(999,'2026-10-02')];
 assert.equal(periodTrades(rows,7,'2026-10-01').length,2);assert.equal(openingEquity(rows,7,'2026-10-01',1000),1200);
 const curve=equityCurve(rows,7,'2026-10-01',1000);assert.equal(curve[0].equity,1200);assert.equal(curve.at(-1)!.equity,1250);assert.equal(curve.at(-1)!.date,'2026-10-01');
 assert.equal(stats(periodTrades(rows,7,'2026-10-01'),1200).returnPct,50/1200*100);
});
test('zero trades, no losses and absent starting balance never invent finite ratios or returns',()=>{
 const empty=stats([],null);assert.equal(empty.count,0);assert.equal(empty.returnPct,null);assert.equal(empty.profitFactor,null);assert.equal(empty.ratio,null);assert.equal(empty.maxDrawdownPct,null);
 const winning=stats([trade(550)],null);assert.equal(winning.profitFactor,Infinity);assert.equal(winning.ratio,Infinity);assert.equal(winning.recovery,Infinity);assert.equal(winning.returnPct,null);
 assert.equal(stats([trade(-200)],1000).maxDrawdown,200);
});
test('invalid dates, time, zero risk, and incompatible result labels are rejected',()=>{
 assert.equal(dateSchema.safeParse('2026-02-30').success,false);
 for(const extras of [{risk:0},{entryTime:'25:00'},{pnl:-100,result:'Win'},{quantity:0}])assert.equal(tradeSchema.safeParse(trade(100,'2026-10-01',extras as Partial<Trade>)).success,false);
});
