import test from 'node:test';
import assert from 'node:assert/strict';
import { exampleBoard, emptyBoard, parseBoard, ranking, boardProblem, scoreOption } from '../lib/decision.ts';
test('weighted ranking and changed priorities change the leader',()=>{
 const b=structuredClone(exampleBoard);
 assert.equal(ranking(b)[0].option.name,'Home office');
 assert.equal(ranking(b)[0].score,8.35);
 b.criteria.forEach(c=>c.weight=c.id==='c2'?100:0);
 assert.equal(ranking(b)[0].option.name,'Coworking space');
 assert.equal(ranking(b)[0].score,9);
});
test('unrated scores are incomplete, zero is a valid rating, and weights normalize',()=>{
 const b=structuredClone(exampleBoard);b.options[0].scores.c1=null;
 assert.equal(scoreOption(b,b.options[0]),null);
 b.options[0].scores.c1=0;assert.equal(scoreOption(b,b.options[0]),4.35);
 b.criteria.forEach(c=>c.weight*=2); // calculation does not require a total of 100
 assert.equal(scoreOption(b,b.options[0]),4.35);
 b.criteria.forEach(c=>c.weight=0);assert.equal(scoreOption(b,b.options[0]),null);
});
test('a preferred choice requires a complete meaningful decision',()=>{
 assert.equal(boardProblem(exampleBoard),null);
 assert.match(boardProblem(emptyBoard)!,/title/);
 const b=structuredClone(exampleBoard); b.options[1].name=b.options[0].name;
 assert.match(boardProblem(b)!,/different name/);
 b.options[1].name='Different'; b.options[0].scores.c1=null;
 assert.match(boardProblem(b)!,/Score/);
 b.criteria[0].weight=0;assert.equal(boardProblem(b),null);
});
test('server validation rejects invalid scores, identities and weights',()=>{
 for(const score of [-1,11,1.5]){const b=structuredClone(exampleBoard);b.options[0].scores.c1=score;assert.throws(()=>parseBoard(b));}
 const b=structuredClone(exampleBoard);b.options[1].id=b.options[0].id;assert.throws(()=>parseBoard(b));
 const c=structuredClone(exampleBoard);c.options[0].scores.unknown=4;assert.throws(()=>parseBoard(c));
 const d=structuredClone(exampleBoard);d.criteria[0].weight=-1;assert.throws(()=>parseBoard(d));
});
