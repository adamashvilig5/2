import test from 'node:test';
import assert from 'node:assert/strict';
import type { Trade } from '../lib/trading.ts';
import { getConditionStatistics,getEmotionStatistics,getProcessQuality,getStrategyConditionCombinations,getStrategyStatistics,getTradeStatistics,getTradingInsights,getTrades,sampleReliability,tradeDataStatus } from '../lib/trade-analytics.ts';

const fixture=():Trade[]=>Array.from({length:10},(_,index)=>{
 const win=index<4,conditions=[{id:'htf_bias',label:'Higher-timeframe bias identified',checked:index<5},{id:'liquidity_sweep',label:'Planned liquidity sweep observed',checked:index%2===0}];
 const emotionsAtEntry=[{id:'fomo',label:'FOMO',selected:index<5},{id:'discipline',label:'Discipline',selected:index>=5}];
 const review={planAdherence:index<6?'yes' as const:'partial' as const,executionChecks:['setup','risk','stop'] as ('setup'|'risk'|'stop')[],satisfiedConditionIds:conditions.filter(item=>item.checked).map(item=>item.id),executionQuality:'partial' as const,mistakes:[] as ('clean')[],lesson:'Review saved',readiness:index<5?80:60,plannedRisk:0.5,reviewedAt:'2026-10-01T12:00:00.000Z'};
 return {id:'trade-'+index,revision:1,symbol:index%2?'MNQ':'MES',side:'Buy',result:win?'Win':'Loss',quantity:1,pnl:win?100:-50,risk:50,date:'2026-10-'+String(index+1).padStart(2,'0'),entryTime:'09:30',exitTime:'10:00',session:index%2?'New York':'London',emotion:index<5?'FOMO':'Discipline',emotions:index<5?['FOMO']:['Discipline'],strategyId:'strategy-1',strategySnapshot:{name:'MMXM',checklist:conditions.map(item=>item.label)},strategyConditions:conditions,conditionsMet:conditions.filter(item=>item.checked).length,conditionsTotal:2,conditionsCompletionRate:conditions.filter(item=>item.checked).length/2*100,emotionsAtEntry,selectedEmotionIds:emotionsAtEntry.filter(item=>item.selected).map(item=>item.id),rMultiple:win?2:-1,preTradeReadinessScore:review.readiness,riskPlan:{plannedRiskPercent:0.5},tags:['MMXM'],notes:'',createdAt:'2026-10-01T00:00:00.000Z',screenshots:[],review};
});

test('saved strategy conditions, emotions and review fields drive common statistics and insights',()=>{
 const trades=fixture(),strategy=getStrategyStatistics(trades)[0],conditions=getConditionStatistics(trades),emotions=getEmotionStatistics(trades);
 assert.equal(strategy.label,'MMXM');assert.equal(strategy.trades,10);assert.equal(strategy.winRate,40);assert.equal(strategy.netPnl,100);assert.equal(strategy.averageR,0.2);assert.equal(strategy.averageConditionsCompletionRate,50);assert.equal(strategy.planAdherence,80);
 const htf=conditions.find(item=>item.id==='htf_bias')!;assert.equal(htf.checkedCount,5);assert.equal(htf.checked.winRate,80);assert.equal(htf.unchecked.winRate,0);assert.equal(htf.checked.netPnl,350);
 const fomo=emotions.find(item=>item.id==='fomo')!;assert.equal(fomo.trades,5);assert.equal(fomo.winRate,80);assert.equal(fomo.averageR,1.4);
 const insight=getTradingInsights(trades).find(item=>item.id==='fomo')!;assert.equal(insight.sampleSize,5);assert.equal(insight.reliability.label,'Early pattern detected');assert.match(insight.explanation,/80%/);
 assert.equal(getTradingInsights(trades).some(item=>item.id==='condition:htf_bias'),true);
});

test('shared filters affect statistics and insights consistently and small combinations stay hidden',()=>{
 const trades=fixture(),filtered=getTrades(trades,{strategy:'strategy-1',asset:'MNQ',session:'New York',emotion:'fomo',condition:'htf_bias',result:'Win',executionQuality:'partial',start:'2026-10-01',end:'2026-10-10'});
 assert.equal(filtered.length,2);assert.equal(getStrategyStatistics(trades,{asset:'MNQ',emotion:'fomo'}).reduce((sum,item)=>sum+item.trades,0),2);
 assert.equal(getTradingInsights(trades,{asset:'MNQ',emotion:'fomo'}).every(item=>item.sampleSize<=3),true);
 assert.equal(getStrategyConditionCombinations(trades).length,0);
});

test('confidence thresholds, data completeness and process score do not depend on P&L',()=>{
 assert.equal(sampleReliability(4).label,'Not enough data');assert.equal(sampleReliability(8).label,'Early pattern detected');assert.equal(sampleReliability(12).label,'Consistent pattern');assert.equal(sampleReliability(20).label,'Strong pattern based on your recent data');
 const trade=fixture()[0];assert.equal(getProcessQuality(trade),getProcessQuality({...trade,pnl:-900,result:'Loss'}));assert.equal(tradeDataStatus(trade),'Complete');assert.equal(tradeDataStatus({...trade,review:undefined}),'Awaiting review');assert.equal(tradeDataStatus({...trade,strategyId:null,review:trade.review}),'Partial');assert.equal(tradeDataStatus({...trade,pnl:undefined as unknown as number}),'Awaiting result');
});

test('analytics immediately reflect an edited or deleted persisted trade',()=>{
 const trades=fixture(),edited=trades.map((trade,index)=>index===0?{...trade,pnl:-200,result:'Loss' as const,rMultiple:-4}:trade);
 assert.equal(getTradeStatistics(trades).netPnl,100);
 assert.equal(getTradeStatistics(edited).netPnl,-200);
 assert.equal(getStrategyStatistics(edited)[0].averageR,-0.4);
 const withoutEditedTrade=edited.filter(trade=>trade.id!=='trade-0');
 assert.equal(getTradeStatistics(withoutEditedTrade).trades,9);
 assert.equal(getEmotionStatistics(withoutEditedTrade).find(item=>item.id==='fomo')?.trades,4);
});
