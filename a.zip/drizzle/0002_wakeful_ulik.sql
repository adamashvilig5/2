DROP INDEX `idx_screenshots_owner_trade_phase`;--> statement-breakpoint
CREATE INDEX `idx_screenshots_owner_trade` ON `screenshots` (`owner_id`,`trade_id`);