CREATE TABLE `inner_space_entries` (
	`owner_id` text NOT NULL,
	`date` text NOT NULL,
	`data_json` text NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL,
	PRIMARY KEY(`owner_id`, `date`)
);
