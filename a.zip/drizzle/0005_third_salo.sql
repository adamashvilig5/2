CREATE TABLE `achievement_awards` (
	`owner_id` text NOT NULL,
	`achievement_id` text NOT NULL,
	`xp` integer NOT NULL,
	`earned_at` text NOT NULL,
	PRIMARY KEY(`owner_id`, `achievement_id`)
);
