CREATE TABLE `decisions` (
	`owner_id` text PRIMARY KEY NOT NULL,
	`board_json` text NOT NULL,
	`choice_json` text,
	`revision` integer DEFAULT 1 NOT NULL,
	`updated_at` text NOT NULL
);
