import type { Metadata } from "next";
import "./globals.css";
import "./welcome.css";
import "./landing-refresh.css";
import { JournalTheme } from './theme-controls';
import { JournalLanguageProvider } from './journal-language';

export const metadata: Metadata = {
  title: "Trade Journal — Build a Better Trading Process",
  description: "A private trading journal to review every trade, understand performance, and build a repeatable trading process.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased"><JournalTheme><JournalLanguageProvider>{children}</JournalLanguageProvider></JournalTheme></body>
    </html>
  );
}
