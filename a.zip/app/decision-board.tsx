'use client';
import { useEffect, useRef, useState } from 'react';
import { Plus, X, LockKeyhole, Check, SlidersHorizontal, Scale, LayoutGrid, BookmarkCheck, RotateCcw, ChevronDown, CheckCircle2, AlertCircle } from 'lucide-react';
import { emptyBoard, exampleBoard, boardProblem, totalWeight, ranking, scoreOption, type Board, type SavedChoice } from '@/lib/decision';
const copy = <T,>(v:T):T=>JSON.parse(JSON.stringify(v));
const uid=()=>crypto.randomUUID();
export default function DecisionBoard() {
 const [board,setBoard]=useState<Board>(copy(emptyBoard));
 const [choice,setChoice]=useState<SavedChoice|null>(null);
 const [revision,setRevision]=useState(0);
 const [loading,setLoading]=useState(true);
 const [loadError,setLoadError]=useState('');
 const [error,setError]=useState('');
 const [saving,setSaving]=useState(false);
 const [savedBoard,setSavedBoard]=useState(JSON.stringify(emptyBoard));
 const [status,setStatus]=useState('');
 const [tab,setTab]=useState<'score'|'compare'>('score');
 const [preferred,setPreferred]=useState('');
 const [rationale,setRationale]=useState('');
 const [pair,setPair]=useState<[string,string]>(['o1','o2']);
 const [showSaved,setShowSaved]=useState(false);
 const didLoad=useRef(false);
 const dirty=JSON.stringify(board)!==savedBoard;
 const choiceDirty=preferred!==(choice?.optionId??'')||rationale!==(choice?.rationale??'');
 const weights=totalWeight(board), ranks=ranking(board), problem=boardProblem(board);
 const selected=board.options.find(o=>o.id===preferred);
 const validPair=pair.map((id,i)=>board.options.find(o=>o.id===id)??board.options[i]) as (Board['options'][number]|undefined)[];
 const a=validPair[0], b=validPair[1];
 const choiceChanged=choice && JSON.stringify(board)!==JSON.stringify(choice.snapshot);
 async function load() {
  setLoading(true);setLoadError('');
  try {
   const res=await fetch('/api/board',{cache:'no-store'}), data=await res.json() as {error?:string;board:Board|null;choice:SavedChoice|null;revision:number};
   if(!res.ok) throw new Error(data.error??'Unable to load your board.');
   const next=data.board??copy(emptyBoard);
   setBoard(next);setChoice(data.choice);setRevision(data.revision);setSavedBoard(JSON.stringify(next));
   setPreferred(data.choice?.optionId??'');setRationale(data.choice?.rationale??'');setError('');setStatus(data.board?'Board saved':'');
  }catch(e){setLoadError(e instanceof Error?e.message:'Unable to load your board.');}
  finally {setLoading(false);}
 }
 useEffect(()=>{if(!didLoad.current){didLoad.current=true;void load();}},[]);
 useEffect(()=>{
  const warn=(e:BeforeUnloadEvent)=>{if(dirty||choiceDirty){e.preventDefault();e.returnValue='';}};
  window.addEventListener('beforeunload',warn);return()=>window.removeEventListener('beforeunload',warn);
 },[dirty,choiceDirty]);
 function update(fn:(b:Board)=>Board) {setBoard(fn);setStatus('');setError('');}
 async function save(finalChoice=false) {
  if(finalChoice && (problem||!selected)){setError(problem??'Select your preferred option.');return;}
  setSaving(true);setError('');setStatus('');
  const snapshot=copy(board);
  try{
   const res=await fetch('/api/board',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({board:snapshot,revision,...(finalChoice?{preferredOptionId:preferred,rationale}:{})})});
   const data=await res.json() as {error?:string;revision:number;choice?:SavedChoice};if(!res.ok)throw new Error(data.error??'Unable to save your board.');
   setRevision(data.revision);setSavedBoard(JSON.stringify(snapshot));
   if(data.choice){setChoice(data.choice);setStatus('Preferred choice saved.');}else setStatus('Board saved.');
  }catch(e){setError(e instanceof Error?e.message:'Unable to save. Please try again.');}
  finally{setSaving(false);}
 }
 function addOption(){const id=uid();update(v=>({...v,options:[...v.options,{id,name:'',notes:'',scores:{}}]}));}
 function removeOption(id:string){update(v=>({...v,options:v.options.filter(o=>o.id!==id)}));if(preferred===id)setPreferred('');}
 function addCriterion(){update(v=>({...v,criteria:[...v.criteria,{id:uid(),name:'',weight:20}]}));}
 function removeCriterion(id:string){update(v=>({...v,criteria:v.criteria.filter(c=>c.id!==id),options:v.options.map(o=>({...o,scores:Object.fromEntries(Object.entries(o.scores).filter(([k])=>k!==id))}))}));}
 function criterion(id:string,fields:Partial<Board['criteria'][number]>){update(v=>({...v,criteria:v.criteria.map(c=>c.id===id?{...c,...fields}:c)}));}
 function option(id:string,fields:Partial<Board['options'][number]>){update(v=>({...v,options:v.options.map(o=>o.id===id?{...o,...fields}:o)}));}
 function rate(oid:string,cid:string,value:string){update(v=>({...v,options:v.options.map(o=>o.id===oid?{...o,scores:{...o.scores,[cid]:value===''?null:Number(value)}}:o)}));}
 const rated=board.options.reduce((n,o)=>n+board.criteria.filter(c=>c.weight>0&&o.scores[c.id]!=null).length,0);
 const needed=board.options.length*board.criteria.filter(c=>c.weight>0).length;
 return <div className="app-shell">
  <header className="topbar"><a href="/" className="brand"><span className="brand-icon"><LayoutGrid size={19}/></span>Decision Board</a><div className="header-actions"><span className="private"><LockKeyhole size={14}/> Private</span><span className="save-state">{saving?'Saving…':dirty||choiceDirty?'Unsaved changes':status||'Your workspace'}</span><button className="primary save-board" onClick={()=>save()} disabled={saving||loading||!!loadError}><Check size={16}/> Save board</button></div></header>
  <main>
   {loading?<div className="loading">Loading your decision board…</div>:loadError?<div className="load-error"><AlertCircle size={24}/><h1>Your board is unavailable</h1><p>{loadError}</p><button className="primary" onClick={load}><RotateCcw size={16}/> Try again</button><a className="signin" href="/signin-with-chatgpt?return_to=%2F" target="_top">Sign in with ChatGPT</a></div>:<>
   <section className="decision-heading"><div className="eyebrow">YOUR DECISION</div><label className="sr-only" htmlFor="decision-title">Decision title</label><input id="decision-title" className="title-input" maxLength={160} value={board.title} placeholder="What are you deciding?" onChange={e=>update(v=>({...v,title:e.target.value}))}/><div className="heading-meta"><p>Make the tradeoffs visible. Choose with confidence.</p>{!dirty&&!choice&&revision===0&&<button className="text-button" onClick={()=>{setBoard(copy(exampleBoard));setPair(['o1','o2']);}}>Try an example</button>}</div></section>
   {error&&<div className="notice error" role="alert"><AlertCircle size={18}/>{error}</div>}
   {status&&<div className="sr-only" role="status">{status}</div>}
   <div className="workspace">
    <aside className="criteria-panel panel"><div className="section-heading"><div><span className="step">01</span><h2>Set your priorities</h2></div><SlidersHorizontal size={18}/></div><p className="section-copy">Give more weight to what matters most.</p>
     <div className="criteria-list">{board.criteria.map((c,i)=><div className="criterion" key={c.id}><div className="criterion-top"><span className="criterion-dot" style={{background:['#1948e6','#1b93b2','#b05bdc','#e0a128'][i%4]}}/><input aria-label={`Criterion ${i+1} name`} placeholder="Criterion name" maxLength={80} value={c.name} onChange={e=>criterion(c.id,{name:e.target.value})}/><button className="icon-button remove" aria-label={`Remove criterion ${c.name||i+1}`} onClick={()=>removeCriterion(c.id)} disabled={saving}><X size={15}/></button></div><div className="weight-row"><input type="range" min={0} max={100} aria-label={`Weight for ${c.name||'criterion '+(i+1)}`} value={c.weight} onChange={e=>criterion(c.id,{weight:Number(e.target.value)})}/><input className="weight-input" type="number" min={0} max={100} aria-label={`Numeric weight for ${c.name||'criterion '+(i+1)}`} value={c.weight} onChange={e=>criterion(c.id,{weight:Math.min(100,Math.max(0,Math.round(Number(e.target.value)||0)))})}/></div><div className="weight-meta"><span>Weight</span><span>{weights?Math.round(c.weight/weights*100):0}% of total</span></div></div>)}</div>
     {!board.criteria.length&&<p className="empty-copy">Add a criterion to start scoring.</p>}
     <button className="add-button" disabled={board.criteria.length>=12||saving} onClick={addCriterion}><Plus size={16}/> Add criterion</button><div className="weight-tip"><Scale size={17}/><p>Weights adjust automatically to 100%. A weight of 0 excludes a criterion.</p></div>
    </aside>
    <div className="main-column">
    <section className="scoring-panel panel"><div className="section-heading"><div><span className="step">02</span><h2>Explore your options</h2></div><span className="count-label">{board.options.length} options</span></div>
     <div className="tabs-row"><div className="tabs" role="tablist" aria-label="Comparison view"><button role="tab" aria-selected={tab==='score'} className={tab==='score'?'active':''} onClick={()=>setTab('score')}><LayoutGrid size={15}/> Score options</button><button role="tab" aria-selected={tab==='compare'} className={tab==='compare'?'active':''} onClick={()=>setTab('compare')}><Scale size={16}/> Compare tradeoffs</button></div><span className="rating-key">0 = poor · 10 = excellent</span></div>
     {tab==='score'?<div role="tabpanel" aria-label="Score options">
      <div className="table-scroll"><table className="score-table" style={{minWidth:Math.max(530,236+board.options.length*154)}}><thead><tr><th className="criteria-col">Criteria <span>Relative weight</span></th>{board.options.map((o,i)=><th key={o.id}><div className="option-head"><span className="option-letter">{String.fromCharCode(65+i)}</span><button className="icon-button remove" aria-label={`Remove option ${o.name||i+1}`} onClick={()=>removeOption(o.id)} disabled={saving}><X size={14}/></button></div><input aria-label={`Option ${i+1} name`} value={o.name} placeholder={`Option ${String.fromCharCode(65+i)}`} maxLength={100} onChange={e=>option(o.id,{name:e.target.value})}/></th>)}<th className="add-option-col"><button className="add-option" aria-label="Add option" title="Add option" disabled={board.options.length>=8||saving} onClick={addOption}><Plus size={20}/></button></th></tr></thead><tbody>{board.criteria.map(c=><tr key={c.id}><th scope="row">{c.name||'Unnamed criterion'}<span>{weights?Math.round(c.weight/weights*100):0}%</span></th>{board.options.map(o=><td key={o.id}><div className="score-control"><select aria-label={`${o.name||'Unnamed option'} score for ${c.name||'Unnamed criterion'}`} value={o.scores[c.id]??''} onChange={e=>rate(o.id,c.id,e.target.value)}><option value="">—</option>{Array.from({length:11},(_,n)=><option key={n} value={n}>{n}</option>)}</select><ChevronDown size={13}/></div></td>)}<td/></tr>)}</tbody><tfoot><tr><th>Weighted score<span>Out of 10</span></th>{board.options.map(o=><td key={o.id}><strong>{scoreOption(board,o)?.toFixed(2)??'—'}</strong></td>)}<td/></tr></tfoot></table></div>
      <div className="matrix-footer"><span>{needed?`${rated} of ${needed} ratings complete`:'Add weighted criteria to begin'}</span><button className="text-button" onClick={addOption} disabled={board.options.length>=8||saving}><Plus size={14}/> Add option</button></div>
      <details className="option-notes"><summary>Notes & tradeoffs <span>Capture what the numbers miss</span></summary><div className="notes-grid">{board.options.map((o,i)=><label key={o.id}>{o.name||`Option ${String.fromCharCode(65+i)}`}<textarea maxLength={2000} value={o.notes} placeholder="Benefits, concerns, or assumptions…" onChange={e=>option(o.id,{notes:e.target.value})}/></label>)}</div></details>
     </div>:<div className="comparison" role="tabpanel" aria-label="Compare tradeoffs">
      {board.options.length<2?<p className="empty-copy">Add at least two options to compare them.</p>:<><div className="pair-selects"><label>Option A<select aria-label="Compare option A" value={a?.id??''} onChange={e=>setPair([e.target.value,b?.id??''])}>{board.options.map((o,i)=><option key={o.id} value={o.id}>{o.name||`Option ${i+1}`}</option>)}</select></label><span>vs.</span><label>Option B<select aria-label="Compare option B" value={b?.id??''} onChange={e=>setPair([a?.id??'',e.target.value])}>{board.options.map((o,i)=><option key={o.id} value={o.id}>{o.name||`Option ${i+1}`}</option>)}</select></label></div>
      <p className="comparison-help">Each bar shows how much a criterion contributes to the total score.</p>
      {a?.id===b?.id?<div className="notice">Choose two different options to compare.</div>:board.criteria.map((c,i)=>{const av=a?.scores[c.id],bv=b?.scores[c.id];const ac=weights?(av??0)*c.weight/weights:0,bc=weights?(bv??0)*c.weight/weights:0;return <div className="tradeoff-row" key={c.id}><div className="tradeoff-label"><strong>{c.name||'Unnamed criterion'}</strong><span>{weights?Math.round(c.weight/weights*100):0}% weight</span></div><div className="comparison-bars"><div><span className="bar-track"><span style={{width:`${ac*10}%`}}/></span><b>{av==null?'Unrated':`${av}/10`}</b><span className="contribution">{av==null?'—':`+${ac.toFixed(2)}`}</span></div><div><span className="bar-track second"><span style={{width:`${bc*10}%`}}/></span><b>{bv==null?'Unrated':`${bv}/10`}</b><span className="contribution">{bv==null?'—':`+${bc.toFixed(2)}`}</span></div></div></div>;})}
      <div className="comparison-notes">{[a,b].map((o,i)=><div key={i}><span className={`legend-dot ${i?'second':''}`}/><strong>{o?.name||`Option ${i+1}`}</strong><p>{o?.notes||'No notes yet. Add them in Score options.'}</p></div>)}</div></>}
     </div>}
    </section>
    <div className="results-grid"><section className="ranking-panel panel"><div className="section-heading"><div><span className="step">03</span><h2>See the balance</h2></div><span className="small-label">LIVE RANKING</span></div><p className="section-copy">{ranks.length>1&&ranks[0].score!=null&&ranks[1].score!=null&&Math.abs(ranks[0].score-ranks[1].score)<0.00001?'The top options are tied. Review their tradeoffs.':rated<needed?'Complete all ratings for a fair comparison.':'Based on your current weights and ratings.'}</p><div className="ranking-list">{ranks.map(({option:o,score},i)=><div key={o.id} className={`rank-row ${preferred===o.id?'selected':''}`}><span className="rank-number">{score==null?'—':i+1}</span><div className="rank-detail"><strong>{o.name||'Unnamed option'}</strong><div className="rank-track"><span style={{width:`${(score??0)*10}%`}}/></div></div><span className="rank-score">{score?.toFixed(2)??'—'}<small>/ 10</small></span><button className="prefer-button" aria-label={`Prefer ${o.name||'unnamed option'}`} aria-pressed={preferred===o.id} disabled={!!problem||saving} onClick={()=>setPreferred(o.id)}>{preferred===o.id?<Check size={15}/>:'Prefer'}</button></div>)}</div>{!board.options.length&&<p className="empty-copy">Your options will appear here.</p>}<details className="formula"><summary>How scoring works</summary><p>Weighted score = sum of each rating × its weight, divided by the total weight. Unrated options stay incomplete. Higher scores are better, including cost and risk: rate how well the option meets your needs.</p></details></section>
    <section className="choice-panel panel"><div className="section-heading"><div><BookmarkCheck size={20}/><h2>Your preferred choice</h2></div></div><p className="section-copy">The numbers inform the choice. You make it.</p><label className="field-label">Preferred option<select aria-label="Preferred option" value={preferred} onChange={e=>setPreferred(e.target.value)} disabled={saving}><option value="">Choose an option</option>{board.options.map((o,i)=><option key={o.id} value={o.id}>{o.name||`Option ${i+1}`}</option>)}</select></label><label className="field-label">Why this choice? <span>Optional</span><textarea aria-label="Choice rationale" maxLength={4000} value={rationale} onChange={e=>setRationale(e.target.value)} placeholder="The deciding factor, and the tradeoff you accept…"/></label><button className="primary choice-save" disabled={saving||!!problem||!selected} onClick={()=>save(true)}><BookmarkCheck size={17}/>{saving?'Saving…':'Save preferred choice'}</button>{problem&&<p className="validation-hint">{problem}</p>}
    </section></div>
    </div>
   </div>
   {choice&&<section className="saved-choice"><div className="saved-icon"><CheckCircle2 size={25}/></div><div className="saved-content"><span className="eyebrow">SAVED PREFERRED CHOICE</span><h2>{choice.optionName}<span>{choice.score.toFixed(2)} / 10</span></h2><p>{choice.rationale||'No rationale added.'}</p><div className="saved-meta">Saved {new Date(choice.savedAt).toLocaleString()}{choiceChanged&&<span>Board changed since this choice was saved. Review and save again.</span>}</div></div><button className="secondary" onClick={()=>setShowSaved(v=>!v)}>{showSaved?'Hide saved scores':'View saved scores'}</button>{showSaved&&<div className="saved-snapshot"><strong>{choice.snapshot.title}</strong><div className="table-scroll"><table><thead><tr><th>Criterion</th><th>Weight</th>{choice.snapshot.options.map(o=><th key={o.id}>{o.name}</th>)}</tr></thead><tbody>{choice.snapshot.criteria.map(c=><tr key={c.id}><th>{c.name}</th><td>{c.weight}</td>{choice.snapshot.options.map(o=><td key={o.id}>{o.scores[c.id]??'—'}</td>)}</tr>)}</tbody></table></div></div>}</section>}
   <footer><span><LockKeyhole size={13}/> A private space for your decisions.</span><span>Score thoughtfully. Weigh the tradeoffs. Keep the reason.</span></footer>
   </>}
  </main>
 </div>;
}
