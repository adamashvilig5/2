'use client';
import { useState } from 'react';
import { Check,Plus,Sparkles,ExternalLink } from 'lucide-react';
import { ICT_CATEGORIES,ICT_CONDITIONS,hasICTCondition } from '@/lib/ict-checklist';
import { useLanguage } from './journal-language';

export default function ICTSuggestions({checklist,onAdd,disabled=false}:{checklist:string[];onAdd:(id:string)=>void;disabled?:boolean}){
 const {t,language}=useLanguage(),[category,setCategory]=useState<string>('all');
 const visible=ICT_CONDITIONS.filter(c=>category==='all'||c.category===category);
 return <details className="ict-suggestions" open><summary><Sparkles size={17}/><span>{t('ICT ჩეკლისტის იდეები')}<small>{t('აირჩიე შენი მოდელისთვის შესაფერისი პირობები')}</small></span><b>24</b></summary><div className="ict-suggestion-body"><p>{t('პუნქტზე დაჭერით ის შენს ჩეკლისტში დაემატება. შეგიძლია ტექსტი შეცვალო ან წაშალო.')}</p><div className="ict-category-tabs" role="group" aria-label={t('ICT პირობების კატეგორია')}><button type="button" disabled={disabled} className={category==='all'?'active':''} aria-pressed={category==='all'} onClick={()=>setCategory('all')}>{t('ყველა')}</button>{ICT_CATEGORIES.map(c=><button type="button" key={c.id} disabled={disabled} className={category===c.id?'active':''} aria-pressed={category===c.id} onClick={()=>setCategory(c.id)}>{(language==='ru'?t(c.en):c[language])}</button>)}</div><div className="ict-suggestion-list">{visible.map(c=>{const added=hasICTCondition(checklist,c);return <button type="button" key={c.id} disabled={disabled||added||checklist.length>=16} className={added?'added':''} onClick={()=>onAdd(c.id)} aria-label={`${(language==='ru'?t(c.en):c[language])} · ${added?t('დამატებულია'):t('დამატება')}`}><span>{(language==='ru'?t(c.en):c[language])}</span>{added?<Check size={15}/>:<Plus size={15}/>}</button>;})}</div><div className="ict-source"><span>{t('შენ ირჩევ პირობებს · მაქსიმუმ 16')}</span><a href="https://www.youtube.com/watch?v=Bkt8B3kLATQ" target="_blank" rel="noreferrer">ICT 2022 Mentorship <ExternalLink size={12}/></a></div></div></details>;
}
