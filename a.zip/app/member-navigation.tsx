'use client';
import {useEffect,useState} from 'react';
import {useLanguage} from './journal-language';
export default function MemberNavigation(){const {t}=useLanguage(),[admin,setAdmin]=useState(false);useEffect(()=>{let live=true;fetch('/api/membership',{cache:'no-store'}).then(r=>r.ok?r.json():null).then((data:any)=>{if(live)setAdmin(data?.admin===true);}).catch(()=>{});return()=>{live=false;};},[]);return <div className="member-nav-links"><a href="/imports">{t("CSV იმპორტი")}</a><a href="/membership">{t('გამოწერა / სატესტო რეგისტრაცია')}</a>{admin&&<a href="/admin">{t('ადმინი')}</a>}</div>;}
