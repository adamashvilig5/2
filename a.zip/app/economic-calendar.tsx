'use client';

import {useCallback,useEffect,useMemo,useRef,useState} from 'react';
import {Download,Info,Newspaper,RefreshCw,ExternalLink} from 'lucide-react';
import {useLanguage} from './journal-language';
import {economicDay,type EconomicEvent} from '@/lib/economic-news';
import EconomicEventRows from './economic-event-rows';
import JournalDateRange from './journal-date-range';
import {todayIn} from '@/lib/trading';

export type CalendarFeed={events:EconomicEvent[];updatedAt:string;stale:boolean;coverage:{start:string;end:string};source:string;schemaVersion?:number|null;sourceUrl:string;coveragePeriods?:{start:string;end:string;updatedAt:string}[];missingDates?:string[];partial?:boolean};
export function useEconomicCalendar(from?:string,to?:string,timezone="America/New_York",enabled=!!from&&!!to){
 const [data,setData]=useState<CalendarFeed|null>(null),[loading,setLoading]=useState(false),[error,setError]=useState(false),sequence=useRef(0);
 const refresh=useCallback(async()=>{
  if(!enabled)return;
  const requestId=++sequence.current;setLoading(true);setError(false);
  const queryUrl=()=>`/api/calendar?from=${from}&to=${to}&timezone=${encodeURIComponent(timezone)}`;
  try{
   const response=await fetch(queryUrl(),{cache:'no-store'});if(!response.ok)throw Error();const next=await response.json() as CalendarFeed;
   if(requestId===sequence.current)setData(next);
  }catch{if(requestId===sequence.current)setError(true);}
  finally{if(requestId===sequence.current)setLoading(false);}
 },[from,to,timezone,enabled]);
 useEffect(()=>{if(!enabled)return;const start=setTimeout(()=>void refresh(),0),id=setInterval(()=>void refresh(),3600000);return()=>{clearTimeout(start);clearInterval(id);};},[refresh,enabled]);
 return {data,loading:enabled&&loading,error:enabled&&error,refresh};
}

export default function EconomicCalendar({feed,timezone,selectedRange,onRange,events,currencies,onCurrencies,impacts,onImpacts}:{feed:ReturnType<typeof useEconomicCalendar>;timezone:string;selectedRange:{from:string;to:string}|null;onRange:(range:{from:string;to:string}|null)=>void;events:EconomicEvent[];currencies:string[];onCurrencies:(c:string[])=>void;impacts:string[];onImpacts:(i:string[])=>void}){
 const {language,locale,t}=useLanguage(),c=(en:string,ka:string)=>language==='ka'?ka:t(en);
 const [query,setQuery]=useState(''),[range,setRange]=useState<{from:string;to:string}|null>(null);
 const impact=(value:string)=>({High:c('High','მაღალი'),Medium:c('Medium','საშუალო'),Low:c('Low','დაბალი'),Holiday:c('Holiday','დასვენება'),Unknown:c('Unknown','უცნობი')}[value]??value);
 const rows=useMemo(()=>selectedRange?events.filter(event=>{
  const day=economicDay(event,timezone);
  return day>=selectedRange.from&&day<=selectedRange.to&&event.title.toLowerCase().includes(query.toLowerCase());
 }):[],[events,timezone,query,selectedRange]);
 const toggle=(values:string[],value:string)=>values.includes(value)?values.filter(item=>item!==value):[...values,value];

 return <section className="economic-panel" aria-label={c('Economic calendar','ეკონომიკური კალენდარი')}>
  <div className="economic-heading">
   <h2><Newspaper size={19}/>{c('Economic calendar','ეკონომიკური კალენდარი')}<span className="economic-result-count">{rows.length}</span></h2>
   <div className="economic-heading-actions">
    <button className="economic-icon-button" disabled={!selectedRange||feed.loading} onClick={()=>void feed.refresh()} aria-label={c('Refresh calendar','კალენდრის განახლება')} title={c('Refresh','განახლება')}><RefreshCw size={16}/></button>
    {selectedRange&&<a className="economic-icon-button" aria-label={c('Download CSV','CSV-ის ჩამოტვირთვა')} title={c('Download CSV','CSV-ის ჩამოტვირთვა')} href={`/api/calendar/export?from=${selectedRange.from}&to=${selectedRange.to}&timezone=${encodeURIComponent(timezone)}&currency=${currencies.join(',')}&impact=${impacts.join(',')}`}><Download size={16}/></a>}
    <details className="economic-source-info"><summary aria-label={c('Sources','წყაროები')} title={c('Sources','წყაროები')}><Info size={16}/></summary><div><a href="https://www.forexfactory.com/calendar" target="_blank" rel="noopener noreferrer">Forex Factory <ExternalLink size={12}/></a></div></details>
   </div>
  </div>

  <div className="economic-filters">
   <fieldset><legend>{c('Currency','ვალუტა')}</legend><div className="economic-filter-options">{['USD','EUR','GBP','JPY','CAD','AUD','NZD','CHF','CNY','ALL'].map(value=><label key={value}><input type="checkbox" checked={currencies.includes(value)} onChange={()=>onCurrencies(toggle(currencies,value))}/><span>{value}</span></label>)}<button onClick={()=>onCurrencies(['USD','EUR','GBP','JPY','CAD','AUD','NZD','CHF','CNY','ALL'])}>{c('All','ყველა')}</button><button onClick={()=>onCurrencies([])}>{c('Clear','გასუფთავება')}</button></div></fieldset>
   <fieldset><legend>{c('Impact','მნიშვნელობა')}</legend><div className="economic-filter-options">{['High','Medium','Low','Holiday','Unknown'].map(value=><label key={value}><input type="checkbox" checked={impacts.includes(value)} onChange={()=>onImpacts(toggle(impacts,value))}/><span><i className={`news-impact ${value.toLowerCase()}`}/>{impact(value)}</span></label>)}</div></fieldset>
  </div>

  <div className="economic-controls">
   <JournalDateRange from={selectedRange?.from??range?.from} to={selectedRange?.to??range?.to} today={todayIn(timezone)} onApply={(from,to)=>{setRange({from,to});onRange({from,to});}}/>
   <input aria-label={c('Search events','მოვლენების ძებნა')} placeholder={c('Search…','ძებნა…')} value={query} onChange={event=>setQuery(event.target.value)}/>
  </div>

  {selectedRange&&(feed.error||feed.data?.stale)&&<p className="economic-warning" role="status">{c('Calendar update failed. Showing saved events.','კალენდარი ვერ განახლდა. ნაჩვენებია შენახული მოვლენები.')}</p>}
  {!selectedRange?<p className="economic-empty">{c('Select a date range above to load economic news.','სიახლეების სანახავად აირჩიე თარიღების შუალედი და დააჭირე „გამოყენება“.')}</p>:feed.loading&&!feed.data?<p className="economic-empty">{c('Loading…','იტვირთება…')}</p>:rows.length?<EconomicEventRows events={rows} timezone={timezone} locale={locale} language={language}/>:!feed.error&&<p className="economic-empty">{c('No events for this selection.','ამ არჩევანში მოვლენები არ არის.')}</p>}
 </section>;
}
