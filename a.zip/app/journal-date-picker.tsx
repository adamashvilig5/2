'use client';
import { useLanguage } from './journal-language';
import { useState } from 'react';
import { CalendarDays, ChevronDown } from 'lucide-react';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { ka, enUS, ru } from 'date-fns/locale';
// Calendar dates represent the journal's timezone, not an instant in the browser's timezone.
const asDate = (value: string) => { const [year, month, day] = value.split('-').map(Number); return new Date(year, month - 1, day, 12); };
const asValue = (date: Date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
export default function JournalDatePicker({ value, onChange, label, today, max, disabled = false, compact = false }: {
    value: string;
    onChange: (date: string) => void;
    label: string;
    today: string;
    max?: string;
    disabled?: boolean;
    compact?: boolean;
}) {
    const { t, language, locale } = useLanguage();
    const [open, setOpen] = useState(false), [month, setMonth] = useState(asDate(value));
    const selected = asDate(value), title = new Intl.DateTimeFormat(locale, { year: 'numeric', month: 'long', day: 'numeric' }).format(selected);
    return <Popover open={open} onOpenChange={next => {
            setOpen(next);
            if (next)
                setMonth(selected);
        }}><PopoverTrigger asChild><button type="button" className={`journal-date-trigger ${compact ? 'compact' : ''}`} disabled={disabled} aria-label={`${label}: ${title}`}><CalendarDays size={17}/><span>{compact ? value : title}</span><ChevronDown size={15}/></button></PopoverTrigger><PopoverContent align="start" sideOffset={8} className="journal-date-popover" data-journal-date-popover onEscapeKeyDown={e => e.stopPropagation()}><div className="date-picker-heading"><span>{label}</span><strong>{title}</strong></div><Calendar mode="single" required selected={selected} month={month} onMonthChange={setMonth} locale={language === 'ka' ? ka : language === 'ru' ? ru : enUS} today={asDate(today)} disabled={max ? { after: asDate(max) } : undefined} onSelect={date => {
            if (date) {
                onChange(asValue(date));
                setOpen(false);
            }
        }} className="journal-mini-calendar"/><div className="date-picker-footer"><button type="button" className="inline-link" disabled={!!max && today > max} onClick={() => { onChange(today); setMonth(asDate(today)); setOpen(false); }}>{t("დღეს")}</button><span>{t("არჩეული: ")}{value}</span></div></PopoverContent></Popover>;
}
