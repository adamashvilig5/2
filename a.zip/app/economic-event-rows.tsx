'use client';

import {economicDay,type EconomicEvent} from '@/lib/economic-news';
import type {JournalLanguage} from '@/lib/journal-language';
import {CalendarDays} from 'lucide-react';

export default function EconomicEventRows({events,timezone,locale,language}:{events:EconomicEvent[];timezone:string;locale:string;language:JournalLanguage}){
 const c=(en:string,ka:string,ru:string)=>language==='ka'?ka:language==='ru'?ru:en;
 const eventCount=(count:number)=>language==='ka'?`${count} მოვლენა`:language==='ru'?`${count} событий`:`${count} ${count===1?'event':'events'}`;
 const impact=(value:EconomicEvent['impact'])=>({High:c('High','მაღალი','Высокий'),Medium:c('Medium','საშუალო','Средний'),Low:c('Low','დაბალი','Низкий'),Holiday:c('Holiday','დასვენება','Выходной'),Unknown:c('Unknown','უცნობი','Неизвестно')}[value]);
 const grouped=new Map<string,EconomicEvent[]>();
 for(const event of events){const day=economicDay(event,timezone);grouped.set(day,[...(grouped.get(day)??[]),event]);}
 return <div className="economic-event-day-list">{[...grouped].sort(([a],[b])=>a.localeCompare(b)).map(([day,dayEvents])=>{
  const dateLabel=new Intl.DateTimeFormat(locale,{timeZone:'UTC',weekday:'long',month:'long',day:'numeric',year:'numeric'}).format(new Date(`${day}T12:00:00Z`));
  return <section className="economic-event-day-group" key={day}>
   <header><CalendarDays size={17}/><h3>{dateLabel}</h3><span>{eventCount(dayEvents.length)}</span></header>
   <div className="economic-event-list">{dayEvents.sort((a,b)=>a.date.localeCompare(b.date)).map(event=>{
  const time=event.allDay?c('All day','მთელი დღე','Весь день'):new Intl.DateTimeFormat(locale,{timeZone:timezone,hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(new Date(event.date));
  const values=[[c('Actual','ფაქტობრივი','Факт'),event.actual],[c('Forecast','პროგნოზი','Прогноз'),event.forecast],[c('Previous','წინა','Предыдущее'),event.previous]].filter(([,value])=>!!value);
  return <article className="economic-event-row" key={event.id}>
   <div className="economic-event-when"><time>{time}</time></div>
   <span className="economic-event-currency">{event.currency}</span>
   <span className={`news-pill ${event.impact.toLowerCase()}`}><i className={`news-impact ${event.impact.toLowerCase()}`}/>{impact(event.impact)}</span>
   <div className="economic-event-main"><strong>{event.title}</strong>{values.length>0&&<details><summary>{c('Details','დეტალები','Данные')}</summary><div>{values.map(([label,value])=><span key={label}><small>{label}</small><b>{value}</b></span>)}</div></details>}</div>
  </article>;
   })}</div>
  </section>;
 })}</div>;
}
