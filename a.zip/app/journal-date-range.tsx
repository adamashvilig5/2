'use client';
import {useState} from 'react';
import {CalendarDays,ChevronDown} from 'lucide-react';
import {Calendar} from '@/components/ui/calendar';
import {Popover,PopoverContent,PopoverTrigger} from '@/components/ui/popover';
import {ka,enUS,ru} from 'date-fns/locale';
import {addDays,startOfWeek,startOfMonth,endOfMonth,addMonths} from 'date-fns';
import type {DateRange} from 'react-day-picker';
import {useLanguage} from './journal-language';
const fromValue=(v:string)=>{const [y,m,d]=v.split('-').map(Number);return new Date(y,m-1,d,12);};
const value=(d:Date)=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
export default function JournalDateRange({from,to,today,onApply}:{from?:string;to?:string;today:string;onApply:(from:string,to:string)=>void}){
 const {language,t}=useLanguage(),c=(en:string,ge:string)=>language==='ka'?ge:t(en);const [open,setOpen]=useState(false),[draft,setDraft]=useState<DateRange|undefined>(),[month,setMonth]=useState(fromValue(from??today));
 const pick=(a:Date,b:Date)=>{setDraft({from:a,to:b});setMonth(a);};
 return <Popover open={open} onOpenChange={v=>{setOpen(v);if(v){setDraft(from&&to?{from:fromValue(from),to:fromValue(to)}:undefined);setMonth(fromValue(from??today));}}}><PopoverTrigger asChild><button type="button" className="journal-date-trigger compact" aria-label={`${c('Date range','თარიღების შუალედი')}${from&&to?`: ${from} – ${to}`:''}`}><CalendarDays size={17}/><span>{from&&to?`${from} – ${to}`:c('Choose dates','აირჩიე თარიღები')}</span><ChevronDown size={15}/></button></PopoverTrigger><PopoverContent align="start" className="journal-date-popover journal-range-popover" data-journal-date-popover><div className="date-picker-heading"><span>{c('Date range','თარიღების შუალედი')}</span><strong>{draft?.from?value(draft.from):'—'} – {draft?.to?value(draft.to):c('Select end date','აირჩიე ბოლო დღე')}</strong><p>{c('Click the first day, then the last day.','დააჭირე პირველ დღეს, შემდეგ — ბოლო დღეს.')}</p></div><Calendar mode="range" selected={draft} onSelect={setDraft} month={month} onMonthChange={setMonth} numberOfMonths={2} locale={language==='ka'?ka:language==='ru'?ru:enUS} today={fromValue(today)} className="journal-mini-calendar"/><div className="range-shortcuts">{[c('This week','ეს კვირა'),c('Next week','შემდეგი კვირა'),c('This month','ეს თვე'),c('Next month','შემდეგი თვე')].map((label,i)=><button type="button" key={i} onClick={()=>{const current=fromValue(today);if(i<2){const start=startOfWeek(addDays(current,i*7),{weekStartsOn:1});pick(start,addDays(start,6));}else{const start=startOfMonth(addMonths(current,i-2));pick(start,endOfMonth(start));}}}>{label}</button>)}</div><div className="range-footer"><button type="button" className="secondary" onClick={()=>setOpen(false)}>{c('Cancel','გაუქმება')}</button><button type="button" className="primary" disabled={!draft?.from||!draft.to} onClick={()=>{if(draft?.from&&draft.to){onApply(value(draft.from),value(draft.to));setOpen(false);}}}>{c('Apply','გამოყენება')}</button></div></PopoverContent></Popover>;
}
