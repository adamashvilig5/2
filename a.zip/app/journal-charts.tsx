'use client';
import {useId} from 'react';
import { useLanguage } from './journal-language';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar, RadarChart, PolarGrid, PolarAngleAxis, Radar, PolarRadiusAxis, Cell } from 'recharts';
import { money } from '@/lib/trading';
type Point = {
    date: string;
    equity: number;
    pnl: number;
    winRate: number;
    benchmark?: number;
    drawdown?: number;
    trades?: number;
};
const tip = { background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 9, color: 'var(--text)', fontSize: 13 };
export function PerformanceChart({ data, mode, currency = 'USD',equityLabel,animated=false }: {
    data: Point[];
    mode: 'equity' | 'pnl' | 'winRate' | 'drawdown' | 'trades';
    currency?: string;
    equityLabel?:string;
    animated?:boolean;
}) {
    const { t, locale } = useLanguage();
    const gradientId=useId();
    const axis = { tick: { fill: 'var(--muted)', fontSize: 12 }, axisLine: false, tickLine: false };
    const isPercent=mode==='winRate'||mode==='drawdown',isCount=mode==='trades',color=mode==='drawdown'?'var(--chart-negative)':mode==='equity'||mode==='winRate'?'var(--chart-positive)':'var(--chart-accent)';
    const common = <><CartesianGrid stroke="var(--chart-grid)" strokeDasharray="3 5" vertical={false}/><XAxis dataKey="date" {...axis} minTickGap={50} tickFormatter={v => String(v).slice(5)}/><YAxis {...axis} width={65} domain={isPercent ? [0, mode==='winRate'?100:'auto'] : ['auto', 'auto']} tickFormatter={v => isPercent ? `${Number(v).toFixed(0)}%` : isCount ? String(Math.round(Number(v))) : Math.abs(v) >= 1000 ? `${(v / 1000).toFixed(1)}k` : money(Number(v), currency)}/><Tooltip cursor={mode === 'pnl'||isCount ? {fill:'var(--accent-soft)',stroke:'none'} : {stroke:'var(--border-strong)'}} itemStyle={{color:'var(--text)'}} contentStyle={tip} labelFormatter={v=>new Intl.DateTimeFormat(locale,{timeZone:'UTC',weekday:'short',month:'short',day:'numeric',year:'numeric'}).format(new Date(String(v)+'T12:00:00Z'))} labelStyle={{ color: 'var(--text)', marginBottom: 7 }} formatter={(value,name) => [isPercent ? `${Number(value).toFixed(1)}%` : isCount ? String(Math.round(Number(value))) : money(Number(value), currency), name==='benchmark'?t('7-day average'):mode==='equity'?(equityLabel??t('Equity')):t(mode==='pnl'?'Daily P&L':mode==='winRate'?'Win rate':mode==='drawdown'?'Drawdown':'Trades')]}/></>;
    return <div className="performance-chart"><ResponsiveContainer width="100%" height="100%">{mode === 'pnl'||isCount ? <BarChart data={data} margin={{ left: 0, right: 14, top: 14, bottom: 0 }}>{common}<Bar dataKey={isCount?'trades':'pnl'} radius={[3, 3, 0, 0]} isAnimationActive={animated} animationDuration={1100} animationEasing="ease-out">{data.map((p, i) => <Cell key={i} fill={isCount?'var(--chart-accent)':p.pnl < 0 ? 'var(--chart-negative)' : 'var(--chart-positive)'}/>)}</Bar></BarChart> : <AreaChart data={data} margin={{ left: 0, right: 14, top: 14, bottom: 0 }}>{common}<defs><linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={color} stopOpacity={.24}/><stop offset="100%" stopColor={color} stopOpacity={0}/></linearGradient></defs><Area type="monotone" dataKey={mode} stroke={color} strokeWidth={2.5} fill={`url(#${gradientId})`} isAnimationActive={animated} animationDuration={1400} animationEasing="ease-out" activeDot={{ r: 4, fill: 'var(--accent-text)', stroke: 'var(--accent)' }}/>{mode==='equity'&&<Area type="monotone" dataKey="benchmark" stroke="var(--chart-secondary,var(--accent-text))" strokeWidth={1.7} strokeDasharray="5 5" fill="none" isAnimationActive={animated} animationDuration={1200} dot={false} activeDot={false}/>}</AreaChart>}</ResponsiveContainer></div>;
}
export function ScoreChart({ data }: {
    data: {
        label: string;
        value: number;
    }[];
}) { const { t } = useLanguage(); return <div className="radar-chart"><ResponsiveContainer width="100%" height="100%"><RadarChart data={data.map(point=>({...point,label:t(point.label)}))} outerRadius="65%"><PolarGrid stroke="var(--chart-grid)"/><PolarAngleAxis dataKey="label" tick={{ fill: 'var(--muted)', fontSize: 12 }}/><PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false}/><Radar dataKey="value" stroke="var(--chart-positive)" fill="var(--chart-positive)" fillOpacity={.18} strokeWidth={2} isAnimationActive={false}/><Tooltip itemStyle={{color:'var(--text)'}} labelStyle={{color:'var(--text)'}} contentStyle={tip} formatter={v => [`${Number(v).toFixed(1)} / 100`, t('Score')]}/></RadarChart></ResponsiveContainer></div>; }
