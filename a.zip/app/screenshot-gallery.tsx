'use client';
import { useLanguage } from './journal-language';
import { useEffect, useState } from 'react';
import { ClipboardPaste, Image as ImageIcon, Upload, X } from 'lucide-react';
import { MAX_SCREENSHOTS, phaseLabel, type Shot } from '@/lib/trading';
export type PendingShot = {
    id: string;
    phase: Shot['phase'];
    file: File;
};
function LocalPhoto({ file }: {
    file: File;
}) { const { t, language, locale } = useLanguage(); const [url, setUrl] = useState(''); useEffect(() => { const next = URL.createObjectURL(file); setUrl(next); return () => URL.revokeObjectURL(next); }, [file]); return url ? <img src={url} alt={file.name}/> : <span>{t("ფოტო იტვირთება\u2026")}</span>; }
export function ScreenshotEditor({ saved, pending, removals, busy, onAdd, onRemove, onError }: {
    saved: Shot[];
    pending: PendingShot[];
    removals: string[];
    busy: boolean;
    onAdd: (files: File[], phase: Shot['phase']) => void;
    onRemove: (id: string, pending: boolean) => void;
    onError: (message: string) => void;
}) {
    const { t, language, locale } = useLanguage();
    const [phase, setPhase] = useState<Shot['phase']>('context');
    const photos = saved.filter(s => !removals.includes(s.id)), count = photos.length + pending.length;
    useEffect(() => {
        const paste = (e: ClipboardEvent) => {
            if (busy)
                return;
            const files = Array.from(e.clipboardData?.files ?? []).filter(f => f.type.startsWith('image/'));
            if (!files.length)
                return;
            e.preventDefault();
            onAdd(files, phase);
        };
        document.addEventListener('paste', paste);
        return () => document.removeEventListener('paste', paste);
    }, [busy, onAdd, phase]);
    async function readClipboard() {
        try {
            if (!navigator.clipboard?.read)
                throw new Error('unsupported');
            const items = await navigator.clipboard.read(), files: File[] = [];
            for (const item of items) {
                const type = item.types.find(t => ['image/png', 'image/jpeg', 'image/webp'].includes(t));
                if (type) {
                    const blob = await item.getType(type);
                    files.push(new File([blob], `pasted-${Date.now()}-${files.length}.${type === 'image/jpeg' ? 'jpg' : type.split('/')[1]}`, { type }));
                }
            }
            if (!files.length) {
                onError(t("Clipboard-ზე ფოტო არ არის. დააკოპირე სქრინშოტი და გამოიყენე Ctrl+V."));
                return;
            }
            onAdd(files, phase);
        }
        catch {
            onError(t("Clipboard-ის წაკითხვა ვერ მოხერხდა. ფორმაში დააჭირე Ctrl+V / \u2318V."));
        }
    }
    return <section className="form-section screenshot-section"><h3><ImageIcon size={18}/>{t(" TradingView Screenshots ")}<span>{count} / {MAX_SCREENSHOTS}</span></h3><p className="section-help">{t("დააკოპირე ფოტო და ამ ფორმაში დააჭირე Ctrl+V / \u2318V. შეგიძლია რამდენიმე ფაილიც ერთად აირჩიო. PNG, JPG, WebP \u00B7 თითოეული მაქს. 8 MB.")}</p><div className="gallery-tools"><label className="field">{t("ახალი ფოტოების ეტაპი")}<select value={phase} onChange={e => setPhase(e.target.value as Shot['phase'])} disabled={busy}>{(['before', 'after', 'context'] as const).map(p => <option key={p} value={p}>{t(phaseLabel(p))}</option>)}</select></label><button type="button" className="secondary" disabled={busy || count >= MAX_SCREENSHOTS} onClick={readClipboard}><ClipboardPaste size={16}/>{t(" ჩასმა")}</button><label className={`gallery-upload ${busy || count >= MAX_SCREENSHOTS ? 'disabled' : ''}`}><Upload size={16}/>{t(" ფოტოების არჩევა")}<input type="file" multiple accept="image/png,image/jpeg,image/webp" aria-label={t("რამდენიმე სქრინშოტის ატვირთვა")} disabled={busy || count >= MAX_SCREENSHOTS} onChange={e => { onAdd(Array.from(e.target.files ?? []), phase); e.target.value = ''; }}/></label></div>
 <div className="photo-grid">{photos.map(s => <article className="photo-card" key={s.id}><img src={'/api/screenshots/' + s.id} alt={s.filename}/><div><span>{t(phaseLabel(s.phase))}</span><button type="button" className="icon-button danger" disabled={busy} aria-label={t("{v0} ფოტოს მოშორება", { v0: s.filename })} onClick={() => onRemove(s.id, false)}><X size={14}/></button></div><small>{s.filename}</small></article>)}{pending.map(p => <article className="photo-card pending" key={p.id}><LocalPhoto file={p.file}/><div><span>{t(phaseLabel(p.phase))}{t(" \u00B7 ახალი")}</span><button type="button" className="icon-button danger" disabled={busy} aria-label={t("{v0} ფოტოს მოშორება", { v0: p.file.name })} onClick={() => onRemove(p.id, true)}><X size={14}/></button></div><small>{p.file.name}</small></article>)}</div>{!count && <div className="paste-empty"><ClipboardPaste size={25}/><span>{t("ჩასვი პირველი სქრინშოტი")}</span></div>}</section>;
}
export function ScreenshotGallery({ shots, symbol }: {
    shots: Shot[];
    symbol: string;
}) { const { t, language, locale } = useLanguage(); return <div className="review-gallery"><h3>{t("სქრინშოტები \u00B7 ")}{shots.length}</h3>{shots.length ? <div className="photo-grid">{shots.map(s => <a key={s.id} className="photo-card" href={'/api/screenshots/' + s.id} target="_blank" rel="noreferrer"><img src={'/api/screenshots/' + s.id} alt={`${symbol} · ${t(phaseLabel(s.phase))}`}/><div><span>{t(phaseLabel(s.phase))}</span><span>{t("სრული ზომა")}</span></div></a>)}</div> : <div className="missing-shot"><ImageIcon size={28}/><span>{t("სქრინშოტი არ არის")}</span></div>}</div>; }
