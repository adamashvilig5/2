'use client';
import {Layers3} from 'lucide-react';
import {accountPerformance} from '@/lib/portfolio';
import {money,type Account,type Trade} from '@/lib/trading';
import {useLanguage} from './journal-language';
export default function PortfolioSummary({accounts,trades,start,end,onSelect}:{accounts:Account[];trades:Trade[];start:string;end:string;onSelect:(id:string)=>void}){
 const {t}=useLanguage(),rows=accountPerformance(trades,accounts,start,end);
 return <section className="panel portfolio-summary"><div className="panel-head"><div><h2><Layers3 size={18}/>{t('Account comparison')}</h2><p>{start} — {end} · {t('Select an account to explore its results')}</p></div></div><div className="table-scroll"><table className="trade-table"><thead><tr><th>{t('სავაჭრო ანგარიში')}</th><th>{t('ანგარიშის ტიპი')}</th><th>{t('Net P&L')}</th><th>{t('თრეიდები')}</th><th>{t('Win Rate')}</th><th>{t('Return')}</th></tr></thead><tbody>{rows.map(row=><tr key={row.account.id}><th><button className="inline-link" onClick={()=>onSelect(row.account.id)}>{row.account.name}</button><small>{row.account.currency}</small></th><td>{t(row.account.type)}</td><td className={row.pnl<0?'red-text':row.pnl>0?'green-text':''}>{money(row.pnl,row.account.currency)}</td><td>{row.count}</td><td>{row.winRate.toFixed(1)}%</td><td>{row.returnPct===null?'—':`${row.returnPct.toFixed(2)}%`}</td></tr>)}</tbody></table></div><p className="portfolio-footnote">{t('Each account keeps its own currency. Archived accounts are excluded from the portfolio.')}</p></section>;
}
