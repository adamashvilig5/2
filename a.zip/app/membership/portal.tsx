'use client';
import {startTransition,useEffect,useState,type FormEvent} from 'react';
import Link from 'next/link';
import {useRouter} from 'next/navigation';
import {ShieldCheck,UserPlus,LogIn,CreditCard,Check,LogOut,Settings2,RefreshCw,LockKeyhole,Mail,ArrowLeft,ExternalLink} from 'lucide-react';
import {LanguageSelector,useLanguage} from '../journal-language';
import {ThemeToggle} from '../theme-controls';
import {membershipCopy} from '@/lib/membership-copy';
import {hasAccess,type Member,type Subscription,type MembershipPlan,type BillingEvent} from '@/lib/membership';
import BillingCheckoutDialog from './billing-checkout-dialog';
import GoogleSignInButton from '../google-sign-in-button';
export type MembershipState={member:Member|null;viewer?:{name:string;email:string};subscription:Subscription|null;plan:MembershipPlan;admin:boolean;access:boolean;events:BillingEvent[];mode:'local-test'|'unconfigured'};
type AuthMode='register'|'login'|'forgot'|'reset';

export default function MembershipPortal(){
 const router=useRouter();
 const {language,t:translate}=useLanguage(),t=(text:string)=>language==='ka'?(membershipCopy[text]??translate(text)):translate(text);
 const [data,setData]=useState<MembershipState|null>(null),[mode,setMode]=useState<AuthMode>('register'),[busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState(''),[name,setName]=useState(''),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[confirmPassword,setConfirmPassword]=useState(''),[checkout,setCheckout]=useState(false),[consent,setConsent]=useState(false),[currentPassword,setCurrentPassword]=useState(''),[nextPassword,setNextPassword]=useState(''),[resetToken,setResetToken]=useState(''),[resetLink,setResetLink]=useState('');
 const locale=language==='ka'?'ka-GE':language==='ru'?'ru-RU':'en-US';
 const money=(cents:number)=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(cents/100);
 const date=(value:string)=>new Date(value).toLocaleString(locale,{dateStyle:'medium',timeStyle:'short'});
 async function load(){const r=await fetch('/api/membership',{cache:'no-store'}),v=await r.json() as MembershipState&{error?:string};if(!r.ok)throw Error(v.error);setData(v);return v;}
 // URL state is client-only, so apply it after hydration to keep server and first client render identical.
 // eslint-disable-next-line react-hooks/set-state-in-effect
 useEffect(()=>{const query=new URLSearchParams(window.location.search),initial=query.get('mode'),oauthError=query.get('auth_error');startTransition(()=>{if(initial==='login'||initial==='forgot'||initial==='reset')setMode(initial);setResetToken(query.get('token')??'');setCheckout(query.get('checkout')==='1');if(oauthError)setNotice('Continue with email and password instead.');});void load().catch(e=>startTransition(()=>setError((e as Error).message)));},[]);
 async function action(payload:Record<string,unknown>,success='',showCheckout=false){
  setBusy(true);setError('');setNotice('');
  try{const r=await fetch('/api/membership',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}),v=await r.json() as {error?:string};if(!r.ok)throw Error(v.error);setPassword('');setConfirmPassword('');setNextPassword('');setCurrentPassword('');setConsent(false);const refreshed=await load();if(payload.action==='register'){router.replace('/?choosePlan=1');return;}if(payload.action==='login'&&refreshed.member){if(refreshed.access){router.replace('/journal');return;}if(!refreshed.subscription){router.replace('/?choosePlan=1');return;}setCheckout(true);return;}const loginNeedsBilling=payload.action==='login'&&!!refreshed.member&&!refreshed.access;setCheckout(showCheckout||loginNeedsBilling);setNotice(success);}
  catch(e){setError((e as Error).message);}finally{setBusy(false);}
 }
 async function submit(e:FormEvent){
  e.preventDefault();setError('');setNotice('');setResetLink('');
  if(mode==='register'&&password!==confirmPassword){setError('Passwords do not match.');return;}
  if(mode==='reset'&&password!==confirmPassword){setError('Passwords do not match.');return;}
  if(mode==='forgot'||mode==='reset'){
   setBusy(true);try{
    const payload=mode==='forgot'?{action:'request',email}:{action:'confirm',token:resetToken,password};
    const r=await fetch('/api/membership/password-reset',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}),v=await r.json() as {error?:string;deliveryConfigured?:boolean;debugLink?:string};if(!r.ok)throw Error(v.error);
    if(mode==='forgot'){setResetLink(v.debugLink??'');setNotice(v.deliveryConfigured?'If an account uses this email, a reset link is on its way.':'Password reset email delivery is not configured yet.');}
    else{setMode('login');setPassword('');setConfirmPassword('');setNotice('Password updated. Sign in with your new password.');}
   }catch(e){setError((e as Error).message);}finally{setBusy(false);}return;
  }
  void action({action:mode,name,email,password},mode==='register'?'Your account is ready.':'You are signed in.',mode==='register');
 }
 const subscription=data?.subscription,member=data?.member,active=!!member&&hasAccess(member,subscription??null);
 const authTitle=mode==='register'?'Create your account':mode==='login'?'Welcome back':mode==='forgot'?'Reset your password':'Choose a new password';
 return <div className="membership-page">
  <header className="membership-header"><Link href="/" className="member-brand"><span><ShieldCheck size={23}/></span>TRADE JOURNAL</Link><div><span className="sandbox-badge">{t('PAYMENTS IN TEST MODE')}</span><ThemeToggle/></div></header>
  <main id="billing" className="membership-main">
   <div className="membership-breadcrumb"><Link href="/"><ArrowLeft size={16}/>{t('Home')}</Link>{data?.admin&&<Link href="/admin"><Settings2 size={16}/>{t('Administrator')}</Link>}</div>
   <div className="sandbox-notice"><LockKeyhole size={18}/><p>{t('Accounts are ready for public signup. Checkout is in test mode until Stripe or another payment provider is connected.')}</p></div>
   {error&&<div className="notice error" role="alert">{t(error)}<button className="inline-link" disabled={busy} onClick={()=>{setError('');void load().catch(e=>setError((e as Error).message));}}>{t('Refresh')}</button></div>}
   {notice&&<div className="notice success" role="status"><Check size={16}/>{t(notice)}</div>}
   {data?.admin&&!member&&<section className="panel owner-profile"><ShieldCheck size={24}/><div><h2>{data.viewer?.name}</h2><p>{data.viewer?.email}</p></div><a className="secondary" href="/journal">{t('Open my journal')}</a></section>}
   {!data?<div className="panel empty-state"><RefreshCw size={24}/>{t('Loading…')}</div>:!member?<div className="membership-entry">
    <section className="membership-intro"><span className="eyebrow">{t('YOUR OWN TRADING SPACE')}</span><h1>{t('Trade with clarity.')}</h1><div className="membership-showcase-chart">
     <div className="signup-chart-head"><span>{t('ILLUSTRATIVE · LAST 30 DAYS')}</span><strong>+$2,480 <small>+12.8%</small></strong></div>
     <div className="signup-chart-summary"><span>Equity curve</span><span><i className="chart-legend-up"/>Growth <i className="chart-legend-down"/>Pullback</span></div>
     <svg className="signup-equity-svg" viewBox="0 0 640 190" role="img" aria-label="Illustrative equity curve showing growth and pullbacks"><defs><linearGradient id="signup-chart-fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#10b981" stopOpacity=".22"/><stop offset="100%" stopColor="#10b981" stopOpacity="0"/></linearGradient></defs><path className="signup-grid" d="M0 30H640M0 70H640M0 110H640M0 150H640"/><path d="M0 154 C28 148 37 130 62 137 S98 126 120 130 S146 94 174 104 S208 117 233 94 S274 81 295 91 S324 116 350 102 S380 112 402 85 S440 57 461 69 S492 91 515 71 S550 59 570 43 S608 51 640 22 V190 H0Z" fill="url(#signup-chart-fill)"/><path className="signup-equity-line" d="M0 154 C28 148 37 130 62 137 S98 126 120 130 S146 94 174 104 S208 117 233 94 S274 81 295 91 S324 116 350 102 S380 112 402 85 S440 57 461 69 S492 91 515 71 S550 59 570 43 S608 51 640 22"/><path className="signup-pullback-line" d="M461 69 C480 76 495 91 515 71"/><circle cx="515" cy="71" r="4" className="signup-pullback-dot"/><circle cx="640" cy="22" r="4" className="signup-equity-dot"/></svg>
     <div className="signup-chart-axis"><span>OCT 01</span><span>OCT 08</span><span>OCT 15</span><span>OCT 22</span><span>OCT 30</span></div>
     <div className="signup-analytics"><article><span>Win rate</span><strong>62.5%</strong><small>↑ +4.2%</small></article><article><span>Profit factor</span><strong>2.14</strong><small>↑ +0.18</small></article><article><span>Max drawdown</span><strong className="signup-drawdown-value">4.8%</strong><small className="signup-regression">↓ 1.2% this week</small></article></div>
     <div className="signup-daily-bars"><span>Session P&amp;L</span><div aria-label="Illustrative daily gains and losses">{[38,58,45,72,34,62,48,82,54,67,42,76,52,91,63,73,47,85,59,68,43,79,55,94,61,72,49,87,65,100].map((height,index)=><i key={index} className={index===4||index===10||index===17||index===22?'loss':''} style={{height:`${height}%`,animationDelay:`${index*18}ms`}}/>)}</div></div>
    </div><div className="membership-price"><strong>{money(data.plan.price_cents)}</strong><span>{t('/ month')}</span><small>{data.plan.trial_days} {t('trial days · test plan')}</small></div>{data.admin&&<a className="secondary owner-return" href="/journal">{t('Return to my existing journal')}</a>}</section>
    <section className="panel membership-form">
     {(mode==='register'||mode==='login')?<div className="segmented">{(['register','login'] as const).map(item=><button key={item} disabled={busy} type="button" aria-pressed={mode===item} className={mode===item?'active':''} onClick={()=>{setMode(item);setError('');setNotice('');setConfirmPassword('');}}>{t(item==='register'?'Create account':'Sign in')}</button>)}</div>:<button className="membership-back" type="button" onClick={()=>{setMode('login');setError('');setNotice('');}}><ArrowLeft size={15}/>{t('Back to sign in')}</button>}
     <h2>{t(authTitle)}</h2>
     {(mode==='register'||mode==='login')&&<><GoogleSignInButton className="google-auth-button" iconClassName="google-brand-icon" statusClassName="google-auth-status" label={t('Continue with Google')}/><div className="membership-divider"><span>{t('or continue with email')}</span></div></>}
     <form onSubmit={submit}><fieldset disabled={busy}>
      {mode==='register'&&<label className="field">{t('Name')}<input required minLength={2} maxLength={80} autoComplete="name" value={name} onChange={e=>setName(e.target.value)}/></label>}
      {(mode==='register'||mode==='login'||mode==='forgot')&&<label className="field">{t('Email')}<input required type="email" maxLength={254} autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)}/></label>}
      {(mode==='register'||mode==='login'||mode==='reset')&&<label className="field">{mode==='reset'?t('New password'):t('Password')}<input required type="password" minLength={12} maxLength={128} autoComplete={mode==='register'||mode==='reset'?'new-password':'current-password'} value={password} onChange={e=>setPassword(e.target.value)}/><small>{t('At least 12 characters.')}</small></label>}
      {mode==='register'&&<label className="field">{t('Confirm password')}<input required type="password" minLength={12} maxLength={128} autoComplete="new-password" value={confirmPassword} onChange={e=>setConfirmPassword(e.target.value)}/></label>}
      {mode==='reset'&&<label className="field">{t('Confirm new password')}<input required type="password" minLength={12} maxLength={128} autoComplete="new-password" value={confirmPassword} onChange={e=>setConfirmPassword(e.target.value)}/></label>}
      <button className="primary member-submit" type="submit">{mode==='register'?<UserPlus size={18}/>:mode==='login'?<LogIn size={18}/>:mode==='forgot'?<Mail size={18}/>:<ShieldCheck size={18}/>} {t(busy?'Please wait…':mode==='register'?'Create account':mode==='login'?'Sign in':mode==='forgot'?'Send reset link':'Set new password')}</button>
     </fieldset></form>
     {mode==='login'&&<button className="membership-text-button" onClick={()=>{setMode('forgot');setError('');setNotice('');}}>{t('Forgot password?')}</button>}
     {mode==='register'&&<p className="signup-payment-note">{t('Payments remain in test mode until a provider is connected. No real charge is made.')}</p>}
     {mode==='forgot'&&resetLink&&<a className="membership-reset-link" href={resetLink}><ExternalLink size={15}/>{t('Open the local password reset link')}</a>}
    </section>
   </div>:<>
    <div className="membership-title"><div><span className="eyebrow">{t('MEMBERSHIP')}</span><h1>{member.name}</h1><p>{member.email}</p></div><button className="secondary" disabled={busy} onClick={()=>void action({action:'logout'},'Signed out.')}><LogOut size={16}/>{t('Sign out')}</button></div>
    <div className="membership-cards"><section className="panel membership-plan"><div className="panel-head"><h2>{t('Journal Pro')}</h2><span className={`member-status ${active?'positive':''}`}>{t(member.suspended?'Suspended':!active?'Expired':subscription?.status==='trialing'?'Trial':subscription?.cancel_at_end?'Ends after this period':'Active')}</span></div><div className="membership-plan-body"><strong className="plan-amount">{money(subscription?.price_cents??data.plan.price_cents)}<small>{t('/ month')}</small></strong><p>{t('Access until')}: <b>{subscription?date(subscription.period_end):'—'}</b></p><p className="member-fineprint">{t('No payment details are stored. Your current trial remains active until its end date.')}</p><div className="member-actions">{active&&<a className="primary" href="/journal">{t('Open my journal')}</a>}{!member.suspended&&(!active||subscription?.status==='trialing')&&<button className="primary" disabled={busy} onClick={()=>{setCheckout(true);setConsent(false);}}><CreditCard size={17}/>{t('Open checkout')}</button>}{active&&<button className="secondary" disabled={busy} onClick={()=>void action({action:subscription?.cancel_at_end?'resume':'cancel',revision:subscription?.revision},subscription?.cancel_at_end?'Cancellation removed.':'Cancelled. Access remains until the end of your current period.')}>{t(subscription?.cancel_at_end?'Keep subscription':'Cancel subscription')}</button>}</div></div></section>
     <section className="panel membership-plan"><div className="panel-head"><h2>{t('Your personal space')}</h2><LockKeyhole size={18}/></div><div className="membership-plan-body"><p>{t('Your trades, strategies and screenshots belong only to this account.')}</p><p className="member-fineprint">{t('An expired subscription keeps your records. Renew your plan to open the journal again.')}</p>{!!member.suspended&&<p className="form-error">{t('This account is suspended. Contact the administrator.')}</p>}</div></section>
    </div>
    {checkout&&data&&<BillingCheckoutDialog open={checkout} onOpenChange={open=>{setCheckout(open);if(!open)setConsent(false);}} data={data} busy={busy} consent={consent} setConsent={setConsent} money={money} onPay={()=>void action({action:'pay',revision:subscription?.revision,requestId:crypto.randomUUID()},'Test payment succeeded. Your monthly access is active.')} onFail={()=>void action({action:'fail',revision:subscription?.revision,requestId:crypto.randomUUID()},'Payment failure simulated. No access extension or charge was made.')}/>}
    <section className="panel member-history"><div className="panel-head"><h2>{t('Payment history')}</h2></div>{data.events.length?<div className="table-scroll"><table className="trade-table"><thead><tr><th>{t('Date')}</th><th>{t('Result')}</th><th>{t('Amount')}</th></tr></thead><tbody>{data.events.map(event=><tr key={event.id}><td>{date(event.created_at)}</td><td className={event.kind==='test_paid'?'green-text':'red-text'}>{t(event.kind==='test_paid'?'Test succeeded':'Test failed')}</td><td>{money(event.amount_cents)}</td></tr>)}</tbody></table></div>:<p className="statistics-empty">{t('No payments yet.')}</p>}</section>
    <details className="panel member-password"><summary>{t('Change password')}</summary><form onSubmit={e=>{e.preventDefault();void action({action:'password',currentPassword,password:nextPassword},'Password changed. Other sessions were signed out.');}}><fieldset disabled={busy}><label className="field">{t('Current password')}<input required type="password" autoComplete="current-password" value={currentPassword} onChange={e=>setCurrentPassword(e.target.value)}/></label><label className="field">{t('New password')}<input required minLength={12} maxLength={128} type="password" autoComplete="new-password" value={nextPassword} onChange={e=>setNextPassword(e.target.value)}/></label><button type="submit" className="secondary">{t('Save password')}</button></fieldset></form></details>
   </>}
  </main><LanguageSelector/>
 </div>;
}
