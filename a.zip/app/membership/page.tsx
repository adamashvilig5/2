import MembershipPortal from './portal';
export default function MembershipPage(){return <MembershipPortal/>;}
