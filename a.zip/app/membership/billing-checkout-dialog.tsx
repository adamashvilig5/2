'use client';

import { useState } from 'react';
import { Check, CheckCircle2, CreditCard, LockKeyhole, ShieldCheck, Sparkles, X, XCircle } from 'lucide-react';
import { Dialog } from 'radix-ui';
import type { MembershipState } from './portal';

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  data: MembershipState;
  busy: boolean;
  consent: boolean;
  setConsent: (value: boolean) => void;
  money: (cents: number) => string;
  error?: string;
  onPay: () => void;
  onFail: () => void;
};

export default function BillingCheckoutDialog({ open, onOpenChange, data, busy, consent, setConsent, money, error, onPay, onFail }: Props) {
  const [step, setStep] = useState<'plan' | 'payment'>('plan');

  return <Dialog.Root open={open} onOpenChange={onOpenChange}>
    <Dialog.Portal>
      <Dialog.Overlay className="billing-dialog-overlay" />
      <Dialog.Content className="billing-dialog" aria-describedby="billing-dialog-description">
        <header className="billing-dialog-header">
          <div className="billing-dialog-mark"><CreditCard size={18}/></div>
          <div>
            <span className="eyebrow">TRADE JOURNAL · MEMBERSHIP</span>
            <Dialog.Title>{step === 'plan' ? 'Choose your plan' : 'Secure checkout'}</Dialog.Title>
            <Dialog.Description id="billing-dialog-description">{step === 'plan' ? 'One focused workspace for your complete trading process.' : 'Review the payment step before continuing.'}</Dialog.Description>
          </div>
          <Dialog.Close className="billing-dialog-close" aria-label="Close billing"><X size={19}/></Dialog.Close>
        </header>

        <div className="billing-dialog-content">
          {step === 'plan' ? <>
            <article className="billing-choice-card">
              <div className="billing-choice-top"><span className="billing-plan-icon"><Sparkles size={18}/></span><span className="billing-plan-name">Journal Pro</span><span className="billing-plan-tag">ALL FEATURES</span></div>
              <div className="billing-choice-price"><strong>{money(data.plan.price_cents)}</strong><span>/ month</span></div>
              {data.plan.trial_days > 0 && <p className="billing-trial"><ShieldCheck size={15}/>{data.plan.trial_days}-day trial · cancel any time</p>}
              <div className="billing-benefits">
                <span><Check size={15}/> Unlimited trade journal and screenshots</span>
                <span><Check size={15}/> Performance analytics and calendar</span>
                <span><Check size={15}/> Strategies, mindset and personal insights</span>
              </div>
              <button className="primary billing-continue" type="button" onClick={() => { setConsent(false); setStep('payment'); }}>
                Continue to checkout <CreditCard size={16}/>
              </button>
            </article>
            <p className="billing-security-note"><LockKeyhole size={13}/> Your journal stays private. No payment details are stored here.</p>
          </> : <section className="billing-payment-step">
            <div className="billing-payment-summary"><div><span>Journal Pro</span><strong>{money(data.plan.price_cents)} <small>/ month</small></strong></div><span className="billing-plan-tag">{data.plan.trial_days > 0 ? `${data.plan.trial_days}-DAY TRIAL` : 'MONTHLY PLAN'}</span></div>
            <div className={`billing-provider-state ${data.mode === 'local-test' ? 'test' : ''}`}><ShieldCheck size={18}/><div><strong>{data.mode === 'local-test' ? 'Test checkout' : 'Payment provider not connected'}</strong><span>{data.mode === 'local-test' ? 'No real payment will be collected.' : 'Checkout will be available when Stripe or another provider is connected.'}</span></div></div>
            {error && <p className="billing-action-error" role="alert">{error}</p>}
            {data.mode === 'local-test' ? <>
              <label className="billing-consent"><input type="checkbox" checked={consent} disabled={busy} onChange={event => setConsent(event.target.checked)}/><span>I understand this is a test and no money will be charged.</span></label>
              <div className="billing-payment-actions">
                <button className="primary" disabled={busy || !consent} onClick={onPay}><CheckCircle2 size={17}/>{busy ? 'Processing…' : 'Simulate successful payment'}</button>
                <button className="secondary" disabled={busy || !consent} onClick={onFail}><XCircle size={17}/>Simulate failed payment</button>
              </div>
            </> : <button className="primary billing-continue" disabled><CreditCard size={16}/>Checkout unavailable</button>}
            <button className="billing-back" type="button" onClick={() => setStep('plan')} disabled={busy}>Back to plan</button>
          </section>}
        </div>
      </Dialog.Content>
    </Dialog.Portal>
  </Dialog.Root>;
}
