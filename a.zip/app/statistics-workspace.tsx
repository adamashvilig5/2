'use client';

import { useEffect, useMemo, useState } from 'react';
import { Activity, ArrowLeft, ArrowRight, ArrowUpRight, CalendarDays, Download, Focus, ShieldAlert, ShieldCheck, Sparkles, Target, TrendingDown, TrendingUp } from 'lucide-react';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, ZAxis } from 'recharts';
import { moveMonth, money, shiftDate, stats, tradeEmotions, tradeOrder, type Strategy, type Trade } from '@/lib/trading';
import type { InnerEntry } from '@/lib/inner-space';
import { useLanguage } from './journal-language';
import { getStrategyStatistics,getConditionStatistics,getEmotionStatistics,getStrategyConditionCombinations,getTradingInsights,type TradeFilters } from '@/lib/trade-analytics';

type Breakdown = 'asset' | 'strategy' | 'session' | 'weekday' | 'time';
type Props = { trades: Trade[]; start: string; end: string; currency: string; strategies: Strategy[]; opening: number | null; onReview: (trade: Trade) => void; onExplore: (title: string, rows: Trade[]) => void; onFocus?: () => void; onApplyFilter?:(filter:Partial<TradeFilters>)=>void; };
type Group = { key: string; name: string; trades: Trade[]; pnl: number; count: number; wins: number; winRate: number; avgR: number; avgRisk: number; consistency: number; profitFactor: string };
const moodTitles = ['Low focus', 'Uneasy', 'Balanced', 'Positive', 'Sharp'];

function summarize(name: string, key: string, rows: Trade[]): Group {
  const result = stats(rows, null);
  const risks = rows.map((trade) => trade.risk);
  const avgRisk = risks.length ? risks.reduce((sum, risk) => sum + risk, 0) / risks.length : 0;
  const avgR = rows.length ? rows.reduce((sum, trade) => sum + trade.pnl / trade.risk, 0) / rows.length : 0;
  const positiveDays = new Set(rows.filter((trade) => trade.pnl > 0).map((trade) => trade.date)).size;
  const tradingDays = new Set(rows.map((trade) => trade.date)).size;
  return { key, name, trades: rows, pnl: result.pnl, count: result.count, wins: result.wins, winRate: result.winRate, avgR, avgRisk, consistency: tradingDays ? positiveDays / tradingDays * 100 : 0, profitFactor: result.profitFactor === Infinity ? '∞' : result.profitFactor === null ? '—' : result.profitFactor.toFixed(2) };
}

function groupBy(trades: Trade[], keyOf: (trade: Trade) => string, nameOf: (key: string) => string = (key) => key) {
  const map = new Map<string, Trade[]>();
  for (const trade of trades) {
    const key = keyOf(trade);
    map.set(key, [...(map.get(key) ?? []), trade]);
  }
  return [...map].map(([key, rows]) => summarize(nameOf(key), key, rows)).sort((a, b) => b.pnl - a.pnl || b.count - a.count);
}

function csvCell(value: string | number) { return `"${String(value).replaceAll('"', '""')}"`; }
function percent(value:number|null){return value===null?'—':`${value.toFixed(1)}%`;}
function signedR(value:number|null){return value===null?'—':`${value>=0?'+':''}${value.toFixed(2)}R`;}
function number(value:number|null){return value===null?'—':value===Infinity?'∞':value.toFixed(2);}

export default function StatisticsWorkspace({ trades, start, end, currency, strategies, opening, onReview, onExplore, onFocus=()=>undefined,onApplyFilter=()=>undefined }: Props) {
  const { t } = useLanguage();
  const [breakdown, setBreakdown] = useState<Breakdown>('asset');
  const [month, setMonth] = useState(end.slice(0, 7));
  const [focusEntries, setFocusEntries] = useState<InnerEntry[]>([]);
  useEffect(() => {
    let active = true;
    void fetch('/api/inner-space', { cache: 'no-store' }).then(async (response) => {
      if (!response.ok) return null;
      return await response.json() as { entries?: InnerEntry[] };
    }).then((data) => { if (active && data?.entries) setFocusEntries(data.entries); }).catch(() => undefined);
    return () => { active = false; };
  }, []);

  const rows = useMemo(() => trades.filter((trade) => trade.date >= start && trade.date <= end).sort(tradeOrder), [trades, start, end]);
  const strategyStats=getStrategyStatistics(rows),conditionStats=getConditionStatistics(rows),emotionStats=getEmotionStatistics(rows),combinationStats=getStrategyConditionCombinations(rows),insights=getTradingInsights(rows,{start,end});
  const groups = useMemo(() => {
    const assets = groupBy(rows, (trade) => trade.symbol);
    const byStrategy = groupBy(rows, (trade) => trade.strategySnapshot?.name ?? strategies.find((strategy) => strategy.id === trade.strategyId)?.name ?? (trade.tags.join(', ') || 'No strategy'));
    const sessions = groupBy(rows, (trade) => trade.session);
    const weekDays = groupBy(rows, (trade) => String((new Date(`${trade.date}T12:00:00Z`).getUTCDay() + 6) % 7), (key) => ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'][Number(key)]);
    const times = groupBy(rows, (trade) => { const hour = Number(trade.entryTime.slice(0, 2)); return hour < 6 ? '00:00–05:59' : hour < 12 ? '06:00–11:59' : hour < 18 ? '12:00–17:59' : '18:00–23:59'; });
    return { asset: assets, strategy: byStrategy, session: sessions, weekday: weekDays, time: times };
  }, [rows, strategies]);
  const activeGroups = groups[breakdown];
  const dayMap = useMemo(() => {
    const map = new Map<string, Trade[]>();
    for (const trade of trades.filter((item) => item.date.startsWith(`${month}-`))) map.set(trade.date, [...(map.get(trade.date) ?? []), trade]);
    return map;
  }, [trades, month]);
  const calendarDays = useMemo(() => {
    const first = `${month}-01`;
    const weekday = (new Date(`${first}T12:00:00Z`).getUTCDay() + 6) % 7;
    return Array.from({ length: 42 }, (_, index) => shiftDate(first, index - weekday));
  }, [month]);
  const calendarMonths = calendarDays.filter((date) => date.startsWith(`${month}-`));
  const monthTotals = calendarMonths.flatMap((date) => dayMap.get(date) ?? []);
  const monthPnl = monthTotals.reduce((sum, trade) => sum + trade.pnl, 0);
  const ordered = rows;
  let equity = opening ?? 0;
  let peak = equity;
  let maxDrawdown = 0;
  let maxDrawdownPct: number | null = opening && opening > 0 ? 0 : null;
  let peakDate = start;
  let maxPeakDate = start;
  let troughDate = start;
  let recoveryDays: number | null = null;
  const drawdown = [{ date: start, value: 0, pnl: 0 }];
  for (const trade of ordered) {
    equity += trade.pnl;
    if (equity > peak) { peak = equity; peakDate = trade.date; }
    const amount = Math.max(0, peak - equity);
    if (amount > maxDrawdown) { maxDrawdown = amount; troughDate = trade.date; maxPeakDate = peakDate; }
    if (maxDrawdownPct !== null && peak > 0) maxDrawdownPct = Math.max(maxDrawdownPct, amount / peak * 100);
    if (recoveryDays === null && maxDrawdown > 0 && trade.date > troughDate && equity >= peak) recoveryDays = Math.round((Date.parse(`${trade.date}T00:00:00Z`) - Date.parse(`${troughDate}T00:00:00Z`)) / 86400000);
    drawdown.push({ date: trade.date, value: -amount, pnl: trade.pnl });
  }
  const lossesInRow = (() => { let best = 0; let current = 0; for (const trade of ordered) { if (trade.pnl < 0) { current++; best = Math.max(best, current); } else current = 0; } return best; })();
  const avgRisk = rows.length ? rows.reduce((sum, trade) => sum + trade.risk, 0) / rows.length : 0;
  const riskDeviation = rows.length ? Math.sqrt(rows.reduce((sum, trade) => sum + (trade.risk - avgRisk) ** 2, 0) / rows.length) : 0;
  const riskCv = avgRisk ? riskDeviation / avgRisk * 100 : 0;
  const previous = (outcome: 'win' | 'loss') => {
    const nextRisks = ordered.slice(1).filter((trade, index) => outcome === 'win' ? ordered[index].pnl > 0 : ordered[index].pnl < 0).map((trade) => trade.risk);
    return nextRisks.length ? nextRisks.reduce((sum, risk) => sum + risk, 0) / nextRisks.length : null;
  };
  const riskAfterWin = previous('win');
  const riskAfterLoss = previous('loss');
  const riskShiftAfterLoss = riskAfterWin && riskAfterLoss !== null ? (riskAfterLoss / riskAfterWin - 1) * 100 : null;
  const riskGroups = (() => {
    const sorted = [...rows].sort((a, b) => a.risk - b.risk);
    return ['Lower risk', 'Mid risk', 'Higher risk'].map((name, index) => {
      const groupRows = sorted.filter((_, rowIndex) => Math.min(2, Math.floor(rowIndex * 3 / Math.max(1, sorted.length))) === index);
      const group = summarize(name, name, groupRows);
      return { risk: group.avgRisk, pnl: group.count ? group.pnl / group.count : 0, count: group.count, winRate: group.winRate, label: name };
    }).filter((group) => group.count);
  })();
  const orderedCalendar = [...dayMap].map(([date, dayTrades]) => ({ date, trades: dayTrades, pnl: dayTrades.reduce((sum, trade) => sum + trade.pnl, 0), winRate: dayTrades.length ? dayTrades.filter((trade) => trade.pnl > 0).length / dayTrades.length * 100 : 0, avgRisk: dayTrades.reduce((sum, trade) => sum + trade.risk, 0) / dayTrades.length, strategy: groupBy(dayTrades, (trade) => trade.strategySnapshot?.name ?? trade.tags[0] ?? 'Unspecified')[0]?.name ?? 'Unspecified' }));
  const calendarStats = new Map(orderedCalendar.map((day) => [day.date, day]));
  const maxAbsDailyPnl = Math.max(1, ...orderedCalendar.map((day) => Math.abs(day.pnl)));
  const bestSession = groups.session.filter((group) => group.count >= 2).sort((a, b) => b.pnl - a.pnl)[0];
  const consistentStrategy = groups.strategy.filter((group) => group.count >= 3).sort((a, b) => b.consistency - a.consistency || b.pnl - a.pnl)[0];
  const focusRows = moodTitles.map((title, index) => {
    const moodEntries = focusEntries.filter((entry) => entry.mood === index + 1 && entry.date >= start && entry.date <= end);
    const daySet = new Set(moodEntries.map((entry) => entry.date));
    const moodTrades = rows.filter((trade) => daySet.has(trade.date));
    const checked = moodTrades.filter((trade) => trade.strategySnapshot?.checklist.length);
    const completed = checked.reduce((sum, trade) => sum + Math.min(trade.strategyChecks?.length ?? 0, trade.strategySnapshot?.checklist.length ?? 0) / Math.max(1, trade.strategySnapshot?.checklist.length ?? 0), 0);
    return { title, rows: moodTrades, pnl: moodTrades.reduce((sum, trade) => sum + trade.pnl, 0), winRate: moodTrades.length ? moodTrades.filter((trade) => trade.pnl > 0).length / moodTrades.length * 100 : null, avgRisk: moodTrades.length ? moodTrades.reduce((sum, trade) => sum + trade.risk, 0) / moodTrades.length : 0, ruleScore: checked.length ? completed / checked.length * 100 : null };
  });
  const bestTrades = rows.filter((trade) => trade.pnl > 0).sort((a, b) => b.pnl - a.pnl).slice(0, 3);
  const reviewTrades = [...rows].filter((trade) => trade.pnl < 0).sort((a, b) => a.pnl - b.pnl).slice(0, 3);
  const tradeGroups = activeGroups;

  function exportReport() {
    const header = ['Date', 'Time', 'Symbol', 'Side', 'Session', 'Strategy', 'Result', 'P&L', 'Risk', 'R multiple', 'Emotion', 'Notes'];
    const lines = [header, ...rows.map((trade) => [trade.date, `${trade.entryTime}–${trade.exitTime}`, trade.symbol, trade.side, trade.session, trade.strategySnapshot?.name ?? trade.tags.join('; '), trade.result, trade.pnl, trade.risk, (trade.pnl / trade.risk).toFixed(2), tradeEmotions(trade).join('; '), trade.notes])].map((line) => line.map(csvCell).join(','));
    const url = URL.createObjectURL(new Blob([`\uFEFF${lines.join('\r\n')}`], { type: 'text/csv;charset=utf-8' }));
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = `trade-journal-report-${start}-${end}.csv`; anchor.click(); window.setTimeout(() => URL.revokeObjectURL(url), 0);
  }

  function dayClass(date: string) {
    const day = calendarStats.get(date);
    if (!day) return 'empty';
    const intensity = Math.max(1, Math.ceil(Math.abs(day.pnl) / maxAbsDailyPnl * 4));
    return day.pnl > 0 ? `profit profit-${intensity}` : day.pnl < 0 ? `loss loss-${intensity}` : 'flat';
  }

  return <div className="performance-workspace">
    <div className="performance-workspace-header"><div><div className="analytics-breadcrumb">{t('Workspace')} <span>/</span> {t('Statistics')}</div><h2>{t('Performance Analytics')}</h2><p>{t('Turn your trading data into a clearer edge.')}</p><small>{start} — {end} · {rows.length} {t('trades')}</small></div><button className="secondary" onClick={exportReport} disabled={!rows.length}><Download size={16}/>{t('Export report')}</button></div>

    <section className="analytics-calendar panel"><div className="analytics-section-title"><div><span className="analytics-kicker"><CalendarDays size={14}/>{t('PERFORMANCE CALENDAR')}</span><h3>{t('Your month, trade by trade')}</h3><p>{t('Hover or focus a day for its recorded summary. Select a trading day to open those journal entries.')}</p></div><div className="analytics-month-nav"><button aria-label={t('Previous month')} onClick={() => setMonth((value) => moveMonth(value, -1))}><ArrowLeft size={15}/></button><strong>{new Intl.DateTimeFormat('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(`${month}-01T12:00:00Z`))}</strong><button aria-label={t('Next month')} onClick={() => setMonth((value) => moveMonth(value, 1))}><ArrowRight size={15}/></button></div></div><div className="analytics-calendar-summary"><strong className={monthPnl < 0 ? 'negative' : monthPnl > 0 ? 'positive' : ''}>{money(monthPnl, currency)}</strong><span>{monthTotals.length} {t('trades')} · {new Set(monthTotals.map((trade) => trade.date)).size} {t('active days')}</span></div><div className="analytics-heatmap"><div className="heatmap-weekdays">{['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map((day) => <span key={day}>{t(day)}</span>)}</div><div className="heatmap-cells">{calendarDays.map((date) => { const day = calendarStats.get(date); return <button key={date} disabled={!day} className={`${dayClass(date)} ${date.slice(0, 7) !== month ? 'outside' : ''}`} title={day ? `${day.date} · ${day.trades.length} ${t('trades')} · ${money(day.pnl, currency)} · ${day.winRate.toFixed(0)}% ${t('win rate')} · ${t('Risk')} ${money(day.avgRisk, currency)} · ${day.strategy}` : `${date} · ${t('No trades')}`} aria-label={day ? `${day.date}, ${day.trades.length} ${t('trades')}, ${money(day.pnl, currency)}, ${day.winRate.toFixed(0)} percent win rate, average risk ${money(day.avgRisk, currency)}, ${day.strategy}` : date} onClick={() => day && onExplore(`${date} · ${t('Trades')}`, day.trades)}><span>{Number(date.slice(-2))}</span>{day && <small>{day.pnl > 0 ? '+' : ''}{money(day.pnl, currency).replace(/[A-Z]{3}\s?/, '')}</small>}</button>; })}</div></div><div className="heatmap-legend"><span>{t('No trades')}</span><i className="empty"/><i className="loss loss-2"/><i className="flat"/><i className="profit profit-2"/><i className="profit profit-4"/><span>{t('Recorded P&L')}</span><button className="inline-link" onClick={() => onFocus()}>{t('Open Trader Focus')} <ArrowUpRight size={13}/></button></div></section>

    <section className="analytics-breakdown panel"><div className="analytics-section-title"><div><span className="analytics-kicker"><Activity size={14}/>{t('PERFORMANCE BREAKDOWN')}</span><h3>{t('Find the conditions that work')}</h3><p>{t('Compare results, trade count, risk and consistency across your journal.')}</p></div></div><div className="analytics-breakdown-tabs" role="tablist" aria-label={t('Performance breakdown')}>{([{id:'asset',label:'By asset'},{id:'strategy',label:'By strategy'},{id:'session',label:'By session'},{id:'weekday',label:'By day'},{id:'time',label:'By time'}] as const).map((tab) => <button key={tab.id} role="tab" aria-selected={breakdown===tab.id} className={breakdown===tab.id?'active':''} onClick={() => setBreakdown(tab.id)}>{t(tab.label)}</button>)}</div>{tradeGroups.length?<div className="analytics-group-list">{tradeGroups.map((group,index) => <article className="analytics-group-row" key={group.key}><span className="group-rank">{String(index+1).padStart(2,'0')}</span><div className="group-name"><strong>{group.name}</strong><small>{group.count} {t('trades')} · {group.consistency.toFixed(0)}% {t('profitable days')}</small></div><div className="group-winrate"><i><b style={{width:`${group.winRate}%`}}/></i><small>{group.winRate.toFixed(1)}% {t('win')}</small></div><strong className={`group-pnl ${group.pnl<0?'negative':group.pnl>0?'positive':''}`}>{money(group.pnl,currency)}</strong><span className="group-r">{group.avgR>=0?'+':''}{group.avgR.toFixed(2)}R</span><span className="group-pf">PF {group.profitFactor}</span><button className="icon-button" aria-label={`${t('View')} ${group.name} ${t('trades')}`} onClick={() => onExplore(`${group.name} · ${t('Trades')}`,group.trades)}><ArrowUpRight size={15}/></button></article>)}</div>:<p className="analytics-empty">{t('No trades in this date range yet. Add journal records to build this breakdown.')}</p>}</section>

    <section className="trade-behavior-analytics" id="behavior-analysis"><div className="analytics-section-title"><div><span className="analytics-kicker"><Target size={14}/>BEHAVIORAL BREAKDOWN</span><h3>Strategy, condition & emotion performance</h3><p>Calculated from the same persisted trades as the journal and overview. Every row shows its sample size.</p></div></div>
      <section className="panel behavior-table-panel"><div className="analytics-section-title"><div><h3>Performance by strategy</h3><p>Compare results with plan adherence and recorded execution quality.</p></div></div>{strategyStats.length?<div className="table-scroll"><table className="behavior-table"><thead><tr><th>Strategy</th><th>Trades</th><th>Win rate</th><th>Net P&amp;L</th><th>Avg R</th><th>Profit factor</th><th>Conditions met</th><th>Plan adherence</th><th>Execution quality</th></tr></thead><tbody>{strategyStats.map(item=><tr key={item.id}><th>{item.label}</th><td>{item.trades}</td><td>{percent(item.winRate)}</td><td className={item.netPnl<0?'negative':item.netPnl>0?'positive':''}>{money(item.netPnl,currency)}</td><td>{signedR(item.averageR)}</td><td>{number(item.profitFactor)}</td><td>{percent(item.averageConditionsCompletionRate)}</td><td>{percent(item.planAdherence)}</td><td>{percent(item.executionQuality)}</td></tr>)}</tbody></table></div>:<p className="analytics-empty">No saved trades match these filters yet.</p>}</section>
      <section className="panel behavior-table-panel"><div className="analytics-section-title"><div><h3>Performance by strategy condition</h3><p>Checked versus unchecked outcomes are descriptive. Small samples are clearly marked.</p></div></div>{conditionStats.length?<div className="table-scroll"><table className="behavior-table"><thead><tr><th>Condition</th><th>Checked</th><th>Win rate · checked</th><th>Win rate · not checked</th><th>Net P&amp;L · checked</th><th>Avg R · checked</th><th>Sample / reliability</th></tr></thead><tbody>{conditionStats.map(item=><tr key={item.id}><th>{item.label}</th><td>{item.checkedCount}</td><td>{percent(item.checked.winRate)}</td><td>{percent(item.unchecked.winRate)}</td><td className={item.checked.netPnl<0?'negative':item.checked.netPnl>0?'positive':''}>{money(item.checked.netPnl,currency)}</td><td>{signedR(item.checked.averageR)}</td><td><span className={`sample-reliability level-${item.reliability.level}`}>{item.reliability.label}</span><small>{item.checkedCount} checked · {item.uncheckedCount} unchecked</small></td></tr>)}</tbody></table></div>:<p className="analytics-empty">Save trades with a strategy checklist to compare conditions.</p>}</section>
      <section className="panel behavior-table-panel"><div className="analytics-section-title"><div><h3>Performance by entry emotion</h3><p>Trades with multiple emotions count in each selected emotion group.</p></div></div>{emotionStats.length?<div className="table-scroll"><table className="behavior-table"><thead><tr><th>Emotion</th><th>Trades</th><th>Win rate</th><th>Net P&amp;L</th><th>Avg R</th><th>Execution quality</th><th>Conditions met</th></tr></thead><tbody>{emotionStats.map(item=><tr key={item.id}><th>{item.label}</th><td>{item.trades}</td><td>{percent(item.winRate)}</td><td className={item.netPnl<0?'negative':item.netPnl>0?'positive':''}>{money(item.netPnl,currency)}</td><td>{signedR(item.averageR)}</td><td>{percent(item.executionQuality)}</td><td>{percent(item.averageConditionsCompletionRate)}</td></tr>)}</tbody></table></div>:<p className="analytics-empty">Save a trade with an entry emotion to build this breakdown.</p>}</section>
      {combinationStats.length>0&&<section className="panel behavior-table-panel"><div className="analytics-section-title"><div><h3>Reliable strategy combinations</h3><p>Only combinations with at least 5 matching saved trades are shown.</p></div></div><div className="table-scroll"><table className="behavior-table"><thead><tr><th>Strategy + checked conditions</th><th>Trades</th><th>Win rate</th><th>Net P&amp;L</th><th>Avg R</th><th>Reliability</th></tr></thead><tbody>{combinationStats.map(item=><tr key={item.id}><th>{item.label}</th><td>{item.trades}</td><td>{percent(item.winRate)}</td><td className={item.netPnl<0?'negative':item.netPnl>0?'positive':''}>{money(item.netPnl,currency)}</td><td>{signedR(item.averageR)}</td><td><span className={`sample-reliability level-${item.reliability.level}`}>{item.reliability.label}</span><small>{item.sampleSize} trades</small></td></tr>)}</tbody></table></div></section>}
    </section>
    <section className="analytics-insights panel"><div className="analytics-section-title"><div><span className="analytics-kicker"><Sparkles size={14}/>PERSONAL INSIGHTS</span><h3>Patterns from your saved trades</h3><p>Insights update with the filters above. They describe your records, not guaranteed outcomes.</p></div></div>{insights.length?<div className="data-insight-grid">{insights.map(insight=><article className="data-insight-card" key={insight.id}><header><strong>{insight.title}</strong><span className={`sample-reliability level-${insight.reliability.level}`}>{insight.reliability.label}</span></header><p>{insight.explanation}</p><ul>{insight.supportingNumbers.map(line=><li key={line}>{line}</li>)}</ul><small>{insight.sampleSize} trade sample</small><div className="data-insight-action"><span><b>Suggested review</b>{insight.recommendedAction}</span><button type="button" className="inline-link" onClick={()=>{onApplyFilter(insight.filter);document.querySelector('.statistics-filters')?.scrollIntoView({behavior:'smooth',block:'start'});}}>View filtered trades <ArrowUpRight size={13}/></button></div></article>)}</div>:<p className="analytics-empty">Add and review trades to build personal insights from your own records.</p>}</section>

    <div className="analytics-risk-grid"><section className="analytics-risk panel"><div className="analytics-section-title"><div><span className="analytics-kicker"><ShieldCheck size={14}/>{t('RISK AND DISCIPLINE')}</span><h3>{t('Protect the downside')}</h3></div></div><div className="analytics-risk-metrics"><div><span>{t('Average risk / trade')}</span><strong>{rows.length?money(avgRisk,currency):'—'}</strong></div><div><span>{t('Risk after a winning trade')}</span><strong>{riskAfterWin===null?'—':money(riskAfterWin,currency)}</strong></div><div><span>{t('Risk after a losing trade')}</span><strong className={riskShiftAfterLoss!==null&&riskShiftAfterLoss>10?'caution':''}>{riskAfterLoss===null?'—':money(riskAfterLoss,currency)}</strong></div><div><span>{t('Risk-size variation')}</span><strong>{rows.length?`${riskCv.toFixed(0)}% CV`:'—'}</strong></div><div><span>{t('Average stop distance')}</span><strong className="not-tracked">{t('Not tracked')}</strong></div><div><span>{t('Trades past daily loss limit')}</span><strong className="not-tracked">{t('Limit not configured')}</strong></div></div><p className="analytics-data-note">{t('Risk values are the recorded cash risk per trade. A percentage requires a saved account balance and position-level risk inputs.')}</p></section>
      <section className="analytics-risk-chart panel"><div className="analytics-section-title"><div><span className="analytics-kicker"><TrendingUp size={14}/>{t('RISK VS PERFORMANCE')}</span><h3>{t('Does more risk pay off?')}</h3><p>{t('Each dot is a risk-size band from your records.')}</p></div></div>{riskGroups.length?<div className="risk-scatter"><ResponsiveContainer width="100%" height="100%"><ScatterChart margin={{top:12,right:18,bottom:10,left:0}}><CartesianGrid stroke="#343d4b" strokeDasharray="3 5"/><XAxis type="number" dataKey="risk" name={t('Average cash risk')} tick={{fill:'#8995a6',fontSize:9}} tickLine={false} axisLine={false} tickFormatter={(value)=>money(Number(value),currency).replace(/[A-Z]{3}\s?/, '')}/><YAxis type="number" dataKey="pnl" name={t('Average P&L')} tick={{fill:'#8995a6',fontSize:9}} tickLine={false} axisLine={false} tickFormatter={(value)=>money(Number(value),currency).replace(/[A-Z]{3}\s?/, '')}/><ZAxis type="number" dataKey="count" range={[70,300]}/><Tooltip cursor={{strokeDasharray:'3 3'}} contentStyle={{background:'#1c222c',border:'1px solid #3a4654',borderRadius:9,color:'#e8edf3',fontSize:11}} formatter={(value,name)=>[name===t('Average cash risk')||name===t('Average P&L')?money(Number(value),currency):value,name]}/><Scatter data={riskGroups} fill="#10b981" fillOpacity={.78}/></ScatterChart></ResponsiveContainer></div>:<p className="analytics-empty">{t('Add trades with recorded risk to compare risk size and outcome.')}</p>}</section></div>

    <div className="analytics-drawdown-trades"><section className="analytics-drawdown panel"><div className="analytics-section-title"><div><span className="analytics-kicker"><TrendingDown size={14}/>{t('DRAWDOWN REVIEW')}</span><h3>{t('Recovery is part of performance')}</h3></div></div><div className="drawdown-headline"><div><small>{t('Current drawdown')}</small><strong className={(drawdown.at(-1)?.value??0)<0?'caution':''}>{money(drawdown.at(-1)?.value??0,currency)}</strong></div><div><small>{t('Maximum drawdown')}</small><strong className={maxDrawdown?'caution':''}>{money(-maxDrawdown,currency)}{maxDrawdownPct===null?'':` · ${maxDrawdownPct.toFixed(1)}%`}</strong></div><div><small>{t('Longest losing streak')}</small><strong>{lossesInRow} {t('trades')}</strong></div></div>{drawdown.length>1?<div className="drawdown-chart"><ResponsiveContainer width="100%" height="100%"><AreaChart data={drawdown} margin={{top:8,right:6,left:0,bottom:0}}><defs><linearGradient id="drawdown-fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#ef7373" stopOpacity={.23}/><stop offset="100%" stopColor="#ef7373" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="#343d4b" strokeDasharray="3 5" vertical={false}/><XAxis dataKey="date" tick={{fill:'#8995a6',fontSize:8}} tickLine={false} axisLine={false} tickFormatter={(date)=>String(date).slice(5)}/><YAxis tick={{fill:'#8995a6',fontSize:8}} tickLine={false} axisLine={false} tickFormatter={(value)=>money(Number(value),currency).replace(/[A-Z]{3}\s?/, '')}/><Tooltip contentStyle={{background:'#1c222c',border:'1px solid #3a4654',borderRadius:9,color:'#e8edf3',fontSize:11}} formatter={(value)=>[money(Number(value),currency),t('Drawdown')]}/><Area type="monotone" dataKey="value" stroke="#df7777" strokeWidth={2} fill="url(#drawdown-fill)" isAnimationActive/></AreaChart></ResponsiveContainer></div>:<p className="analytics-empty">{t('Add trades to map peak-to-trough movement.')}</p>}<div className="drawdown-timeline"><span><i/>{t('Peak')} · {maxPeakDate}</span><span><i/>{t('Lowest point')} · {troughDate}</span><span><i/>{recoveryDays===null?t('Recovery not yet recorded'):`${recoveryDays} ${t('days to recovery')}`}</span></div></section>
      <section className="analytics-best-worst"><div className="panel analytics-trade-list"><div className="analytics-section-title"><div><span className="analytics-kicker"><ArrowUpRight size={14}/>{t('BEST TRADES')}</span><h3>{t('What went right')}</h3></div></div>{bestTrades.length?bestTrades.map((trade)=><button className="analytics-trade-row" key={trade.id} onClick={()=>onReview(trade)}><span><strong>{trade.symbol}</strong><small>{trade.strategySnapshot?.name??trade.tags[0]??t('No strategy')} · {trade.session}</small></span><span><b className="positive">{money(trade.pnl,currency)}</b><small>{(trade.pnl/trade.risk).toFixed(2)}R</small></span></button>):<p className="analytics-empty">{t('No trade records in this period.')}</p>}</div><div className="panel analytics-trade-list"><div className="analytics-section-title"><div><span className="analytics-kicker caution-kicker"><ShieldAlert size={14}/>{t('TRADES TO REVIEW')}</span><h3>{t('Look for a repeatable lesson')}</h3></div></div>{reviewTrades.length?reviewTrades.map((trade)=>{const emotions=tradeEmotions(trade).join(' ').toLowerCase();const mistake=emotions.includes('revenge')?'Revenge trade':emotions.includes('fomo')?'FOMO':trade.strategySnapshot?.checklist.length&&trade.strategyChecks?.length!==trade.strategySnapshot.checklist.length?'Plan checklist incomplete':trade.pnl<trade.risk*-1?'Loss exceeded recorded risk':'Review entry and risk';return <button className="analytics-trade-row" key={trade.id} onClick={()=>onReview(trade)}><span><strong>{trade.symbol}</strong><small>{trade.date} · {mistake}</small></span><span><b className="negative">{money(trade.pnl,currency)}</b><small>{trade.strategySnapshot?.name??trade.tags[0]??t('Unspecified')}</small></span></button>}):<p className="analytics-empty">{t('No losing trades to review in this period.')}</p>}</div></section></div>

    <section className="analytics-mindset panel"><div className="analytics-section-title"><div><span className="analytics-kicker"><Focus size={14}/>{t('TRADER FOCUS')}</span><h3>{t('Mindset versus performance')}</h3><p>{t('Trader Focus check-ins are matched to trades recorded on the same date. These are personal observations, not diagnoses.')}</p></div><button className="secondary" onClick={onFocus}>{t('Open Trader Focus')}<ArrowUpRight size={14}/></button></div><div className="mindset-performance-table"><div className="mindset-performance-head"><span>{t('Mindset')}</span><span>{t('Win rate')}</span><span>{t('Net P&L')}</span><span>{t('Trades')}</span><span>{t('Avg risk')}</span><span>{t('Rule follow-through')}</span></div>{focusRows.map((item)=>{const width=Math.max(0,item.winRate??0);return <div className="mindset-performance-row" key={item.title}><strong>{t(item.title)}</strong><span className="mindset-win-cell"><i><b style={{width:`${width}%`}}/></i>{item.winRate===null?'—':`${item.winRate.toFixed(0)}%`}</span><span className={item.pnl<0?'negative':item.pnl>0?'positive':''}>{item.rows.length?money(item.pnl,currency):'—'}</span><span>{item.rows.length||'—'}</span><span>{item.rows.length?money(item.avgRisk,currency):'—'}</span><span>{item.ruleScore===null?'—':`${item.ruleScore.toFixed(0)}%`}</span></div>;})}</div><p className="analytics-data-note">{t('Rule follow-through is available only for trades linked to a strategy checklist. “—” means that field has not been recorded.')}</p></section>

    <section className="analytics-edge panel"><div className="edge-icon"><Sparkles size={20}/></div><div className="edge-copy"><span className="analytics-kicker">{t('YOUR CURRENT EDGE')}</span><h3>{bestSession?`${bestSession.name} is your leading recorded session${consistentStrategy?`, while ${consistentStrategy.name} shows your strongest process consistency.`:'.'}`:t('Your edge will become clearer as your journal grows.')}</h3><p>{riskShiftAfterLoss!==null&&riskShiftAfterLoss>10?`Risk in the next trade averaged ${riskShiftAfterLoss.toFixed(0)}% higher after a loss in this period. Review that sequence against your plan.`:t('Use the breakdowns above to review performance, protect risk and reinforce decisions that match your plan.')}</p></div><div className="edge-actions"><button className="secondary" onClick={()=>setBreakdown('strategy')}>{t('Review my patterns')}<ArrowUpRight size={14}/></button><button className="primary" onClick={onFocus}><Focus size={15}/>{t('Open Trader Focus')}</button></div></section>
    <p className="analytics-data-note workspace-disclaimer">{t('All analytics are calculated from closed trades and saved check-ins in the selected date range. Cash risk is used where risk percentage or stop distance is not available.')}</p>
  </div>;
}
