'use client';

import {CalendarDays,ChevronDown} from 'lucide-react';
import {groupEconomicWeeks} from '@/lib/calendar-weeks';
import {todayIn} from '@/lib/trading';
import {type EconomicEvent} from '@/lib/economic-news';
import {useLanguage} from './journal-language';
import EconomicEventRows from './economic-event-rows';

export default function EconomicWeeks({events,timezone}:{events:EconomicEvent[];timezone:string}){
 const {language,locale}=useLanguage(),groups=groupEconomicWeeks(events,timezone,todayIn(timezone));
 return <div className="economic-week-groups">{groups.map(week=>{
  const start=new Intl.DateTimeFormat(locale,{timeZone:'UTC',month:'short',day:'numeric'}).format(new Date(`${week.start}T12:00:00Z`));
  const end=new Intl.DateTimeFormat(locale,{timeZone:'UTC',month:'short',day:'numeric'}).format(new Date(`${week.end}T12:00:00Z`));
  const high=week.events.filter(event=>event.impact==='High').length;
  const medium=week.events.filter(event=>event.impact==='Medium').length;
  const low=week.events.filter(event=>event.impact==='Low').length;
  return <details className="economic-week-card" key={week.start} open={week.kind==='current'}>
   <summary className="economic-week-summary">
    <span className="economic-week-title"><CalendarDays size={16}/><h3>{start} – {end}</h3><ChevronDown className="economic-week-chevron" size={16}/></span>
    <span className="economic-week-summary-meta">
     {high>0&&<span className="economic-week-impact high">{language==='ka'?'მაღალი':'High'} <b>{high}</b></span>}
     {medium>0&&<span className="economic-week-impact medium">{language==='ka'?'საშუალო':'Medium'} <b>{medium}</b></span>}
     {low>0&&<span className="economic-week-impact low">{language==='ka'?'დაბალი':'Low'} <b>{low}</b></span>}
     <span className="economic-week-total">{week.events.length} {language==='ka'?'მოვლენა':'events'}</span>
    </span>
   </summary>
   {week.events.length?<EconomicEventRows events={week.events} timezone={timezone} locale={locale} language={language}/>:<p className="economic-week-empty">{language==='ka'?'ამ კვირისთვის სიახლე არ მოიძებნა.':'No events this week.'}</p>}
  </details>;
 })}</div>;
}
