'use client';

import { useMemo, useState } from 'react';
import { Activity, ArrowUpRight, Check, CircleAlert, ClipboardCheck, LoaderCircle, Save, ShieldCheck, Sparkles } from 'lucide-react';
import type { Trade, TradeReview } from '@/lib/trading';
import { useLanguage } from './journal-language';

const checks = [
  ['setup', 'I followed my planned setup'],
  ['risk', 'I respected my risk'],
  ['entry', 'I followed my entry rules'],
  ['stop', 'I respected my stop-loss'],
  ['impulse', 'I avoided impulsive decisions'],
  ['exit', 'I exited according to my plan'],
] as const;
const mistakes = [
  ['clean', 'Clean execution'], ['early', 'Entered too early'], ['early_exit', 'Exited too early'], ['moved_stop', 'Moved my stop'],
  ['overtraded', 'Overtraded'], ['revenge', 'Revenge trade'], ['missed_confirmation', 'Missed confirmation'],
  ['ignored_plan', 'Ignored my plan'], ['other', 'Other'],
] as const;
const adherenceOptions = [['yes', 'Yes, completely'], ['partial', 'Partially'], ['no', 'No']] as const;
type Props = { trade: Trade; readiness: number | null; plannedRisk: number | null; onSave: (review: TradeReview) => Promise<void> };

export default function TradePostReview({ trade, readiness, plannedRisk, onSave }: Props) {
  const { t } = useLanguage();
  const [adherence, setAdherence] = useState<TradeReview['planAdherence']>(trade.review?.planAdherence ?? 'yes');
  const [selectedChecks, setSelectedChecks] = useState<string[]>(trade.review?.executionChecks ?? []);
  const [selectedMistakes, setSelectedMistakes] = useState<string[]>(trade.review?.mistakes ?? []);
  const [satisfiedConditions,setSatisfiedConditions]=useState<string[]>(trade.review?.satisfiedConditionIds??[]);
  const [lesson, setLesson] = useState(trade.review?.lesson ?? '');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [editing, setEditing] = useState(!trade.review);
  const [stage, setStage] = useState(0);

  const analysis = useMemo(() => {
    const execution = Math.round(selectedChecks.length / checks.length * 100);
    const adherenceScore = adherence === 'yes' ? 100 : adherence === 'partial' ? 55 : 0;
    const risk = selectedChecks.includes('risk') && selectedChecks.includes('stop') ? 100 : selectedChecks.includes('risk') || selectedChecks.includes('stop') ? 50 : 0;
    const emotional = selectedChecks.includes('impulse') && !selectedMistakes.includes('revenge') ? 100 : selectedChecks.includes('impulse') || !selectedMistakes.includes('revenge') ? 50 : 0;
    return { execution, adherence: adherenceScore, risk, emotional, process: Math.round(execution * .55 + adherenceScore * .3 + risk * .15) };
  }, [selectedChecks, selectedMistakes, adherence]);
  const outcome = trade.pnl > 0 ? t('Positive result') : trade.pnl < 0 ? t('Negative result') : t('Breakeven result');
  const processLabel = analysis.process >= 80 ? t('Strong process') : analysis.process >= 55 ? t('Mixed process') : t('Process to review');

  async function save() {
    setBusy(true); setError('');
    try {
      const executionQuality:TradeReview['executionQuality']=analysis.execution>=84?'excellent':analysis.execution>=67?'good':analysis.execution>=34?'partial':'needs_review';
      await onSave({ planAdherence: adherence, executionChecks: selectedChecks as TradeReview['executionChecks'], satisfiedConditionIds:satisfiedConditions, executionQuality, mistakes: selectedMistakes as TradeReview['mistakes'], lesson: lesson.trim(), readiness, plannedRisk, reviewedAt: new Date().toISOString() });
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : t('Review could not be saved.'));
    } finally { setBusy(false); }
  }
  function toggle(values: string[], setter: (next: string[]) => void, value: string) {
    if(value==='clean'&&!values.includes(value)){setter(['clean']);return;}
    setter(values.includes(value) ? values.filter(item => item !== value) : [...values.filter(item=>item!=='clean'),value]);
  }

  return <section className="post-trade-review" aria-label={t('Post-trade review')}>
    {trade.review && !editing ? <div className="post-review-analysis"><span className="focus-kicker"><Sparkles size={14}/>{t('PROCESS REVIEW')}</span><div className="post-review-result"><div><small>{t('Trade result')}</small><strong className={trade.pnl < 0 ? 'focus-risk-text' : trade.pnl > 0 ? 'focus-positive-text' : ''}>{outcome} · {trade.pnl > 0 ? '+' : ''}{trade.pnl.toFixed(2)}</strong></div><div><small>{t('Process quality')}</small><strong>{analysis.process}/100 · {processLabel}</strong></div></div>
      {trade.pnl < 0 && analysis.process >= 80 && <p className="post-review-insight good-process"><ShieldCheck size={17}/><span><strong>{t('Good process, negative outcome')}</strong>{t('You followed your setup and respected your risk. This loss can still be a process success.')}</span></p>}
      {trade.pnl > 0 && analysis.process < 55 && <p className="post-review-insight weak-process"><CircleAlert size={17}/><span><strong>{t('Positive result, weak process')}</strong>{t('A profitable outcome does not make a rule break repeatable. Review the decision, not just the result.')}</span></p>}
      <div className="post-review-metrics"><span><small>{t('Execution quality')}</small><b>{analysis.execution}%</b></span><span><small>{t('Plan adherence')}</small><b>{analysis.adherence}%</b></span><span><small>{t('Risk discipline')}</small><b>{analysis.risk}%</b></span><span><small>{t('Emotional control')}</small><b>{analysis.emotional}%</b></span></div>
      {trade.review.mistakes.length > 0 && <div className="post-review-tags"><small>{t('Mistakes noted')}</small>{trade.review.mistakes.map(id => <span key={id}>{t(mistakes.find(([key]) => key === id)?.[1] ?? id)}</span>)}</div>}
      {trade.review.lesson && <blockquote>{trade.review.lesson}</blockquote>}
      <button type="button" className="focus-edit-button" onClick={() => setEditing(true)}>{t('Update review')}<Activity size={14}/></button>
    </div> : <>
      <div className="post-review-heading"><span className="focus-kicker"><ClipboardCheck size={14}/>{t('AFTER THE TRADE')} · {t('STEP {v0} OF 3',{v0:stage+1})}</span><h3>{t('Review the decision, separate from the result.')}</h3><p>{t('A quick review helps you learn from wins and losses equally.')}</p><i className="post-review-step-progress"><b style={{width:`${(stage+1)/3*100}%`}}/></i></div>
      <fieldset className="post-review-fieldset" disabled={busy}>{stage===0&&<><legend>{t('Did you follow your pre-trade plan?')}</legend><div className="post-review-choice">{adherenceOptions.map(([id,label]) => <button type="button" key={id} className={adherence === id ? 'selected' : ''} aria-pressed={adherence === id} onClick={() => setAdherence(id)}>{adherence === id && <Check size={14}/>} {t(label)}</button>)}</div></>}
        {stage===1&&<><div className="post-review-group"><h4>{t('Which planned conditions were actually satisfied?')} <small>{t('Post-trade reality · optional')}</small></h4>{trade.strategyConditions?.length?<div className="post-review-checks">{trade.strategyConditions.map((condition)=><label key={condition.id} className={satisfiedConditions.includes(condition.id)?'checked':''}><input type="checkbox" checked={satisfiedConditions.includes(condition.id)} onChange={()=>setSatisfiedConditions(current=>current.includes(condition.id)?current.filter(id=>id!==condition.id):[...current,condition.id])}/><span><Check size={12}/></span>{condition.label}</label>)}</div>:<p className="analytics-data-note">{t('No strategy conditions were saved with this trade.')}</p>}</div><div className="post-review-group"><h4>{t('What happened?')} <small>{t('Select any that apply')}</small></h4><div className="post-review-tags selectable">{mistakes.map(([id,label]) => <button type="button" key={id} className={selectedMistakes.includes(id) ? 'selected' : ''} aria-pressed={selectedMistakes.includes(id)} onClick={() => toggle(selectedMistakes, setSelectedMistakes, id)}>{t(label)}</button>)}</div></div><div className="post-review-group"><h4>{t('Execution checks')} <small>{t('optional')}</small></h4><div className="post-review-checks">{checks.map(([id,label]) => <label key={id} className={selectedChecks.includes(id) ? 'checked' : ''}><input type="checkbox" checked={selectedChecks.includes(id)} onChange={() => toggle(selectedChecks, setSelectedChecks, id)}/><span><Check size={12}/></span>{t(label)}</label>)}</div></div></>}
        {stage===2&&<label className="post-review-lesson">{t('What should you remember from this trade?')}<textarea maxLength={500} value={lesson} onChange={event => setLesson(event.target.value)} placeholder={t('Example: I waited for confirmation and respected my risk.')}/></label>}
      </fieldset>
      {error && <p className="post-review-error" role="alert">{error}</p>}
      <div className="post-review-footer"><span>{stage>0&&<button className="focus-edit-button" type="button" disabled={busy} onClick={()=>setStage(value=>value-1)}>{t('Back')}</button>}<small>{t('Trade result')} · {trade.pnl > 0 ? '+' : ''}{trade.pnl.toFixed(2)} <i className="post-review-separator"/> {t('Process is scored separately.')}</small></span>{stage<2?<button type="button" className="primary" disabled={busy} onClick={()=>setStage(value=>value+1)}>{t('Continue')}<ArrowUpRight size={15}/></button>:<button type="button" className="primary" disabled={busy} onClick={() => void save()}>{busy ? <LoaderCircle className="post-review-spinner" size={16}/> : <Save size={16}/>} {busy ? t('Saving…') : t(trade.review ? 'Update review' : 'Complete review')}</button>}</div>
    </>}
  </section>;
}
