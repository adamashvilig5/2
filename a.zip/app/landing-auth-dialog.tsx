'use client';

import { startTransition, useEffect, useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, ArrowRight, Check, CreditCard, LockKeyhole, ShieldCheck, X } from 'lucide-react';
import { Dialog } from 'radix-ui';
import BillingCheckoutDialog from './membership/billing-checkout-dialog';
import GoogleSignInButton from './google-sign-in-button';
import type { MembershipState } from './membership/portal';

type AuthMode = 'login' | 'register' | 'forgot';

export default function LandingAuthDialog({
  open,
  initialMode = 'register',
  onOpenChange,
  onModeChange,
}: {
  open: boolean;
  initialMode?: 'login' | 'register';
  onOpenChange: (open: boolean) => void;
  onModeChange: (mode: 'login' | 'register') => void;
}) {
  const router = useRouter();
  const [mode, setMode] = useState<AuthMode>(initialMode);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [resetLink, setResetLink] = useState('');
  const [billing, setBilling] = useState<MembershipState | null>(null);
  const [planChooserOpen, setPlanChooserOpen] = useState(false);
  const [planError, setPlanError] = useState('');
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [consent, setConsent] = useState(false);
  const [checkoutError, setCheckoutError] = useState('');

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const authMode = params.get('auth');
    if (authMode === 'login' || authMode === 'register') startTransition(() => { setMode(authMode); onModeChange(authMode); onOpenChange(true); });
    if (params.get('checkout') === '1' || params.get('choosePlan') === '1') {
      fetch('/api/membership', { cache: 'no-store' }).then(async response => {
        if (!response.ok) throw Error();
        const state = await response.json() as MembershipState;
        if (state.member && state.access) router.replace('/journal');
        else if (state.member && !state.subscription) { setPlanChooserOpen(true); }
        else if (state.member) { setBilling(state); setCheckoutOpen(true); }
        else { setMode('register'); onOpenChange(true); }
      }).catch(() => { setMode('login'); onOpenChange(true); });
    }
    const authError = params.get('auth_error');
    if (authError) {
      startTransition(() => {
        setMode('login');
        onModeChange('login');
        setNotice('Continue with email and password instead.');
        onOpenChange(true);
      });
    }
  }, [onModeChange, onOpenChange, router]);

  const money = (cents: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(cents / 100);

  async function refreshedState() {
    const response = await fetch('/api/membership', { cache: 'no-store' });
    const data = await response.json() as MembershipState & { error?: string };
    if (!response.ok) throw Error(data.error || 'Could not load membership.');
    return data;
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(''); setNotice(''); setResetLink('');
    if (mode === 'register' && password !== confirm) { setError('Passwords do not match.'); return; }
    setBusy(true);
    try {
      if (mode === 'forgot') {
        const response = await fetch('/api/membership/password-reset', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'request', email }) });
        const result = await response.json() as { error?: string; deliveryConfigured?: boolean; debugLink?: string };
        if (!response.ok) throw Error(result.error || 'Could not request password reset.');
        setResetLink(result.debugLink || '');
        setNotice(result.deliveryConfigured ? 'If an account uses this email, a reset link is on its way.' : 'Password reset email delivery is not configured yet.');
        return;
      }
      const response = await fetch('/api/membership', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: mode, ...(mode === 'register' ? { name } : {}), email, password }) });
      const result = await response.json() as { error?: string };
      if (!response.ok) throw Error(result.error || 'Could not sign in.');
      const state = await refreshedState();
      setPassword(''); setConfirm('');
      if (state.member && state.access) { router.replace('/journal'); return; }
      if (state.member && !state.subscription) { setPlanError(''); setPlanChooserOpen(true); onOpenChange(false); }
      else if (state.member) { setBilling(state); setCheckoutOpen(true); onOpenChange(false); }
      else throw Error('Your account could not be loaded. Please try again.');
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Something went wrong.');
    } finally { setBusy(false); }
  }

  async function checkoutAction(action: 'pay' | 'fail') {
    if (!billing?.subscription) return;
    setBusy(true); setCheckoutError('');
    try {
      const response = await fetch('/api/membership', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, revision: billing.subscription.revision, requestId: crypto.randomUUID() }) });
      const result = await response.json() as { error?: string };
      if (!response.ok) throw Error(result.error || 'Checkout could not be completed.');
      if (action === 'fail') { setCheckoutError('The test payment failed. No charge was made. Please try again.'); return; }
      const state = await refreshedState(); setBilling(state); setCheckoutOpen(false); router.replace('/journal');
    } catch (reason) { setCheckoutError(reason instanceof Error ? reason.message : 'Checkout could not be completed.'); }
    finally { setBusy(false); }
  }

  async function choosePlan(plan: 'demo' | 'pro') {
    setBusy(true); setPlanError('');
    try {
      const response = await fetch('/api/membership', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'select_plan', plan }) });
      const result = await response.json() as { error?: string };
      if (!response.ok) throw Error(result.error || 'Could not save your plan choice.');
      const state = await refreshedState(); setPlanChooserOpen(false);
      if (plan === 'demo' && state.access) { router.replace('/journal'); return; }
      setBilling(state); setConsent(false); setCheckoutError(''); setCheckoutOpen(true);
    } catch (reason) { setPlanError(reason instanceof Error ? reason.message : 'Could not save your plan choice.'); }
    finally { setBusy(false); }
  }

  return <>
    <Dialog.Root open={planChooserOpen} onOpenChange={next=>{if(next)setPlanChooserOpen(true);}}>
      <Dialog.Portal><Dialog.Overlay className="landing-plan-overlay"/><Dialog.Content className="landing-plan-dialog" aria-describedby="landing-plan-description">
        <header className="landing-plan-header"><div><span className="landing-auth-eyebrow">CHOOSE YOUR WORKSPACE</span><Dialog.Title>Pick the plan that fits.</Dialog.Title><Dialog.Description id="landing-plan-description">Start with a one-trade demo or unlock the complete journal with Pro.</Dialog.Description></div></header>
        <div className="landing-plan-grid">
          <article className="landing-plan-card"><div className="landing-plan-top"><span>DEMO</span><b>Free</b></div><p>Try the journal with one saved trade. Explore the workspace before choosing Pro.</p><ul><li><Check size={15}/>One trade entry</li><li><Check size={15}/>Explore journal and analytics</li><li><Check size={15}/>No charge</li></ul><button className="landing-plan-demo" type="button" disabled={busy} onClick={()=>void choosePlan('demo')}>{busy?'Saving…':'Start free demo'}<ArrowRight size={16}/></button></article>
          <article className="landing-plan-card pro"><div className="landing-plan-top"><span>JOURNAL PRO</span><span className="landing-plan-tag">FULL ACCESS</span></div><div className="landing-plan-price"><strong>$20</strong><span>/ month</span></div><p>Full access to every tool, with unlimited trade logging and reviews.</p><ul><li><Check size={15}/>Unlimited trades and screenshots</li><li><Check size={15}/>All analytics, calendar and playbook tools</li><li><Check size={15}/>No free trial · monthly subscription</li></ul><button className="landing-plan-pro-button" type="button" disabled={busy} onClick={()=>void choosePlan('pro')}><CreditCard size={16}/>{busy?'Saving…':'Choose Pro'}<ArrowRight size={16}/></button></article>
        </div>{planError&&<p className="landing-auth-error" role="alert">{planError}</p>}<p className="landing-plan-footnote"><LockKeyhole size={13}/>Checkout is in test mode. No real payment will be collected.</p>
      </Dialog.Content></Dialog.Portal>
    </Dialog.Root>
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="landing-auth-overlay" />
        <Dialog.Content className="landing-auth-dialog" aria-describedby="landing-auth-description">
          <header className="landing-auth-header">
            <div className="landing-auth-brand"><span><ShieldCheck size={19}/></span><b>TRADE JOURNAL</b></div>
            <Dialog.Close className="landing-auth-close" aria-label="Close sign in"><X size={19}/></Dialog.Close>
          </header>
          <div className="landing-auth-body">
            <div className="landing-auth-copy"><span className="landing-auth-eyebrow">YOUR OWN TRADING SPACE</span><h2>{mode === 'register' ? 'Build a clearer trading routine.' : mode === 'forgot' ? 'Reset your password.' : 'Welcome back.'}</h2><p id="landing-auth-description">{mode === 'register' ? 'Create your account, then choose Demo or Journal Pro.' : mode === 'forgot' ? 'We’ll send a secure link if the email belongs to an account.' : 'Sign in to continue to your private journal.'}</p><div className="landing-auth-proof"><span><Check size={14}/>Private trading journal</span><span><Check size={14}/>Analytics, calendar and playbook</span><span><LockKeyhole size={14}/>Secure account access</span></div><div className="landing-auth-mini-chart" aria-hidden="true"><svg viewBox="0 0 360 92"><path d="M0 74 C24 68 30 57 52 62 S84 39 104 48 S136 26 158 39 S186 50 207 32 S239 40 259 22 S294 31 316 13 S342 20 360 5"/><path className="landing-auth-chart-fill" d="M0 74 C24 68 30 57 52 62 S84 39 104 48 S136 26 158 39 S186 50 207 32 S239 40 259 22 S294 31 316 13 S342 20 360 5 V92 H0Z"/></svg></div></div>
            <section className="landing-auth-form-wrap">
              {mode !== 'forgot' ? <div className="landing-auth-tabs"><button type="button" className={mode === 'login' ? 'active' : ''} onClick={() => { setMode('login'); setError(''); setNotice(''); }}>Sign in</button><button type="button" className={mode === 'register' ? 'active' : ''} onClick={() => { setMode('register'); setError(''); setNotice(''); }}>Create account</button></div> : <button className="landing-auth-back" type="button" onClick={() => { setMode('login'); setError(''); setNotice(''); }}><ArrowLeft size={15}/>Back to sign in</button>}
              <h3>{mode === 'register' ? 'Create your account' : mode === 'forgot' ? 'Forgot password?' : 'Sign in to your journal'}</h3>
              {mode !== 'forgot' && <GoogleSignInButton className="landing-auth-google" iconClassName="landing-google-icon" statusClassName="landing-google-status" label="Continue with Google"/>}
              <div className="landing-auth-divider"><span>{mode === 'forgot' ? 'PASSWORD RECOVERY' : 'OR CONTINUE WITH EMAIL'}</span></div>
              <form onSubmit={submit}>
                <fieldset disabled={busy}>
                  {mode === 'register' && <label>Full name<input required minLength={2} maxLength={80} autoComplete="name" value={name} onChange={event => setName(event.target.value)} placeholder="Your name"/></label>}
                  <label>Email<input required type="email" maxLength={254} autoComplete="email" value={email} onChange={event => setEmail(event.target.value)} placeholder="you@example.com"/></label>
                  {mode !== 'forgot' && <label>Password<input required type="password" minLength={12} maxLength={128} autoComplete={mode === 'register' ? 'new-password' : 'current-password'} value={password} onChange={event => setPassword(event.target.value)} placeholder="At least 12 characters"/>{mode === 'register' && <small>Use at least 12 characters.</small>}</label>}
                  {mode === 'register' && <label>Confirm password<input required type="password" minLength={12} maxLength={128} autoComplete="new-password" value={confirm} onChange={event => setConfirm(event.target.value)} placeholder="Re-enter your password"/></label>}
                  {error && <p className="landing-auth-error" role="alert">{error}</p>}{notice && <p className="landing-auth-notice" role="status">{notice}</p>}
                  <button className="landing-auth-submit" type="submit">{busy ? 'Please wait…' : mode === 'register' ? 'Create account' : mode === 'forgot' ? 'Send reset link' : 'Sign in'}<ArrowRight size={16}/></button>
                </fieldset>
              </form>
              {mode === 'login' && <button className="landing-auth-forgot" type="button" onClick={() => { setMode('forgot'); setError(''); setNotice(''); }}>Forgot password?</button>}
              {resetLink && <a className="landing-auth-reset-link" href={resetLink}>Open password reset link<ArrowRight size={14}/></a>}
              <p className="landing-auth-terms">{mode === 'register' ? 'Choose a free one-trade Demo or Pro for $20/month. No free trial.' : 'Your trades and notes stay private to your account.'}</p>
            </section>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
    {billing && <BillingCheckoutDialog open={checkoutOpen} onOpenChange={setCheckoutOpen} data={billing} busy={busy} consent={consent} setConsent={setConsent} money={money} error={checkoutError} onPay={() => void checkoutAction('pay')} onFail={() => void checkoutAction('fail')}/>}
  </>;
}
