'use client';
import { createContext,useCallback,useContext,useEffect,useState,type ReactNode } from 'react';
import { translate,journalLocale,type JournalLanguage } from '@/lib/journal-language';

type LanguageContextValue={language:JournalLanguage;locale:string;setLanguage:(language:JournalLanguage)=>void;t:(text:string,values?:Record<string,string|number>)=>string};
const LanguageContext=createContext<LanguageContextValue>({language:'en',locale:'en-US',setLanguage:()=>{},t:text=>text});
export function JournalLanguageProvider({children}:{children:ReactNode}){
 const [language,setCurrent]=useState<JournalLanguage>('en');
 useEffect(()=>{try{localStorage.setItem('trading-journal-language','en');}catch{}},[]);
 useEffect(()=>{document.documentElement.lang=language;},[language]);
 const setLanguage=useCallback((_next:JournalLanguage)=>{setCurrent('en');try{localStorage.setItem('trading-journal-language','en');}catch{}},[]);
 const t=useCallback((text:string,values?:Record<string,string|number>)=>translate(text,language,values),[language]);
 return <LanguageContext.Provider value={{language,locale:journalLocale(language),setLanguage,t}}>{children}</LanguageContext.Provider>;
}
export const useLanguage=()=>useContext(LanguageContext);
export function LanguageSelector(){
 return null;
}
