'use client';

import { useEffect, useRef, useState } from 'react';
import { ArrowRight } from 'lucide-react';

type Props = { className: string; iconClassName: string; label: string; statusClassName: string };
type GoogleMessage = { type?: string; flowId?: string; destination?: string; error?: string };

export default function GoogleSignInButton({ className, iconClassName, label, statusClassName }: Props) {
  const popup = useRef<Window | null>(null);
  const flowId = useRef('');
  const finished = useRef(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');

  useEffect(() => {
    const finish = (data: GoogleMessage) => {
      if (finished.current || data.type !== 'journal:google-auth' || data.flowId !== flowId.current) return;
      finished.current = true;
      const destination = data.destination;
      popup.current?.close();
      popup.current = null;
      setBusy(false);
      try { localStorage.removeItem(`trade-journal:google:${flowId.current}`); } catch { /* Storage can be disabled. */ }
      if (destination && destination.startsWith('/') && !destination.startsWith('//')) {
        window.location.assign(destination);
        return;
      }
      setNotice('Google sign-in did not finish. Continue with email and password.');
    };
    const receive = (event: MessageEvent<GoogleMessage>) => {
      if (event.origin === window.location.origin && event.source === popup.current) finish(event.data);
    };
    const receiveStorage = (event: StorageEvent) => {
      if (event.key !== `trade-journal:google:${flowId.current}` || !event.newValue) return;
      try { finish(JSON.parse(event.newValue) as GoogleMessage); } catch { setBusy(false); }
    };
    window.addEventListener('message', receive);
    window.addEventListener('storage', receiveStorage);
    const watch = window.setInterval(() => {
      if (popup.current?.closed) {
        popup.current = null;
        setBusy(false);
        flowId.current = '';
      }
    }, 350);
    return () => { window.removeEventListener('message', receive); window.removeEventListener('storage', receiveStorage); window.clearInterval(watch); popup.current?.close(); };
  }, []);

  function openGoogle() {
    setNotice('');
    flowId.current = crypto.randomUUID();
    finished.current = false;
    const child = window.open(`/api/auth/google?popup=1&flow=${encodeURIComponent(flowId.current)}`, 'trade-journal-google', 'popup=yes,width=520,height=680,resizable=yes,scrollbars=yes');
    if (!child) {
      setNotice('Allow the sign-in popup, or continue with email and password.');
      return;
    }
    popup.current = child;
    setBusy(true);
    child.focus();
  }

  return <>
    <button className={className} type="button" onClick={openGoogle} disabled={busy} aria-busy={busy}>
      <GoogleBrandIcon className={iconClassName}/>{busy ? 'Connecting to Google…' : label}<ArrowRight size={15}/>
    </button>
    {notice && <p className={statusClassName} role="status">{notice}</p>}
  </>;
}

function GoogleBrandIcon({ className }: { className: string }) {
  return <svg className={className} viewBox="0 0 48 48" aria-hidden="true" focusable="false">
    <path fill="#4285F4" d="M43.611 20.083H42V20H24v8h11.303C33.654 32.662 29.223 36 24 36c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4 12.955 4 4 12.955 4 24s8.955 20 20 20 20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z"/>
    <path fill="#34A853" d="M6.306 14.691l6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4c-7.682 0-14.344 4.326-17.694 10.691z"/>
    <path fill="#FBBC05" d="M24 44c5.166 0 9.86-1.977 13.409-5.197l-6.19-5.238C29.146 35.243 26.715 36 24 36c-5.202 0-9.62-3.312-11.273-7.946l-6.52 5.025C9.516 39.556 16.29 44 24 44z"/>
    <path fill="#EA4335" d="M43.611 20.083H42V20H24v8h11.303a12.04 12.04 0 0 1-4.086 5.565l6.19 5.238C41.359 35.084 44 29.938 44 24c0-1.341-.138-2.65-.389-3.917z"/>
  </svg>;
}
