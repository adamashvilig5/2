'use client';
import { useLanguage } from './journal-language';
import { useEffect, useState, type ReactNode } from 'react';
import { ThemeProvider, useTheme } from 'next-themes';
import { Moon, Sun } from 'lucide-react';
export function JournalTheme({ children }: {
    children: ReactNode;
}) {
    const { t, language, locale } = useLanguage();
    return <ThemeProvider attribute="data-theme" defaultTheme="dark" enableSystem={false} storageKey="trading-journal-theme" disableTransitionOnChange>{children}</ThemeProvider>;
}
export function ThemeToggle() {
    const { t, language, locale } = useLanguage();
    const { resolvedTheme, setTheme } = useTheme(), [mounted, setMounted] = useState(false);
    useEffect(() => setMounted(true), []);
    const light = mounted && resolvedTheme === 'light', label = light ? t("მუქ რეჟიმზე გადართვა") : t("ნათელ რეჟიმზე გადართვა");
    return <button type="button" className="theme-toggle" disabled={!mounted} aria-label={label} title={label} aria-pressed={light} onClick={() => setTheme(light ? 'dark' : 'light')}>{light ? <Moon size={19}/> : <Sun size={19}/>}</button>;
}
