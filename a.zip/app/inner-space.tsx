'use client';

import { useEffect, useMemo, useRef, useState, type CSSProperties } from 'react';
import {
  Activity,
  ArrowUpRight,
  BatteryLow,
  Brain,
  Check,
  CircleDot,
  Clock3,
  Crosshair,
  Gauge,
  Moon,
  Plus,
  RefreshCw,
  RotateCcw,
  Save,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  Pause,
  Play,
  Flag,
  ListChecks,
  ClipboardCheck,
  Timer,
  LockKeyhole,
  CloudFog,
  CloudSun,
  SunMedium,
  TrendingDown,
} from 'lucide-react';
import { blankInnerEntry, innerAnalytics, MINDSET_OPTIONS, type InnerEntry } from '@/lib/inner-space';
import { tradeEmotions, type Trade } from '@/lib/trading';
import JournalDatePicker from './journal-date-picker';
import { useLanguage } from './journal-language';

const mindsetLabels = {
  confident: 'Confident',
  focused: 'Focused',
  calm: 'Calm',
  patient: 'Patient',
  anxious: 'Anxious',
  fomo: 'FOMO',
  revenge: 'Revenge urge',
  tired: 'Tired',
} as const;

const mindsetIcons = {
  confident: TrendingUp,
  focused: Crosshair,
  calm: CircleDot,
  patient: Clock3,
  anxious: Activity,
  fomo: ArrowUpRight,
  revenge: RotateCcw,
  tired: Moon,
} as const;

const moods = [
  { value: 1, icon: TrendingDown, title: 'Low focus', hint: 'Focus feels limited', sticker: 'low' },
  { value: 2, icon: CloudFog, title: 'Uneasy', hint: 'Something feels off', sticker: 'uneasy' },
  { value: 3, icon: CircleDot, title: 'Balanced', hint: 'Steady and neutral', sticker: 'balanced' },
  { value: 4, icon: CloudSun, title: 'Positive', hint: 'Feeling good', sticker: 'positive' },
  { value: 5, icon: SunMedium, title: 'Sharp', hint: 'Clear and prepared', sticker: 'great' },
] as const;

const checklistItems = [
  'I know my setup',
  'My risk is within today’s limit',
  'I know where I exit if I am wrong',
  'I am not trying to recover a loss',
  'I know what would invalidate this trade',
] as const;
const focusGoals = ['Follow my plan', 'Protect capital', 'Only A+ setups', 'Review one strategy'] as const;
const mistakeLabels: Record<string,string> = { early:'Entered too early',early_exit:'Exited too early',moved_stop:'Moved my stop',overtraded:'Overtraded',revenge:'Revenge trade',missed_confirmation:'Missed confirmation',ignored_plan:'Ignored my plan',other:'Other' };
const defaultFocusPlan = { goal: 'Follow my entry rules', avoid: 'Overtrading after a loss', maxTrades: 3, risk: 0.5, reminder: 'Missing a trade is better than forcing one.' };
const processScore = (trade: Trade) => {
  const review = trade.review;
  if (!review) return null;
  const execution = review.executionChecks.length / 6 * 100;
  const adherence = review.planAdherence === 'yes' ? 100 : review.planAdherence === 'partial' ? 55 : 0;
  const risk = review.executionChecks.includes('risk') && review.executionChecks.includes('stop') ? 100 : review.executionChecks.includes('risk') || review.executionChecks.includes('stop') ? 50 : 0;
  return Math.round(execution * .55 + adherence * .3 + risk * .15);
};
function lossPressureByTrade(trades: Trade[]) {
  let streak = 0;
  const pressure = new Map<string, boolean>();
  for (const trade of trades.slice().sort((a,b)=>(a.date+a.entryTime).localeCompare(b.date+b.entryTime))) {
    pressure.set(trade.id, streak >= 2);
    streak = trade.pnl < 0 ? streak + 1 : 0;
  }
  return pressure;
}

function getEncouragement(report: ReturnType<typeof innerAnalytics>, t: (text: string) => string) {
  const challenging = report.mindsets
    .filter((item) => ['anxious', 'fomo', 'revenge', 'tired'].includes(item.id))
    .sort((a, b) => b.count - a.count)[0];

  if (challenging?.count) {
    const message = {
      anxious: 'Anxiety is a signal, not an order. Return to your risk plan; sitting out is a valid decision.',
      fomo: 'A move you missed does not change your plan. Wait for the setup that belongs to you.',
      revenge: 'The next trade does not need to win back the last one. Let your rules guide the next decision.',
      tired: 'Rest can be the best risk control. You do not owe the market another trade today.',
    }[challenging.id as 'anxious' | 'fomo' | 'revenge' | 'tired'];
    return { label: mindsetLabels[challenging.id as keyof typeof mindsetLabels], message: t(message) };
  }

  if (report.averageEnergy !== null && report.averageEnergy <= 2.5) {
    return { label: t('Energy'), message: t('Protect your focus before you protect a position. A planned pause is part of the process.') };
  }
  if (report.averageMood !== null && report.averageMood <= 2.5) {
    return { label: t('Mood'), message: t('One session does not define your ability. Review the quality of your decisions, one trade at a time.') };
  }
  if (report.entries) {
    return { label: t('Your process'), message: t('Patience is an edge. Keep your risk steady and let the right setup come to you.') };
  }
  return { label: t('Start with one check-in'), message: t('A quick check-in helps you notice your state before it starts shaping a trade.') };
}

export default function InnerSpace({ today, onDirtyChange, trades, onOpenReview, onProgressChange, initialStep = 'check' }: { today: string; onDirtyChange: (dirty: boolean) => void; trades: Trade[]; onOpenReview: (trade: Trade) => void; onProgressChange: () => void; initialStep?: 'check'|'session'|'review'|'analytics' }) {
  const { t } = useLanguage();
  const [tab, setTab] = useState<'check' | 'session' | 'review' | 'analytics'>(initialStep);
  const [experienceMode, setExperienceMode] = useState<'guided'|'advanced'>('guided');
  const [advancedCheckIn, setAdvancedCheckIn] = useState(false);
  const [advancedSession, setAdvancedSession] = useState(false);
  const [showAllInsights, setShowAllInsights] = useState(false);
  const [showAllReviewQueue, setShowAllReviewQueue] = useState(false);
  const [entries, setEntries] = useState<InnerEntry[]>([]);
  const [draft, setDraft] = useState(() => blankInnerEntry(today));
  const [saved, setSaved] = useState(() => JSON.stringify(blankInnerEntry(today)));
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [checks, setChecks] = useState<boolean[]>([false, false, false, false, false]);
  const [sessionType, setSessionType] = useState('New York');
  const [sessionGoal, setSessionGoal] = useState<string>(focusGoals[0]);
  const [maxTrades, setMaxTrades] = useState(3);
  const [riskLimit, setRiskLimit] = useState(0.5);
  const [dailyRiskBudget, setDailyRiskBudget] = useState(0);
  const [dailyLossLimit, setDailyLossLimit] = useState(0);
  const [sessionStartedAt, setSessionStartedAt] = useState<number | null>(null);
  const [sessionPausedAt, setSessionPausedAt] = useState<number | null>(null);
  const [sessionElapsed, setSessionElapsed] = useState(0);
  const [plan, setPlan] = useState(defaultFocusPlan);
  const [resetStep, setResetStep] = useState(-1);
  const [resetRemaining, setResetRemaining] = useState(60);
  const [resetRunning, setResetRunning] = useState(false);
  const [focusRatings, setFocusRatings] = useState({ focus: 3, clarity: 3, riskConfidence: 3 });
  const current = useRef(draft);
  const persistedFocusDate = useRef('');
  const dirty = JSON.stringify(draft) !== saved;
  useEffect(() => { current.current = draft; }, [draft]);

  useEffect(() => {
    onDirtyChange(dirty);
    return () => onDirtyChange(false);
  }, [dirty, onDirtyChange]);

  async function load() {
    setLoading(true);
    setError('');
    try {
      const response = await fetch('/api/inner-space', { cache: 'no-store' });
      const data = await response.json() as { entries: InnerEntry[]; error?: string };
      if (!response.ok) throw new Error(data.error);
      setEntries(data.entries);
      const next = data.entries.find((entry) => entry.date === current.current.date) ?? blankInnerEntry(current.current.date);
      setDraft(next);
      setSaved(JSON.stringify(next));
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }

  // Fetching the existing saved check-ins is the server synchronization boundary for this page.
  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => { void load(); }, []);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(`trader-focus-v2:${draft.date}`);
      const stored = raw ? JSON.parse(raw) as { checks?: boolean[]; plan?: typeof defaultFocusPlan; sessionType?: string; sessionGoal?: string; maxTrades?: number; riskLimit?: number; dailyRiskBudget?: number; dailyLossLimit?: number; startedAt?: number; pausedAt?: number | null; elapsed?: number; focusRatings?: typeof focusRatings } : null;
      // Loading persisted per-day controls is the synchronization boundary for this client-only workspace UI.
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setChecks(stored?.checks?.length === checklistItems.length ? stored.checks : [false, false, false, false, false]);
      setPlan(stored?.plan ?? defaultFocusPlan);
      setSessionType(stored?.sessionType ?? 'New York');
      setSessionGoal(stored?.sessionGoal ?? focusGoals[0]);
      setMaxTrades(stored?.maxTrades ?? 3);
      setRiskLimit(stored?.riskLimit ?? 0.5);
      setDailyRiskBudget(stored?.dailyRiskBudget ?? 0);
      setDailyLossLimit(stored?.dailyLossLimit ?? 0);
      setSessionStartedAt(stored?.startedAt ?? null);
      setSessionPausedAt(stored?.pausedAt ?? null);
      setSessionElapsed(stored?.elapsed ?? 0);
      setFocusRatings(stored?.focusRatings ?? { focus: 3, clarity: 3, riskConfidence: 3 });
    } catch {
      setChecks([false, false, false, false, false]);
      setPlan(defaultFocusPlan);
      setDailyRiskBudget(0);
      setSessionStartedAt(null);
      setSessionPausedAt(null);
      setSessionElapsed(0);
      setFocusRatings({ focus: 3, clarity: 3, riskConfidence: 3 });
    }
  }, [draft.date]);

  useEffect(() => {
    if (persistedFocusDate.current !== draft.date) {
      persistedFocusDate.current = draft.date;
      return;
    }
    try {
      const readinessSnapshot = draft.mood === null ? 0 : Math.max(12, Math.min(100, Math.round(draft.energy * 5 + focusRatings.focus * 5 + focusRatings.clarity * 5 + focusRatings.riskConfidence * 5 + Math.min(checks.filter(Boolean).length, 5) * 4 + (draft.mindset.includes('focused') ? 8 : 0))));
      localStorage.setItem(`trader-focus-v2:${draft.date}`, JSON.stringify({ checks, plan, sessionType, sessionGoal, maxTrades, riskLimit, dailyRiskBudget, dailyLossLimit, startedAt: sessionStartedAt, pausedAt: sessionPausedAt, elapsed: sessionElapsed, focusRatings, readiness: readinessSnapshot }));
    } catch { /* Focus tools remain usable when browser storage is unavailable. */ }
  }, [draft.date, draft.mood, draft.energy, draft.mindset, checks, plan, sessionType, sessionGoal, maxTrades, riskLimit, dailyRiskBudget, dailyLossLimit, sessionStartedAt, sessionPausedAt, sessionElapsed, focusRatings]);

  useEffect(() => {
    if (!sessionStartedAt || sessionPausedAt) return;
    const tick = () => setSessionElapsed(Math.max(0, Math.floor((Date.now() - sessionStartedAt) / 1000)));
    tick();
    const timer = window.setInterval(tick, 1000);
    return () => window.clearInterval(timer);
  }, [sessionStartedAt, sessionPausedAt]);

  useEffect(() => {
    if (!resetRunning) return;
    const timer = window.setInterval(() => {
      if (resetRemaining <= 1) {
        setResetRemaining(0);
        setResetRunning(false);
        setResetStep(3);
      } else {
        const nextRemaining = resetRemaining - 1;
        setResetRemaining(nextRemaining);
        setResetStep(Math.min(3, Math.floor((60 - nextRemaining) / 15)));
      }
    }, 1000);
    return () => window.clearInterval(timer);
  }, [resetRunning, resetRemaining]);

  const report = useMemo(() => innerAnalytics(entries.filter((entry) => entry.date <= today)), [entries, today]);
  const boost = useMemo(() => getEncouragement(report, t), [report, t]);
  const todayTrades = useMemo(() => trades.filter((trade) => trade.date === draft.date), [trades, draft.date]);
  const reviewedTrades = useMemo(() => trades.filter((trade) => trade.review), [trades]);
  const processScores = reviewedTrades.map(trade => processScore(trade) ?? 0);
  const averageProcess = processScores.length ? Math.round(processScores.reduce((sum, value) => sum + value, 0) / processScores.length) : null;
  const adherenceRate = reviewedTrades.length ? Math.round(reviewedTrades.reduce((sum, trade) => sum + (trade.review?.planAdherence === 'yes' ? 100 : trade.review?.planAdherence === 'partial' ? 50 : 0), 0) / reviewedTrades.length) : null;
  const riskDiscipline = reviewedTrades.length ? Math.round(reviewedTrades.reduce((sum, trade) => sum + Number(trade.review?.executionChecks.includes('risk')) * 50 + Number(trade.review?.executionChecks.includes('stop')) * 50, 0) / reviewedTrades.length) : null;
  const emotionalControl = reviewedTrades.length ? Math.round(reviewedTrades.reduce((sum, trade) => sum + (trade.review?.executionChecks.includes('impulse') && !trade.review.mistakes.includes('revenge') ? 100 : 0), 0) / reviewedTrades.length) : null;
  const reviewCompletion = trades.length ? Math.round(reviewedTrades.length / trades.length * 100) : null;
  const weeklyReviews = reviewedTrades.filter(trade => trade.date >= (()=>{const date=new Date(`${today}T12:00:00Z`);date.setUTCDate(date.getUTCDate()-6);return date.toISOString().slice(0,10);})() && trade.date <= today);
  const weeklyProcess = weeklyReviews.length ? Math.round(weeklyReviews.reduce((sum, trade) => sum + (processScore(trade) ?? 0), 0) / weeklyReviews.length) : null;
  const priorWeekReviews = reviewedTrades.filter(trade => { const date=new Date(`${today}T12:00:00Z`);date.setUTCDate(date.getUTCDate()-13);const start=date.toISOString().slice(0,10);date.setUTCDate(date.getUTCDate()+6);return trade.date>=start&&trade.date<=date.toISOString().slice(0,10); });
  const priorWeekProcess = priorWeekReviews.length>=2?Math.round(priorWeekReviews.reduce((sum,trade)=>sum+(processScore(trade)??0),0)/priorWeekReviews.length):null;
  const processChange = weeklyProcess!==null&&priorWeekProcess!==null?weeklyProcess-priorWeekProcess:null;
  const weeklyPlanFollowed = weeklyReviews.filter(trade => trade.review?.planAdherence === 'yes').length;
  const weeklyImpulsive = weeklyReviews.filter(trade => trade.review?.mistakes.some(item => ['revenge','overtraded','early','ignored_plan'].includes(item))).length;
  const mistakeTotals = reviewedTrades.flatMap(trade => trade.review?.mistakes ?? []).filter(mistake=>mistake!=='clean').reduce<Record<string,number>>((totals, mistake) => { totals[mistake] = (totals[mistake] ?? 0) + 1; return totals; }, {});
  const topMistake = Object.entries(mistakeTotals).sort((a,b)=>b[1]-a[1])[0];
  const weeklyTopMistake = Object.entries(weeklyReviews.flatMap(trade=>trade.review?.mistakes??[]).filter(mistake=>mistake!=='clean').reduce<Record<string,number>>((totals,mistake)=>{totals[mistake]=(totals[mistake]??0)+1;return totals;},{})).sort((a,b)=>b[1]-a[1])[0];
  const sessionQuality = Object.entries(reviewedTrades.reduce<Record<string,{score:number;count:number}>>((groups, trade)=>{const row=groups[trade.session]??{score:0,count:0};row.score+=processScore(trade)??0;row.count++;groups[trade.session]=row;return groups;},{})).filter(([,row])=>row.count>=2).map(([name,row])=>({name,score:Math.round(row.score/row.count)})).sort((a,b)=>b.score-a.score);
  const weeklySessionQuality = Object.entries(weeklyReviews.reduce<Record<string,{score:number;count:number}>>((groups, trade)=>{const row=groups[trade.session]??{score:0,count:0};row.score+=processScore(trade)??0;row.count++;groups[trade.session]=row;return groups;},{})).filter(([,row])=>row.count>=2).map(([name,row])=>({name,score:Math.round(row.score/row.count)})).sort((a,b)=>b.score-a.score);
  const reviewByDate = new Map(entries.map(entry=>[entry.date,entry]));
  const bestProcessMindset = MINDSET_OPTIONS.map(id=>{const rows=reviewedTrades.filter(trade=>reviewByDate.get(trade.date)?.mindset.includes(id));return {id,rows,score:rows.length?Math.round(rows.reduce((sum,trade)=>sum+(processScore(trade)??0),0)/rows.length):0};}).filter(item=>item.rows.length>=2).sort((a,b)=>b.score-a.score)[0];
  const weeklyBestProcessMindset = MINDSET_OPTIONS.map(id=>{const rows=weeklyReviews.filter(trade=>reviewByDate.get(trade.date)?.mindset.includes(id));return {id,rows,score:rows.length?Math.round(rows.reduce((sum,trade)=>sum+(processScore(trade)??0),0)/rows.length):0};}).filter(item=>item.rows.length>=2).sort((a,b)=>b.score-a.score)[0];
  const pendingReviewTrades = useMemo(()=>trades.filter(trade=>!trade.review).sort((a,b)=>(b.date+b.entryTime).localeCompare(a.date+a.entryTime)),[trades]);
  const checkInComplete = draft.mood !== null;
  const sessionComplete = sessionStartedAt !== null;
  const reviewComplete = trades.length > 0 && pendingReviewTrades.length === 0;
  const processSteps = [
    {id:'check' as const,label:'Check-in',done:checkInComplete,icon:Brain},
    {id:'session' as const,label:'Session plan',done:sessionComplete,icon:Crosshair},
    {id:'review' as const,label:'Trade review',done:reviewComplete,icon:ClipboardCheck},
    {id:'analytics' as const,label:'Insights',done:false,icon:Gauge},
  ];
  const highReadiness = reviewedTrades.filter(trade => trade.review?.readiness != null && trade.review.readiness >= 75);
  const lowReadiness = reviewedTrades.filter(trade => trade.review?.readiness != null && trade.review.readiness < 75);
  const readinessInsight = highReadiness.length >= 2 && lowReadiness.length >= 2 ? Math.round(highReadiness.reduce((sum,trade)=>sum+(processScore(trade)??0),0)/highReadiness.length)-Math.round(lowReadiness.reduce((sum,trade)=>sum+(processScore(trade)??0),0)/lowReadiness.length) : null;
  const lossPressure = lossPressureByTrade(trades);
  const afterLosses = reviewedTrades.filter(trade=>lossPressure.get(trade.id));
  const withoutLosses = reviewedTrades.filter(trade=>!lossPressure.get(trade.id));
  const lossPressureInsight = afterLosses.length>=2&&withoutLosses.length>=2?Math.round(afterLosses.reduce((sum,trade)=>sum+(processScore(trade)??0),0)/afterLosses.length)-Math.round(withoutLosses.reduce((sum,trade)=>sum+(processScore(trade)??0),0)/withoutLosses.length):null;
  const todayPnl = todayTrades.reduce((sum, trade) => sum + trade.pnl, 0);
  const readiness = draft.mood === null ? 0 : Math.max(12, Math.min(100, Math.round(draft.energy * 5 + focusRatings.focus * 5 + focusRatings.clarity * 5 + focusRatings.riskConfidence * 5 + Math.min(checks.filter(Boolean).length, 5) * 4 + (draft.mindset.includes('focused') ? 8 : 0))));
  const readinessLabel = draft.mood === null ? 'Check-in needed' : readiness >= 72 ? 'Prepared to trade' : readiness >= 48 ? 'Pause and review' : 'Consider sitting out';
  const orderedTodayTrades = [...todayTrades].sort((a,b)=>(a.date+a.entryTime).localeCompare(b.date+b.entryTime));
  const lossesInRow = (() => { let count = 0; for (const trade of [...orderedTodayTrades].reverse()) { if (trade.pnl < 0) count++; else break; } return count; })();
  const lastThree = orderedTodayTrades.slice(-3);
  const rapidTrading = lastThree.length === 3 && (new Date(`${draft.date}T${lastThree[2].entryTime}:00`).getTime() - new Date(`${draft.date}T${lastThree[0].entryTime}:00`).getTime()) <= 30 * 60 * 1000;
  const riskEscalation = orderedTodayTrades.length >= 2 && orderedTodayTrades.at(-2)!.pnl < 0 && orderedTodayTrades.at(-1)!.risk > orderedTodayTrades.at(-2)!.risk * 1.25;
  const revengeBehavior = draft.mindset.includes('revenge') || todayTrades.some(trade => tradeEmotions(trade).some(emotion => /revenge|შურისძიება/i.test(emotion)));
  const riskUsed = todayTrades.reduce((sum, trade) => sum + trade.risk, 0);
  const tiltSignal = lossesInRow >= 2 || rapidTrading || riskEscalation || revengeBehavior || todayTrades.length > maxTrades || (dailyRiskBudget > 0 && riskUsed >= dailyRiskBudget * .8) || (dailyLossLimit > 0 && todayPnl <= -(dailyLossLimit * 0.8));
  const trackedMoodRows = useMemo(() => moods.map((mood) => {
    const group = entries.filter((entry) => entry.mood === mood.value);
    const matchedDates = new Set(group.map((entry) => entry.date));
    const relatedTrades = trades.filter((trade) => matchedDates.has(trade.date));
    const wins = relatedTrades.filter((trade) => trade.pnl > 0).length;
    return { ...mood, entries: group.length, trades: relatedTrades.length, pnl: relatedTrades.reduce((sum, trade) => sum + trade.pnl, 0), winRate: relatedTrades.length ? Math.round((wins / relatedTrades.length) * 100) : null };
  }), [entries, trades]);
  const checkInDates = new Set(entries.map((entry) => entry.date));
  let processStreak = 0;
  const streakDate = new Date(`${today}T12:00:00Z`);
  while (checkInDates.has(streakDate.toISOString().slice(0, 10)) && processStreak < 365) {
    processStreak++;
    streakDate.setUTCDate(streakDate.getUTCDate() - 1);
  }

  function startSession() {
    setSessionStartedAt(Date.now() - sessionElapsed * 1000);
    setSessionPausedAt(null);
    setTab('session');
  }

  function pauseSession() {
    if (sessionPausedAt) {
      setSessionStartedAt(Date.now() - sessionElapsed * 1000);
      setSessionPausedAt(null);
    } else {
      setSessionPausedAt(Date.now());
    }
  }

  function endSession() {
    setSessionStartedAt(null);
    setSessionPausedAt(null);
    setSessionElapsed(0);
  }

  function change(patch: Partial<InnerEntry>) {
    setDraft((value) => ({ ...value, ...patch }));
    setNotice('');
  }

  function selectDate(date: string) {
    if (dirty && !window.confirm(t('Discard unsaved Trader Focus changes?'))) return;
    const next = entries.find((entry) => entry.date === date) ?? blankInnerEntry(date);
    setDraft(next);
    setSaved(JSON.stringify(next));
    setError('');
    setNotice('');
  }

  async function save() {
    setBusy(true);
    setError('');
    try {
      const response = await fetch('/api/inner-space', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(draft),
      });
      const data = await response.json() as { entry: InnerEntry; error?: string };
      if (!response.ok) throw new Error(data.error);
      setDraft(data.entry);
      setSaved(JSON.stringify(data.entry));
      setEntries((value) => [data.entry, ...value.filter((entry) => entry.date !== data.entry.date)]);
      setNotice('Your check-in is saved.');
      onProgressChange();
      return true;
    } catch (e) {
      setError((e as Error).message);
      return false;
    } finally {
      setBusy(false);
    }
  }

  async function continueToSession() {
    if (dirty && !(await save())) return;
    setTab('session');
  }

  return (
    <div className="inner-space trader-focus trader-focus-v2">
      <header className="focus-v2-header">
        <div><span className="inner-eyebrow">{t('YOUR EDGE STARTS INSIDE')}</span><h2>{t('Trader Focus')}</h2><p>{t('Build discipline before you build results.')}</p></div>
        <div className="focus-streak"><span><Activity size={16}/>{t('Process streak')}</span><strong>{processStreak} {t('days')}</strong><small>{t('Consecutive check-ins')}</small></div>
      </header>

      <section className="focus-process-stepper" aria-label={t('Today’s trading process')}>
        <div className="focus-process-stepper-head"><div><span className="focus-kicker"><Activity size={14}/>{t('TODAY’S TRADING PROCESS')}</span><p>{t(tab==='check'?'Start with a quick check-in. Next, set the boundaries for this session.':tab==='session'?'Set your guardrails, then start the session.':tab==='review'?'Review the decision after each trade. Insights build from those reviews.':'Patterns become more useful as your reviews accumulate.')}</p></div><div className="focus-stepper-controls"><button type="button" className={`focus-mode-toggle ${experienceMode==='advanced'?'active':''}`} onClick={()=>setExperienceMode(value=>value==='guided'?'advanced':'guided')}>{t(experienceMode==='guided'?'Guided':'Advanced')}<span>{t('mode')}</span></button><JournalDatePicker value={draft.date} label={t('Focus date')} today={today} max={today} disabled={loading || busy} compact onChange={selectDate}/></div></div>
        <nav className="focus-process-steps">{processSteps.map((step,index)=>{const Icon=step.icon;return <button type="button" key={step.id} className={`${tab===step.id?'active':''} ${step.done?'complete':''}`} aria-current={tab===step.id?'step':undefined} onClick={()=>setTab(step.id)}><span className="focus-step-number">{step.done?<Check size={14}/>:<Icon size={14}/>}</span><span className="focus-step-label"><small>{t('STEP {v0}',{v0:index+1})}</small><strong>{t(step.label)}</strong></span>{index<processSteps.length-1&&<i aria-hidden="true"/>}</button>;})}</nav>
      </section>

      {error && <div className="notice error" role="alert">{t(error)}<button className="inline-link" disabled={busy} onClick={() => { if (!dirty || window.confirm(t('Discard unsaved Trader Focus changes?'))) void load(); }}>{t('Reload entries')}</button></div>}
      {notice && <div className="notice success" role="status"><Check size={16}/>{t(notice)}</div>}
      {loading ? <div className="panel empty-state"><RefreshCw size={22}/><p>{t('Loading your check-ins…')}</p></div> : <>
        {tab === 'check' && <div className="focus-v2-layout">
          <section className="panel focus-readiness">
            <div className="focus-readiness-main"><div className="focus-readiness-copy"><span className="focus-kicker"><ShieldCheck size={15}/>{t('SELF-ASSESSMENT · NOT A SIGNAL')}</span><h2>{t('Are you ready to follow your plan?')}</h2><p>{t('A quick check helps you decide what to focus on. This is a self-assessment, not a trading signal.')}</p><span className={`readiness-status ${readiness >= 72 ? 'ready' : readiness >= 48 ? 'caution' : 'low'}`}><i/>{t(readinessLabel)}</span></div>
              <div className="readiness-ring" style={{ '--readiness': `${readiness}%` } as CSSProperties} aria-label={`${readiness} out of 100 self-assessed readiness`}><div><strong>{readiness}</strong><small>/ 100</small></div></div>
            </div>
            <div className="readiness-metrics"><div><span>{t('Energy')}</span><strong>{draft.energy * 2}<small>/10</small></strong><i><b style={{width:`${draft.energy * 20}%`}}/></i></div><div><span>{t('Focus')}</span><strong>{focusRatings.focus * 2}<small>/10</small></strong><i><b style={{width:`${focusRatings.focus * 20}%`}}/></i></div><div><span>{t('Risk confidence')}</span><strong>{focusRatings.riskConfidence * 2}<small>/10</small></strong><i><b style={{width:`${focusRatings.riskConfidence * 20}%`}}/></i></div><div><span>{t('Mindset')}</span><strong>{draft.mood===null?'—':t(moods[draft.mood-1].title)}</strong><small>{t('self-reported')}</small></div></div>
            <div className="focus-self-ratings">{([['focus','Focus'],['riskConfidence','Risk confidence']] as const).map(([key,label])=><label key={key}><span>{t(label)}</span><input type="range" min={1} max={5} value={focusRatings[key]} onChange={event=>setFocusRatings(current=>({...current,[key]:Number(event.target.value)}))} aria-label={t(label)}/><strong>{focusRatings[key]}/5</strong></label>)}</div>
            <div className="focus-checkin-next"><p>{t('Next: set your session limits and review the entry checklist.')}</p><button className="primary" disabled={busy} onClick={()=>void continueToSession()}><ArrowUpRight size={16}/>{t('Continue to session setup')}</button></div>
          </section>

          <section className="panel focus-mood-card inner-mood-panel"><div className="focus-v2-section-head"><div><span className="focus-kicker"><Brain size={15}/>{t('CHECK-IN')}</span><h2>{t('How are you showing up today?')}</h2><p>{t('Choose the state that best matches your trading mindset.')}</p></div></div>
            <div className="mood-options">{moods.map((mood) => { const MoodIcon=mood.icon; return <button key={mood.value} disabled={busy} aria-pressed={draft.mood === mood.value} className={`${draft.mood === mood.value ? 'selected' : ''} mood-${mood.sticker}`} onClick={(event) => { change({mood:mood.value}); const card=event.currentTarget; card.classList.remove('mood-bloom'); void card.offsetWidth; card.classList.add('mood-bloom'); window.setTimeout(()=>card.classList.remove('mood-bloom'),1100); }}><span className="mood-sticker-art" aria-hidden="true"><MoodIcon size={25} strokeWidth={1.8}/></span><strong>{t(mood.title)}</strong><small>{t(mood.hint)}</small>{draft.mood === mood.value && <span className="mood-selected-mark"><Check size={14}/></span>}</button>; })}</div>
            <label className="inner-energy" style={{'--energy-progress':`${((draft.energy-1)/4)*100}%`,'--energy-thumb':draft.energy<=2?'#ef4444':draft.energy===3?'#e8ae35':'#10b981'} as CSSProperties}><span><BatteryLow size={17}/>{t('Energy')}</span><input type="range" min={1} max={5} value={draft.energy} disabled={busy} onChange={(e)=>change({energy:Number(e.target.value)})}/><strong key={draft.energy}>{draft.energy} / 5</strong></label>
            <button className="focus-advanced-toggle" type="button" aria-expanded={advancedCheckIn||experienceMode==='advanced'} onClick={()=>{if(experienceMode==='advanced')setExperienceMode('guided');else setAdvancedCheckIn(value=>!value);}}>{t(advancedCheckIn||experienceMode==='advanced'?'Hide advanced check-in':'Show advanced check-in')}<Plus size={14}/></button>
            {(advancedCheckIn||experienceMode==='advanced')&&<div className="focus-advanced-fields"><label>{t('Emotional clarity')} · {focusRatings.clarity}/5<input type="range" min={1} max={5} value={focusRatings.clarity} onChange={event=>setFocusRatings(current=>({...current,clarity:Number(event.target.value)}))}/></label><div className="focus-mindset-block"><div><h3>{t('What is your trading mindset?')}</h3><p>{t('Select all that describe you right now.')}</p></div><div className="mindset-options">{MINDSET_OPTIONS.map((id) => { const Icon=mindsetIcons[id]; const selected=draft.mindset.includes(id); return <button key={id} disabled={busy} aria-pressed={selected} className={`${selected?'selected':''} ${['anxious','fomo','revenge','tired'].includes(id)?'challenging':''}`} onClick={()=>change({mindset:selected?draft.mindset.filter((item)=>item!==id):[...draft.mindset,id]})}><Icon size={16}/>{t(mindsetLabels[id])}<span className="mindset-state-icon" aria-hidden="true">{selected?<Check size={14}/>:<Plus size={13}/>}</span></button>; })}</div></div><label className="field inner-intention">{t('One intention for your next session')}<textarea maxLength={2000} value={draft.intention} disabled={busy} placeholder={t('What will you focus on, regardless of the outcome?')} onChange={(e)=>change({intention:e.target.value})}/></label></div>}
          </section>
          <div className="inner-save focus-v2-save"><span>{t(dirty?'Unsaved check-in changes':'Your check-in is up to date.')}</span><button className="secondary" disabled={busy||!dirty} onClick={save}><Save size={16}/>{t(busy?'Saving…':'Save check-in')}</button></div>
        </div>}

        {tab === 'session' && <div className="focus-session-layout">
          <section className={`panel focus-session-hero ${sessionStartedAt?'is-active':''}`}><div className="focus-session-top"><div><span className="focus-kicker"><Crosshair size={15}/>{sessionStartedAt?t('SESSION IN PROGRESS'):t('SESSION SETUP')}</span><h2>{sessionStartedAt?t(`${sessionType} session`):t('Make the next decision intentional.')}</h2><p>{sessionStartedAt?t('Keep your attention on the plan, not the last outcome.'):t('Set a few clear boundaries before the market gets moving.')}</p></div><span className={`session-live ${sessionStartedAt&&!sessionPausedAt?'live':''}`}><i/>{sessionStartedAt?(sessionPausedAt?t('Paused'):t('Live')):t('Not started')}</span></div>
            {!sessionStartedAt?<div className="focus-session-setup"><label>{t('Session')}<select value={sessionType} onChange={(e)=>setSessionType(e.target.value)}>{['London','New York','Asia','Custom'].map((item)=><option key={item}>{item}</option>)}</select></label><label>{t('Today’s goal')}<select value={sessionGoal} onChange={(e)=>setSessionGoal(e.target.value)}>{focusGoals.map((item)=><option key={item}>{t(item)}</option>)}</select></label><label>{t('Maximum trades')}<input type="number" min={1} max={50} value={maxTrades} onChange={(e)=>setMaxTrades(Number(e.target.value))}/></label><label>{t('Risk per trade (%)')}<input type="number" min={0.1} step={0.1} value={riskLimit} onChange={(e)=>setRiskLimit(Number(e.target.value))}/></label><label>{t('Daily loss limit (account currency; 0 disables)')}<input type="number" min={0} step={10} value={dailyLossLimit} onChange={(e)=>setDailyLossLimit(Number(e.target.value))}/></label><div className="focus-session-start"><span><LockKeyhole size={15}/>{t('Your limits stay on this device')}</span><p>{t('Next: check your five guardrails, then start the session.')}</p></div></div>:<div className="focus-session-live-grid"><div className="session-timer"><Timer size={19}/><strong>{String(Math.floor(sessionElapsed/3600)).padStart(2,'0')}:{String(Math.floor((sessionElapsed%3600)/60)).padStart(2,'0')}:{String(sessionElapsed%60).padStart(2,'0')}</strong><small>{t(sessionPausedAt?'Paused duration':'Time in session')}</small></div><div><span>{t('Trades taken')}</span><strong>{todayTrades.length}<small> / {maxTrades}</small></strong><i><b style={{width:`${Math.min(100,todayTrades.length/maxTrades*100)}%`}}/></i></div><div><span>{t('Risk used')} · {t('saved trade risk')}</span><strong>{riskUsed.toFixed(2)}<small> / {dailyRiskBudget>0?dailyRiskBudget.toFixed(2):t('no risk budget')}</small></strong><i><b style={{width:`${dailyRiskBudget>0?Math.min(100,riskUsed/dailyRiskBudget*100):0}%`}}/></i></div><div><span>{t('Current P&L')}</span><strong className={todayPnl<0?'focus-risk-text':'focus-positive-text'}>{todayPnl>=0?'+':''}{todayPnl.toFixed(2)}</strong><small>{t('From today’s saved trades')}</small></div><div className="session-focus-status"><span>{t('Focus status')}</span><strong><i/>{t(draft.mood===null?'Check-in needed':readinessLabel)}</strong><small>{t('Self-reported · update in Check-in')}</small></div><div className="focus-session-controls"><button className="secondary" onClick={pauseSession}>{sessionPausedAt?<Play size={16}/>:<Pause size={16}/>} {t(sessionPausedAt?'Resume session':'Pause session')}</button><button className="quiet-danger" onClick={endSession}>{t('End session')}</button></div></div>}
          </section>
          {!sessionStartedAt&&<section className="panel focus-checklist"><div className="focus-v2-section-head"><div><span className="focus-kicker"><ListChecks size={15}/>{t('SESSION GUARDRAILS')}</span><h2>{t('Before you start')}</h2><p>{checks.filter(Boolean).length} {t('of')} 5 {t('checks completed')}</p></div><span className="checklist-count">{checks.filter(Boolean).length}<small>/5</small></span></div><div className="checklist-progress"><i><b style={{width:`${checks.filter(Boolean).length*20}%`}}/></i></div><div className="focus-check-items">{checklistItems.map((item,index)=><label key={item} className={checks[index]?'done':''}><input type="checkbox" checked={checks[index]} onChange={(event)=>setChecks((value)=>value.map((checked,i)=>i===index?event.target.checked:checked))}/><span className="focus-custom-check"><Check size={13}/></span><span>{t(item)}</span></label>)}</div>{checks.filter(Boolean).length<5&&<p className="focus-calm-warning"><ShieldCheck size={16}/>{t('One check is still incomplete. Reviewing it may protect your process.')}</p>}<div className="focus-session-primary"><p>{checks.filter(Boolean).length===5?<><Check size={15}/>{t('Ready to start')}</>:t('You can continue when you feel ready. This checklist is a guide, not a gate.')}</p><button className="primary" onClick={startSession}><Play size={15}/>{t('Start focused session')}</button></div></section>}
          {!sessionStartedAt&&<button type="button" className="focus-advanced-toggle" aria-expanded={advancedSession||experienceMode==='advanced'} onClick={()=>{if(experienceMode==='advanced')setExperienceMode('guided');else setAdvancedSession(value=>!value);}}>{t(advancedSession||experienceMode==='advanced'?'Hide advanced settings':'Advanced settings')}<Plus size={14}/></button>}
          {!sessionStartedAt&&(advancedSession||experienceMode==='advanced')&&<section className="panel focus-plan" id="focus-plan"><div className="focus-v2-section-head"><div><span className="focus-kicker"><Flag size={15}/>{t('A PLAN YOU CAN FOLLOW')}</span><h2>{t('Session notes')}</h2></div></div><div className="focus-plan-editor"><label>{t('Avoid')}<input value={plan.avoid} onChange={(e)=>setPlan({...plan,avoid:e.target.value})}/></label><label>{t('Daily risk budget')}<input type="number" min={0} step={10} value={dailyRiskBudget} onChange={(e)=>setDailyRiskBudget(Number(e.target.value))}/></label><label className="wide">{t('Personal reminder')}<input value={plan.reminder} onChange={(e)=>setPlan({...plan,reminder:e.target.value})}/></label></div></section>}
          {tiltSignal&&<section className={`panel focus-tilt-shield ${tiltSignal?'has-signal':''}`}><div className="tilt-icon"><ShieldCheck size={21}/></div><div><span className="focus-kicker">{t('TILT SHIELD')}</span><h3>{t(tiltSignal?'Pause and review your limits':'Your guardrails are holding')}</h3><p>{tiltSignal?(lossesInRow>=2?t(`You have ${lossesInRow} losses in a row today. Consider stepping away before the next decision.`):riskEscalation?t('Your latest risk increased after a loss. Check your planned risk before the next trade.'):rapidTrading?t('Three trades were opened within 30 minutes. Step back and check whether each one matched your plan.'):revengeBehavior?t('Your check-in or trade notes mention revenge trading. Take a reset before deciding whether to continue.'):todayTrades.length>maxTrades?t('You have passed your planned trade count for today. Take a moment to reset.'):dailyRiskBudget>0&&riskUsed>=dailyRiskBudget*.8?t('Saved trade risk is close to your daily risk budget. Review the remaining exposure before continuing.'):t('Today’s P&L is approaching your saved daily loss limit.')):t('We’ll surface a gentle reminder if today’s saved trades approach your personal limits.')}</p><div className="tilt-metrics"><span>{todayTrades.length} {t('trades today')}</span><span>{lossesInRow} {t('losses in a row')}</span><span>{t('Loss limit')} {dailyLossLimit>0?dailyLossLimit.toFixed(0):t('Off')}</span></div></div>{tiltSignal&&<div className="tilt-actions"><button className="secondary" onClick={()=>{setResetRemaining(60);setResetRunning(true);setResetStep(0);}}><RotateCcw size={14}/>{t('Take a reset')}</button><button className="secondary" onClick={()=>setTab('check')}>{t('Review my plan')}</button><button className="inline-link" onClick={()=>setTab('session')}>{t('Continue')}</button></div>}</section>}
          {(resetRunning||resetRemaining===0)&&<section className="panel focus-reset"><div className="focus-reset-heading"><div><span className="focus-kicker"><RotateCcw size={15}/>{t('RESET YOUR ATTENTION')}</span><h3>{t('Take a 60-second reset')}</h3><p>{t('Step back before making the next decision.')}</p></div><strong className={resetRunning?'running':''}>{String(Math.floor(resetRemaining/60)).padStart(2,'0')}:{String(resetRemaining%60).padStart(2,'0')}</strong></div><div className="reset-progress"><i><b style={{width:`${((60-resetRemaining)/60)*100}%`}}/></i></div><div className="reset-steps">{['Look away from the chart','Review your maximum risk','Name the setup you are waiting for','Choose your next action'].map((step,index)=><div key={step} className={resetStep===index?'active':''}><span>{resetStep>index?<Check size={13}/>:String(index+1).padStart(2,'0')}</span>{t(step)}</div>)}</div><button className="focus-edit-button" onClick={()=>{if(resetRemaining===0){setResetRemaining(60);setTab('session');}else if(resetRunning){setResetRunning(false);}else{if(resetRemaining===60)setResetStep(0);setResetRunning(true);}}}>{t(resetRemaining===0?'Return to session':resetRunning?'Pause reset':resetRemaining===60?'Start 60-second reset':'Resume reset')}<ArrowUpRight size={14}/></button></section>}
        </div>}

        {tab === 'review' && <div className="focus-review-layout">
          <section className="panel focus-review-queue"><div className="focus-v2-section-head"><div><span className="focus-kicker"><ClipboardCheck size={15}/>{t('STEP 3 · TRADE REVIEW')}</span><h2>{t('Review the trade, not just the outcome.')}</h2><p>{t('A short review after each saved trade turns it into personal process data.')}</p></div><span className="checklist-count">{pendingReviewTrades.length}<small>{t('to review')}</small></span></div>
            {pendingReviewTrades.length?<><div className="focus-review-list">{(showAllReviewQueue?pendingReviewTrades:pendingReviewTrades.slice(0,4)).map(trade=><button key={trade.id} className="focus-review-item" onClick={()=>onOpenReview(trade)}><span className="focus-review-symbol">{trade.symbol.slice(0,3)}</span><span><strong>{trade.symbol} · {t(trade.side)}</strong><small>{trade.date} · {trade.entryTime} · {trade.session}</small></span><strong className={trade.pnl<0?'focus-risk-text':trade.pnl>0?'focus-positive-text':''}>{trade.pnl>0?'+':''}{trade.pnl.toFixed(2)}</strong><span className="focus-review-cta">{t('Review')}<ArrowUpRight size={14}/></span></button>)}</div>{pendingReviewTrades.length>4&&<button className="focus-edit-button" onClick={()=>setShowAllReviewQueue(value=>!value)}>{t(showAllReviewQueue?'Show fewer':'View all {v0} trades',{v0:pendingReviewTrades.length})}</button>}</>:<div className="focus-review-empty"><span><Check size={20}/></span><h3>{trades.length?t('You’re up to date on trade reviews.'):t('Your first trade review will appear here.')}</h3><p>{trades.length?t('Each completed review adds to your process insights, separately from P&L.'):t('Save a trade in your journal. Then record how closely you followed your plan.')}</p></div>}
          </section>
          <aside className="panel focus-review-next"><span className="focus-kicker"><ShieldCheck size={15}/>{t('WHAT HAPPENS NEXT')}</span><h3>{t('A review in under a minute')}</h3><ol><li>{t('Rate plan adherence')}</li><li>{t('Select any execution tags')}</li><li>{t('Save one short takeaway')}</li></ol><p>{t('We compare process quality separately from the financial result.')}</p><div className="focus-review-mini"><span>{t('Reviewed')}</span><strong>{reviewedTrades.length}</strong><small>{reviewCompletion??0}% {t('coverage')}</small></div><button className="secondary" onClick={()=>setTab('analytics')}>{t('See insights')}<ArrowUpRight size={14}/></button></aside>
        </div>}

        {tab === 'analytics' && <div className="focus-insights-layout">
          <section className="panel trader-boost"><div className="trader-boost-icon"><Sparkles size={21}/></div><div className="trader-boost-copy"><span>{t('A note for your process')} · {boost.label}</span><p>{boost.message}</p></div><ShieldCheck className="trader-boost-shield" size={22}/></section>
          <div className="inner-stat-grid trader-stat-grid"><section className="panel"><span>{t('Reviewed trades')}</span><strong>{reviewedTrades.length}</strong><small>{reviewCompletion===null?t('Add trades and reviews to begin'):t('{v0}% review coverage',{v0:reviewCompletion})}</small></section><section className="panel"><span>{t('Process quality')}</span><strong>{averageProcess===null?'—':`${averageProcess}%`}</strong><small>{t('separate from trade P&L')}</small></section><section className="panel"><span>{t('Plan adherence')}</span><strong>{adherenceRate===null?'—':`${adherenceRate}%`}</strong><small>{t('yes weighted; partial = half')}</small></section><section className="panel"><span>{t('Risk discipline')}</span><strong>{riskDiscipline===null?'—':`${riskDiscipline}%`}</strong><small>{t('risk and stop rules followed')}</small></section></div>
          <section className="panel process-dashboard"><div className="panel-head"><div><span className="focus-kicker"><ShieldCheck size={15}/>{t('DECISION QUALITY')}</span><h2>{t('Measure the process, not only the outcome')}</h2><p>{t('Scores are calculated only from reviews you have completed.')}</p></div><div className="process-ring" style={{'--process-score':`${averageProcess??0}%`} as CSSProperties}><strong>{averageProcess===null?'—':averageProcess}</strong><small>{averageProcess===null?'':t('/100')}</small></div></div><div className="process-metric-grid">{[[t('Execution quality'),averageProcess],[t('Plan adherence'),adherenceRate],[t('Risk discipline'),riskDiscipline],[t('Review completion'),reviewCompletion],...(showAllInsights?[[t('Emotional control'),emotionalControl],[t('Average execution score'),averageProcess]]:[])].map(([label,value],index)=><div className="process-metric" key={`${label}-${index}`}><span>{label}</span><strong>{value===null?'—':`${value}%`}</strong><i><b style={{width:`${Number(value??0)}%`}}/></i></div>)}</div></section>
          {showAllInsights&&<section className="panel focus-mindset-chart"><div className="panel-head"><div><span className="focus-kicker"><TrendingUp size={15}/>{t('PERSONAL DATA')}</span><h2>{t('How your mindset and trading overlap')}</h2><p>{t('Win rate and P&L are matched by date to your saved check-ins. No sample performance is shown.')}</p></div></div><div className="focus-chart-legend"><span><i className="legend-win"/>{t('Win rate')}</span><span><i className="legend-pnl"/>{t('P&L')}</span></div><div className="mood-performance-rows">{trackedMoodRows.map((item)=>{const MoodIcon=moods[item.value-1].icon; return <div className="mood-performance-row" key={item.value}><span><i className={`mood-mini-dot mood-dot-${item.sticker}`}><MoodIcon size={12}/></i>{t(item.title)}</span><div className="mood-performance-track"><i style={{width:`${Math.max(0,item.winRate??0)}%`}}/><small style={{left:`${Math.max(0,Math.min(96,item.winRate??0))}%`}}>{item.winRate===null?'—':`${item.winRate}%`}</small></div><strong className={item.pnl<0?'focus-risk-text':item.pnl>0?'focus-positive-text':''}>{item.trades?`${item.pnl>=0?'+':''}${item.pnl.toFixed(0)}`:'—'}</strong><small>{item.trades} {t('trades')}</small></div>; })}</div>{!report.entries&&<p className="statistics-empty">{t('Save check-ins and trades on matching dates to reveal your personal patterns.')}</p>}</section>}
          <section className="panel focus-weekly-report"><div><span className="focus-kicker"><Activity size={15}/>{t('LAST 7 DAYS')}</span><h2>{t('Your process, in review')}</h2><p>{t(weeklyReviews.length?'Your reviewed trades reveal where your process is holding and where it needs attention.':'Your weekly report will fill in as you review completed trades.')}</p></div><div className="weekly-report-stats"><div><small>{t('Reviewed trades')}</small><strong>{weeklyReviews.length}</strong></div><div><small>{t('Average process')}</small><strong>{weeklyProcess===null?'—':`${weeklyProcess}%`}</strong></div><div><small>{t('Vs previous week')}</small><strong>{processChange===null?'—':`${processChange>0?'+':''}${processChange} pts`}</strong></div><div><small>{t('Plan followed')}</small><strong>{weeklyPlanFollowed}</strong></div><div><small>{t('Impulsive trades')}</small><strong>{weeklyImpulsive}</strong></div><div><small>{t('Best process mindset')}</small><strong>{weeklyBestProcessMindset?t(mindsetLabels[weeklyBestProcessMindset.id]):'—'}</strong></div><div><small>{t('Most common mistake')}</small><strong>{weeklyTopMistake?t(mistakeLabels[weeklyTopMistake[0]]??weeklyTopMistake[0]):'—'}</strong></div><div><small>{t('Best process session')}</small><strong>{weeklySessionQuality[0]?t(weeklySessionQuality[0].name):'—'}</strong></div></div><div className="weekly-process-note"><ShieldCheck size={17}/><span>{processChange===null?t(weeklyReviews.length?'Keep repeating the rule you followed most consistently. A week-over-week comparison appears after enough reviews.':'Review your next trade to begin a process-based weekly report.'):t(processChange>0?'Your average process score improved by {v0} points versus the previous week.':'Your average process score changed by {v0} points versus the previous week.',{v0:Math.abs(processChange)})}</span></div></section>
          <section className="panel personal-process-insights"><div className="panel-head"><div><span className="focus-kicker"><Sparkles size={15}/>{t('PERSONAL PATTERNS')}</span><h2>{t('Insights from your reviewed trades')}</h2><p>{t('Only patterns with enough reviewed trades are shown.')}</p></div></div><div className="process-insight-grid">{readinessInsight!==null&&<article><strong>{t('Readiness pattern')}</strong><p>{t('Your process score is {v0} points {v1} when readiness is at least 75.',{v0:Math.abs(readinessInsight),v1:readinessInsight>=0?'higher':'lower'})}</p></article>}{lossPressureInsight!==null&&<article><strong>{t('After consecutive losses')}</strong><p>{t('Your process score is {v0} points {v1} after at least two losses in a row.',{v0:Math.abs(lossPressureInsight),v1:lossPressureInsight>=0?'higher':'lower'})}</p></article>}{bestProcessMindset&&<article><strong>{t('Best process mindset')}</strong><p>{t('Your average process score is {v0}% when you marked yourself {v1}.',{v0:bestProcessMindset.score,v1:t(mindsetLabels[bestProcessMindset.id])})}</p></article>}<article className="process-recommendation"><strong>{t('Next recommended focus')}</strong><p>{topMistake?t('Use the 60-second reset before the next setup, then check for: {v0}.',{v0:t(mistakeLabels[topMistake[0]]??topMistake[0])}):t('Keep your risk steady and review your next completed trade.')}</p></article></div>{showAllInsights&&<div className="process-insight-grid process-insight-extra">{sessionQuality[0]&&<article><strong>{t('Strongest session')}</strong><p>{t('Your best average process score is during {v0} ({v1}%).',{v0:sessionQuality[0].name,v1:sessionQuality[0].score})}</p></article>}{topMistake&&<article><strong>{t('Most common performance leak')}</strong><p>{t('{v0} appeared {v1} times in your trade reviews.',{v0:t(mistakeLabels[topMistake[0]]??topMistake[0]),v1:topMistake[1]})}</p></article>}</div>}<button type="button" className="focus-edit-button insights-toggle" aria-expanded={showAllInsights} onClick={()=>setShowAllInsights(value=>!value)}>{t(showAllInsights?'Show fewer insights':'View all insights')}<ArrowUpRight size={14}/></button>{reviewedTrades.length<2&&<p className="statistics-empty">{t('Complete a few post-trade reviews to unlock reliable personal patterns.')}</p>}</section>
          {showAllInsights&&<><section className="panel inner-insights trader-patterns"><div className="panel-head"><div><h2>{t('Mindset patterns')}</h2><p>{t('How often each mindset appeared in your saved check-ins.')}</p></div><TrendingUp size={19}/></div>{report.mindsets.length?<div className="mindset-bars">{report.mindsets.map((item)=><div key={item.id}><span><i className={`mindset-dot mindset-dot-${item.id}`}/>{t(mindsetLabels[item.id])}</span><i className="mindset-bar-track"><b style={{width:`${(item.count/report.entries)*100}%`}}/></i><strong>{item.count}<small>/{report.entries}</small></strong></div>)}</div>:<p className="statistics-empty">{t('Save your first check-in to begin seeing patterns.')}</p>}</section>
          <section className="panel trader-history"><div className="panel-head"><div><h2>{t('Check-in history')}</h2><p>{t('Your saved mindset snapshots.')}</p></div></div><div className="inner-history">{entries.filter((entry)=>entry.date<=today).map((entry)=>{const MoodIcon=entry.mood?moods[entry.mood-1].icon:null; return <button key={entry.date} onClick={()=>{selectDate(entry.date);setTab('check');}}><strong>{entry.date}</strong><span className="history-mood-icon">{MoodIcon?<MoodIcon size={18}/>:<span>—</span>}</span><small>{entry.mindset.map((id)=>t(mindsetLabels[id])).join(' · ')||t('No mindset selected')}</small></button>;})}</div>{!report.entries&&<p className="statistics-empty">{t('Save your first check-in to begin seeing patterns.')}</p>}</section></>}
        </div>}
      </>}
    </div>
  );
}
