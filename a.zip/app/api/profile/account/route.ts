import {getJournalDb,getScreenshotsBucket} from '@/db';
import {body,failure,json} from '@/lib/journal-server';
import {profileIdentity,readProfile,profileKey} from '@/lib/profile-server';
import {currentMember} from '@/lib/member-server';
import {SESSION_COOKIE} from '@/lib/membership';
import {z} from 'zod';

export async function DELETE(request:Request){
 try{
  const identity=await profileIdentity(request),value=z.object({confirmation:z.string().trim().min(2).max(80),revision:z.string().max(128).nullable()}).parse(await body(request));
  const saved=await readProfile(identity.owner),name=saved.data?.name??identity.name;
  if(value.revision!==saved.revision)return json({error:'Profile changed in another window. Reload and try again.'},409);
  if(value.confirmation!==name)return json({error:'Enter your account name exactly to confirm deletion.'},400);
  const db=getJournalDb(),bucket=getScreenshotsBucket(),member=await currentMember();
  const shots=await db.prepare('SELECT object_key FROM screenshots WHERE owner_id = ?').bind(identity.owner).all<{object_key:string}>();
  const objects=[...shots.results.map(item=>item.object_key)];
  if(saved.data?.photoKey)objects.push(saved.data.photoKey);
  const statements=[
   'DELETE FROM screenshots WHERE owner_id = ?','DELETE FROM trades WHERE owner_id = ?','DELETE FROM daily_notes WHERE owner_id = ?',
   'DELETE FROM trading_accounts WHERE owner_id = ?','DELETE FROM trading_strategies WHERE owner_id = ?','DELETE FROM achievement_awards WHERE owner_id = ?',
   'DELETE FROM inner_space_entries WHERE owner_id = ?','DELETE FROM decisions WHERE owner_id = ?','DELETE FROM journal_settings WHERE owner_id = ?'
  ].map(sql=>db.prepare(sql).bind(identity.owner));
  if(member)statements.push(
   db.prepare('DELETE FROM member_sessions WHERE member_id = ?').bind(member.id),
   db.prepare('DELETE FROM password_reset_tokens WHERE member_id = ?').bind(member.id),
   db.prepare('DELETE FROM billing_events WHERE member_id = ?').bind(member.id),
   db.prepare('DELETE FROM subscriptions WHERE member_id = ?').bind(member.id),
   db.prepare('DELETE FROM members WHERE id = ?').bind(member.id)
  );
  await db.batch(statements);
  if(objects.length)for(let offset=0;offset<objects.length;offset+=1000)try{await bucket.delete(objects.slice(offset,offset+1000));}catch(error){console.error('Account object cleanup failed',error);}
  try{await bucket.delete(profileKey(identity.owner));}catch(error){console.error('Profile object cleanup failed',error);}
  const response=json({ok:true});
  if(member)response.headers.set('Set-Cookie',`${SESSION_COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`);
  return response;
 }catch(error){return failure(error);}
}

