import {GET as calendar} from '../route';
import {calendarCSV} from '@/lib/calendar-weeks';
import type {EconomicEvent} from '@/lib/economic-news';
export async function GET(request:Request){const response=await calendar(request);if(!response.ok)return response;const data=await response.json() as {events:EconomicEvent[]};return new Response(calendarCSV(data.events),{headers:{'Content-Type':'text/csv; charset=utf-8','Content-Disposition':'attachment; filename="forex_factory_history.csv"','Cache-Control':'no-store'}});}
