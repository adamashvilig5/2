import {currentCalendar,savedCalendar,type Cached} from '@/lib/calendar-source';
import {groupEconomicWeeks} from '@/lib/calendar-weeks';
import {todayIn} from '@/lib/trading';
// Shared public-feed updater. The owner-private Sites dispatch authorizes both
// signed-in owner requests and service requests; this endpoint has no user data,
// takes no source URLs, and never accesses journals, accounts or connected apps.
function response(data:Cached|null){return Response.json({source:data?.source??'Forex Factory',count:data?.events.length??0,fetchedAt:data?.fetchedAt??null,coverage:data?.coverage??null,stale:!data||!!data.failed,weeks:groupEconomicWeeks(data?.events??[],'America/New_York',todayIn('America/New_York')).map(w=>({start:w.start,end:w.end,kind:w.kind,count:w.events.length}))},{status:data?.events.length&&!data.failed?200:503,headers:{'Cache-Control':'no-store'}});}
export async function POST(){return response(await currentCalendar());}
export async function GET(){return response(await savedCalendar());}
