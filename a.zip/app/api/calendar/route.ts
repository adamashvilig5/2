import {groupEconomicWeeks} from '@/lib/calendar-weeks';
import {getScreenshotsBucket} from '@/db';
import {auth,json,failure} from '@/lib/journal-server';
import {currentCalendar} from '@/lib/calendar-source';
import {calendarQuery,archiveWeeks,filterCalendar,missingDates} from '@/lib/calendar-query';
import {economicWeek,type EconomicEvent} from '@/lib/economic-news';
import {todayIn,shiftDate} from '@/lib/trading';
export async function GET(request:Request){try{await auth();const today=todayIn('America/New_York');
 // Validate user input before external requests or storage work.
 try{calendarQuery(request.url,{start:shiftDate(today,-6),end:today});}catch(e){return json({error:e instanceof Error?e.message:'Invalid calendar query.'},400);}
 const current=await currentCalendar(),fallback=current?.coverage??(current?.events.length?economicWeek(current.events):{start:today,end:today});let query;
 try{query=calendarQuery(request.url,fallback);}catch{return json({error:'Invalid calendar query.'},400);}
 const bucket=getScreenshotsBucket(),keys=archiveWeeks(query.from,query.to),snapshots=await Promise.all(keys.map(async key=>{const object=await bucket.get(`public-feed-cache/calendar-weeks/${key}.json`);return object?await object.json<{events:EconomicEvent[];fetchedAt:string;coverage:{start:string;end:string}} >():null;}));
 const saved=snapshots.filter((v):v is NonNullable<typeof v>=>!!v),unique=new Map<string,EconomicEvent>();for(const snapshot of saved)for(const event of snapshot.events)unique.set(event.id,{...event,fetchedAt:snapshot.fetchedAt});
 const events=filterCalendar([...unique.values()],query).sort((a,b)=>Date.parse(a.date)-Date.parse(b.date)),periods=saved.map(s=>({...s.coverage,updatedAt:s.fetchedAt})).sort((a,b)=>a.start.localeCompare(b.start));
 const missing=missingDates(query.from,query.to,periods),latest=periods.map(p=>p.updatedAt).sort().at(-1)??null;
 if(!saved.length&&(!current?.events.length))return json({error:'Calendar source is unavailable and this period has not been archived.',events:[],query,missingDates:missing,sourceUrl:'https://www.forexfactory.com/calendar'},503);
 const source=current?.source??'Forex Factory';return json({events,weeks:groupEconomicWeeks(events,query.timezone,todayIn(query.timezone)),query,total:events.length,updatedAt:latest??current?.fetchedAt??null,stale:!!current?.failed,coverage:fallback,coveragePeriods:periods,missingDates:missing,partial:missing.length>0,source,schemaVersion:current?.schemaVersion??null,sourceUrl:source==='Finance Calendar'?'https://www.financecalendar.com':'https://www.forexfactory.com/calendar',archiveStarted:periods[0]?.start??null,refreshPolicy:source==='Forex Factory (manual)'?'Calendar copied from Forex Factory and refreshed manually each month.':'Calendar refreshes automatically when its source is available.'});
}catch(e){return failure(e);}}
