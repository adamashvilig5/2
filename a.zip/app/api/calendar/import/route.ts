import {auth,json,failure} from '@/lib/journal-server';
import {storeMonthlyCalendar} from '@/lib/calendar-source';
import {economicDay,parseMonthlyEconomicEvents} from '@/lib/economic-news';
import {dateSchema,shiftDate,todayIn} from '@/lib/trading';

export async function POST(request:Request){try{
 await auth();const text=await request.text();if(text.length>1_000_000)return json({error:'Calendar import is too large.'},413);
 const body=JSON.parse(text) as {from?:unknown;to?:unknown;events?:unknown};const today=todayIn('America/New_York');
 const from=dateSchema.parse(body.from),to=dateSchema.parse(body.to);if(from>to||from<shiftDate(today,-7)||to>shiftDate(today,31)||Date.parse(to)-Date.parse(from)>35*86400000)return json({error:'Calendar import must cover no more than the next month.'},400);
 const events=parseMonthlyEconomicEvents(body.events);if(events.some(event=>{const day=economicDay(event,'America/New_York');return day<from||day>to;}))return json({error:'Calendar event lies outside the requested period.'},400);
 const saved=await storeMonthlyCalendar(events,from,to);return json({count:saved.events.length,coverage:saved.coverage,fetchedAt:saved.fetchedAt,source:saved.source});
}catch(e){return failure(e);}}
