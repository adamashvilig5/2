import { getJournalDb } from '@/db';
import { auth,json,failure,fromRow,type TradeRow } from '@/lib/journal-server';
import { dailySchema, rulesDefault } from '@/lib/trading';
export const dynamic='force-dynamic';
export async function GET(request:Request){try{
 const owner=await auth(),db=getJournalDb(),date=dailySchema.shape.date.parse(new URL(request.url).searchParams.get('date'));
 const [trades,shots,settings,daily,accounts,strategies]=await Promise.all([
 db.prepare('SELECT id, data_json, revision, created_at, updated_at FROM trades WHERE owner_id = ? ORDER BY trade_date DESC, created_at DESC').bind(owner).all<TradeRow>(),
 db.prepare('SELECT id, trade_id, phase, filename FROM screenshots WHERE owner_id = ? ORDER BY rowid').bind(owner).all<{id:string;trade_id:string;phase:'before'|'after'|'context';filename:string}>(),
 db.prepare('SELECT data_json, revision FROM journal_settings WHERE owner_id = ?').bind(owner).first<{data_json:string;revision:number}>(),
 db.prepare('SELECT data_json, revision FROM daily_notes WHERE owner_id = ? AND date = ?').bind(owner,date).first<{data_json:string;revision:number}>(),
 db.prepare('SELECT id, data_json, revision, archived FROM trading_accounts WHERE owner_id = ? ORDER BY created_at').bind(owner).all<{id:string;data_json:string;revision:number;archived:number}>(),
 db.prepare('SELECT data_json, revision FROM trading_strategies WHERE owner_id = ? AND archived = 0 ORDER BY created_at').bind(owner).all<{data_json:string;revision:number}>()
 ]);
 const archivedAccounts=accounts.results.filter(a=>a.archived===1||a.archived===2).map(a=>({...JSON.parse(a.data_json),revision:a.revision}));
 const savedAccounts=accounts.results.filter(a=>!a.archived).map(a=>({...JSON.parse(a.data_json),revision:a.revision}));
 const defaultAccount=savedAccounts.find(a=>a.id==='default')??(accounts.results.some(a=>a.id==='default')?null:{id:'default',revision:0,name:'მთავარი ანგარიში',type:'Demo',currency:'USD',startingBalance:settings?JSON.parse(settings.data_json).startingBalance:null,description:''});
 return json({archivedAccounts,accounts:[...(defaultAccount?[defaultAccount]:[]),...savedAccounts.filter(a=>a.id!=='default')],strategies:strategies.results.map(s=>({...JSON.parse(s.data_json),revision:s.revision})),trades:trades.results.map(t=>fromRow(t,shots.results.filter(s=>s.trade_id===t.id).map(s=>({id:s.id,phase:s.phase,filename:s.filename})))),settings:settings?{...JSON.parse(settings.data_json),revision:settings.revision}:{startingBalance:null,timezone:'America/New_York',revision:0},daily:daily?{...JSON.parse(daily.data_json),revision:daily.revision}:{date,note:'',rules:rulesDefault,revision:0}});
}catch(e){return failure(e);}}
