import { getJournalDb } from '@/db';
import { auth,body,failure,json } from '@/lib/journal-server';
import { innerSpaceSchema } from '@/lib/inner-space';
export async function GET(){try{const owner=await auth(),rows=await getJournalDb().prepare('SELECT data_json, revision FROM inner_space_entries WHERE owner_id = ? ORDER BY date DESC').bind(owner).all<{data_json:string;revision:number}>();return json({entries:rows.results.map(row=>({...JSON.parse(row.data_json),revision:row.revision}))});}catch(e){return failure(e);}}
export async function PUT(request:Request){try{const owner=await auth(request),entry=innerSpaceSchema.parse(await body(request)),db=getJournalDb();
 const result=entry.revision===0?await db.prepare('INSERT INTO inner_space_entries (owner_id, date, data_json, revision) VALUES (?, ?, ?, 1) ON CONFLICT(owner_id, date) DO NOTHING').bind(owner,entry.date,JSON.stringify(entry)).run():await db.prepare('UPDATE inner_space_entries SET data_json = ?, revision = revision + 1 WHERE owner_id = ? AND date = ? AND revision = ?').bind(JSON.stringify(entry),owner,entry.date,entry.revision).run();
 if(!result.meta.changes)return json({error:'Trader Focus changed in another window. Reload your check-ins.'},409);return json({entry:{...entry,revision:entry.revision+1}});
}catch(e){return failure(e);}}
