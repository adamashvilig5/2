import {z} from 'zod';
import {headers} from 'next/headers';
import {getChatGPTUser} from '@/app/chatgpt-auth';
import {getJournalDb} from '@/db';
import {body,failure} from '@/lib/journal-server';
import {gate,currentMember,subscriptionFor,getPlan,sessionCookie,passwordHash,passwordMatches,digest,reply,limitAttempts,hasMemberCookie} from '@/lib/member-server';
import {SITE_OWNER_ID,SESSION_COOKIE,hasAccess,nextMonth,type Member} from '@/lib/membership';
const credentials=z.object({email:z.string().trim().email().max(254).transform(s=>s.toLowerCase()),password:z.string().min(12).max(128)});
export async function GET(request:Request){try{const chatUser=await getChatGPTUser(),member=await currentMember(),viewer=member?{name:member.name,email:member.email}:chatUser?{name:chatUser.displayName,email:chatUser.email}:undefined,subscription=member?await subscriptionFor(member.id):null,events=member?await getJournalDb().prepare('SELECT id,kind,amount_cents,created_at FROM billing_events WHERE member_id = ? ORDER BY created_at DESC LIMIT 30').bind(member.id).all():{results:[]},local=['localhost','127.0.0.1'].includes(new URL(request.url).hostname);const response=reply({member,viewer,subscription,events:events.results,plan:await getPlan(),admin:chatUser?.userId===SITE_OWNER_ID&&!member,access:member?hasAccess(member,subscription):chatUser?.userId===SITE_OWNER_ID,mode:local?'local-test':'unconfigured'});if(!member&&await hasMemberCookie())response.headers.set('Set-Cookie',`${SESSION_COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`);return response;}catch(e){return failure(e);}}
export async function POST(request:Request){try{
 const origin=request.headers.get('origin');if(origin&&origin!==new URL(request.url).origin)return reply({error:'Invalid request origin.'},403);const data=await body(request) as Record<string,unknown>,action=z.enum(['register','login','logout','select_plan','pay','fail','cancel','resume','password']).parse(data.action),db=getJournalDb(),user=action==='register'||action==='login'?null:await gate(request);
 if(action==='logout'){const cookie=(await headers()).get('cookie')??'',token=cookie.split(';').map(s=>s.trim()).find(s=>s.startsWith(SESSION_COOKIE+'='))?.slice(SESSION_COOKIE.length+1);if(token)await db.prepare('DELETE FROM member_sessions WHERE token_hash = ?').bind(await digest(token)).run();const response=reply({ok:true});response.headers.set('Set-Cookie',`${SESSION_COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`);return response;}
 if(action==='register'||action==='login'){
  const input=credentials.parse(data);await limitAttempts(request,`email:${input.email}`);let member:Member|null=null;
  if(action==='register'){
   const name=z.string().trim().min(2).max(80).parse(data.name),id=crypto.randomUUID(),created=new Date().toISOString(),hash=await passwordHash(input.password);
   const result=await db.prepare('INSERT INTO members (id,email,name,password_hash,created_at) VALUES (?, ?, ?, ?, ?) ON CONFLICT(email) DO NOTHING').bind(id,input.email,name,hash,created).run();
   if(!result.meta.changes)return reply({error:'This email is already registered. Sign in instead.'},409);member={id,email:input.email,name,created_at:created,suspended:0};
  }else{
   const row=await db.prepare('SELECT * FROM members WHERE email = ?').bind(input.email).first<Member&{password_hash:string}>();const valid=await passwordMatches(input.password,row?.password_hash??'missing:0000000000000000000000000000000000000000000000000000000000000000');if(!row||!valid)return reply({error:'Incorrect email or password.'},401);member=row;
  }
  const response=reply({ok:true});response.headers.set('Set-Cookie',await sessionCookie(member.id,member.id));return response;
 }
 if((action==='pay'||action==='fail')&&!['localhost','127.0.0.1'].includes(new URL(request.url).hostname))return reply({error:'Payment provider is not connected.'},503);
 const member=await currentMember();if(!member)return reply({error:'Sign in to manage your membership.'},401);
 if(action==='select_plan'){
  const choice=z.enum(['demo','pro']).parse(data.plan),existing=await subscriptionFor(member.id);
  if(existing&&choice==='demo')return reply({error:'Your account plan has already been selected. Demo cannot be restarted.'},409);
  if(existing&&existing.status!=='inactive')return reply({error:'Your current plan cannot be replaced here.'},409);
  const plan=await getPlan(),isDemo=choice==='demo',end=isDemo?'9999-12-31T23:59:59.999Z':new Date().toISOString();
  const selected=await db.prepare("INSERT INTO subscriptions (member_id,status,period_end,cancel_at_end,price_cents,revision) VALUES (?, ?, ?, 0, ?, 1) ON CONFLICT(member_id) DO NOTHING").bind(member.id,isDemo?'demo':'inactive',end,isDemo?0:plan.price_cents).run();
  if(!selected.meta.changes)return reply({error:'Your account plan was selected in another request. Refresh and sign in again.'},409);
  return reply({ok:true});
 }
 if(action==='password'){
  await limitAttempts(request,user?.userId??member.id);const old=z.string().min(1).max(128).parse(data.currentPassword),next=z.string().min(12).max(128).parse(data.password),row=await db.prepare('SELECT password_hash FROM members WHERE id = ?').bind(member.id).first<{password_hash:string}>();if(!row||!await passwordMatches(old,row.password_hash))return reply({error:'Incorrect current password.'},400);
  await db.batch([db.prepare('UPDATE members SET password_hash = ? WHERE id = ?').bind(await passwordHash(next),member.id),db.prepare('DELETE FROM member_sessions WHERE member_id = ?').bind(member.id)]);const response=reply({ok:true});response.headers.set('Set-Cookie',await sessionCookie(member.id,member.id));return response;
 }
 if(member.suspended)return reply({error:'This test account is suspended. Contact the administrator.'},403);
 const subscription=await subscriptionFor(member.id);if(!subscription)return reply({error:'Subscription unavailable.'},409);
 if(action==='pay'||action==='fail'){const requestId=z.string().uuid().parse(data.requestId),existing=await db.prepare('SELECT id FROM billing_events WHERE id = ? AND member_id = ?').bind(requestId,member.id).first();if(existing)return reply({ok:true});}
 const revision=z.number().int().positive().parse(data.revision);if(revision!==subscription.revision)return reply({error:'Membership changed in another window. Refresh and try again.'},409);
 if(action==='cancel'||action==='resume'){
  const result=await db.prepare('UPDATE subscriptions SET cancel_at_end = ?, revision = revision + 1 WHERE member_id = ? AND revision = ?').bind(action==='cancel'?1:0,member.id,revision).run();if(!result.meta.changes)return reply({error:'Membership changed in another window. Refresh and try again.'},409);return reply({ok:true});
 }
 const id=z.string().uuid().parse(data.requestId);
 if(action==='fail'){await db.prepare("INSERT INTO billing_events (id,member_id,kind,amount_cents,created_at) VALUES (?, ?,'test_failed',0,?)").bind(id,member.id,new Date().toISOString()).run();return reply({ok:true});}
 // Sandbox only: a verified bank callback must replace this action before real billing is enabled.
 if(subscription.status==='active'&&hasAccess(member,subscription))return reply({error:'Your paid test period is still active.'},409);
 const plan=await getPlan(),created=new Date().toISOString(),results=await db.batch([
  db.prepare("INSERT INTO billing_events (id,member_id,kind,amount_cents,created_at) SELECT ?,member_id,'test_paid',?,? FROM subscriptions WHERE member_id = ? AND revision = ?").bind(id,plan.price_cents,created,member.id,revision),
  db.prepare("UPDATE subscriptions SET status = 'active',period_end = ?,cancel_at_end = 0,price_cents = ?,revision = revision + 1 WHERE member_id = ? AND revision = ? AND EXISTS (SELECT 1 FROM billing_events WHERE id = ? AND member_id = ?)").bind(nextMonth(),plan.price_cents,member.id,revision,id,member.id)
 ]);if(!results[0].meta.changes||!results[1].meta.changes)return reply({error:'Membership changed in another window. Refresh and try again.'},409);return reply({ok:true});
}catch(e){return failure(e);}}
