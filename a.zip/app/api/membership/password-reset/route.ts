import {env} from 'cloudflare:workers';
import {z} from 'zod';
import {getJournalDb} from '@/db';
import {body,json,failure} from '@/lib/journal-server';
import {digest,limitAttempts,passwordHash,reply} from '@/lib/member-server';

type MailEnv={RESEND_API_KEY?:string;AUTH_FROM_EMAIL?:string;PUBLIC_APP_URL?:string};
const mailEnv=env as unknown as MailEnv;
const requestSchema=z.object({action:z.literal('request'),email:z.string().trim().email().max(254).transform(value=>value.toLowerCase())});
const confirmSchema=z.object({action:z.literal('confirm'),token:z.string().min(32).max(256),password:z.string().min(12).max(128)});

export async function POST(request:Request){try{
 const origin=request.headers.get('origin');if(origin&&origin!==new URL(request.url).origin)return reply({error:'Invalid request origin.'},403);
 const input=await body(request) as Record<string,unknown>;
 if(input.action==='request'){
  const {email}=requestSchema.parse(input);await limitAttempts(request,`reset:${email}`);
  const db=getJournalDb(),member=await db.prepare('SELECT id FROM members WHERE email = ?').bind(email).first<{id:string}>();let debugLink:string|undefined;
  if(member){
   const token=crypto.randomUUID()+crypto.randomUUID(),tokenHash=await digest(token),createdAt=new Date().toISOString(),expiresAt=new Date(Date.now()+60*60*1000).toISOString();
   await db.batch([db.prepare('DELETE FROM password_reset_tokens WHERE member_id = ?').bind(member.id),db.prepare('INSERT INTO password_reset_tokens (token_hash,member_id,expires_at,created_at) VALUES (?, ?, ?, ?)').bind(tokenHash,member.id,expiresAt,createdAt)]);
   const base=(mailEnv.PUBLIC_APP_URL??new URL(request.url).origin).replace(/\/$/,'');debugLink=`${base}/membership?mode=reset&token=${encodeURIComponent(token)}`;
   if(mailEnv.RESEND_API_KEY){
    const response=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${mailEnv.RESEND_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({from:mailEnv.AUTH_FROM_EMAIL??'Trade Journal <onboarding@resend.dev>',to:[email],subject:'Reset your Trade Journal password',html:`<div style="font-family:Arial,sans-serif;max-width:520px;margin:40px auto;color:#192330"><h1 style="font-size:24px">Reset your password</h1><p>Use the secure link below to choose a new Trade Journal password. This link expires in one hour and can only be used once.</p><p style="margin:28px 0"><a href="${debugLink}" style="background:#172b3d;color:#fff;text-decoration:none;padding:13px 18px;border-radius:7px">Choose a new password</a></p><p>If you did not request this change, you can ignore this email.</p></div>`})});
    if(!response.ok)console.error('Password reset email delivery failed',response.status);
   }
  }
  const local=['localhost','127.0.0.1'].includes(new URL(request.url).hostname);
  return json({ok:true,deliveryConfigured:!!mailEnv.RESEND_API_KEY,...(local&&debugLink?{debugLink}:{})});
 }
 const {token,password}=confirmSchema.parse(input),db=getJournalDb(),now=new Date().toISOString(),tokenHash=await digest(token),claimed=await db.prepare('DELETE FROM password_reset_tokens WHERE token_hash = ? AND expires_at > ? RETURNING member_id').bind(tokenHash,now).first<{member_id:string}>();
 if(!claimed)return reply({error:'This password reset link has expired or was already used. Request a new link.'},400);
 const hash=await passwordHash(password);
 await db.batch([db.prepare('UPDATE members SET password_hash = ? WHERE id = ?').bind(hash,claimed.member_id),db.prepare('DELETE FROM member_sessions WHERE member_id = ?').bind(claimed.member_id),db.prepare('DELETE FROM password_reset_tokens WHERE member_id = ?').bind(claimed.member_id)]);
 return json({ok:true});
}catch(error){return failure(error);}}
