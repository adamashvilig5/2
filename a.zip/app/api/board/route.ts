import {auth} from '@/lib/journal-server';
import { getDecisionDb } from '@/db';
import { parseBoard, boardProblem, scoreOption, type SavedChoice } from '@/lib/decision';
export const dynamic = 'force-dynamic';
const json = (value: unknown, status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store'}});
export async function GET() {
 let user;try{user={userId:await auth()};}catch(e){if(e instanceof Response)return e;throw e;}
 try {
  const row=await getDecisionDb().prepare('SELECT board_json, choice_json, revision FROM decisions WHERE owner_id = ?').bind(user.userId).first<{board_json:string;choice_json:string|null;revision:number}>();
  return json(row?{board:JSON.parse(row.board_json),choice:row.choice_json?JSON.parse(row.choice_json):null,revision:row.revision}:{board:null,choice:null,revision:0});
 } catch(e) {console.error('Board load failed',e);return json({error:'Your board could not be loaded. Please try again.'},503);}
}
export async function PUT(request: Request) {
 let user;try{user={userId:await auth(request)};}catch(e){if(e instanceof Response)return e;throw e;}
 const origin=request.headers.get('origin'); if(origin && origin!==new URL(request.url).origin) return json({error:'Invalid request origin.'},403);
 let payload: {board:unknown;revision:number;preferredOptionId?:string;rationale?:string};
 try {
  if(Number(request.headers.get('content-length')??0)>100000) return json({error:'Board is too large.'},413);
  const raw=await request.text(); if(raw.length>100000) return json({error:'Board is too large.'},413);
  payload=JSON.parse(raw);
  if(!Number.isSafeInteger(payload.revision)||payload.revision<0) throw new Error('Invalid revision');
  const board=parseBoard(payload.board);
  let choice:SavedChoice|null=null;
  if(payload.preferredOptionId!==undefined) {
   const problem=boardProblem(board); if(problem) return json({error:problem},400);
   const option=board.options.find(o=>o.id===payload.preferredOptionId); if(!option) return json({error:'Choose a valid option.'},400);
   if(typeof payload.rationale!=='string'||payload.rationale.length>4000) return json({error:'Rationale must be under 4,000 characters.'},400);
   choice={optionId:option.id,optionName:option.name.trim(),rationale:payload.rationale.trim(),score:scoreOption(board,option)!,savedAt:new Date().toISOString(),snapshot:board};
  }
  const db=getDecisionDb();
  const now=new Date().toISOString();
  let result;
  if(payload.revision===0) {
   result=await db.prepare('INSERT INTO decisions (owner_id, board_json, choice_json, revision, updated_at) VALUES (?, ?, ?, 1, ?) ON CONFLICT(owner_id) DO NOTHING').bind(user.userId,JSON.stringify(board),choice?JSON.stringify(choice):null,now).run();
  } else if(choice) {
   result=await db.prepare('UPDATE decisions SET board_json = ?, choice_json = ?, revision = revision + 1, updated_at = ? WHERE owner_id = ? AND revision = ?').bind(JSON.stringify(board),JSON.stringify(choice),now,user.userId,payload.revision).run();
  } else {
   result=await db.prepare('UPDATE decisions SET board_json = ?, revision = revision + 1, updated_at = ? WHERE owner_id = ? AND revision = ?').bind(JSON.stringify(board),now,user.userId,payload.revision).run();
  }
  if(!result.meta.changes) return json({error:'This board changed in another tab. Reload before saving again.'},409);
  return json({revision:payload.revision+1,...(choice?{choice}:{})});
 } catch(e) {
  if(e instanceof SyntaxError || (e instanceof Error && (e.name==='ZodError'||e.message==='Duplicate IDs'||e.message==='Unknown criterion'||e.message==='Invalid revision'))) return json({error:'Check the board values and try again.'},400);
  console.error('Board save failed',e); return json({error:'Your changes could not be saved. Your input is still here; try again.'},503);
 }
}
