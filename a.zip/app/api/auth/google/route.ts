import {env} from 'cloudflare:workers';
import {getJournalDb} from '@/db';
import {hasAccess,type Member} from '@/lib/membership';
import {limitAttempts,passwordHash,sessionCookie,subscriptionFor} from '@/lib/member-server';

type GoogleEnvironment={GOOGLE_CLIENT_ID?:string;GOOGLE_CLIENT_SECRET?:string;GOOGLE_REDIRECT_URI?:string;PUBLIC_APP_URL?:string};
const config=env as unknown as GoogleEnvironment;
const STATE_COOKIE='journal_google_oauth';

function randomToken(size=32){const bytes=crypto.getRandomValues(new Uint8Array(size));return btoa(String.fromCharCode(...bytes)).replaceAll('+','-').replaceAll('/','_').replaceAll('=','');}
function base64url(bytes:Uint8Array){return btoa(String.fromCharCode(...bytes)).replaceAll('+','-').replaceAll('/','_').replaceAll('=','');}
function appBase(request:Request){if(config.PUBLIC_APP_URL)return new URL(config.PUBLIC_APP_URL).origin;if(config.GOOGLE_REDIRECT_URI)return new URL(config.GOOGLE_REDIRECT_URI).origin;const url=new URL(request.url);return ['localhost','127.0.0.1'].includes(url.hostname)?url.origin:null;}
function popupResponse(request:Request,payloadData:Record<string,string>){
 const targetOrigin=appBase(request)??new URL(request.url).origin,flowId=new URL(request.url).searchParams.get('flow')??'',message=JSON.stringify({type:'journal:google-auth',...payloadData,flowId}).replaceAll('<','\\u003c'),key=JSON.stringify(`trade-journal:google:${flowId}`);
 return new Response(`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Trade Journal</title></head><body><p>Returning to Trade Journal…</p><script>const result=${message};try{localStorage.setItem(${key},JSON.stringify(result))}catch{}if(window.opener){window.opener.postMessage(result,${JSON.stringify(targetOrigin)});window.close()}setTimeout(()=>{document.body.textContent='You can close this window and continue with email and password.'},400)</script></body></html>`,{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','Content-Security-Policy':"default-src 'none'; script-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'"}});
}
async function localGooglePreview(request:Request){
 const db=getJournalDb(),email='google-preview@tradejournal.local';let member=await db.prepare('SELECT id,email,name,created_at,suspended FROM members WHERE email = ?').bind(email).first<Member>(),isNewMember=false;
 if(!member){const id=crypto.randomUUID(),created=new Date().toISOString(),unusablePassword=await passwordHash(crypto.randomUUID()+crypto.randomUUID()),inserted=await db.prepare('INSERT INTO members (id,email,name,password_hash,created_at) VALUES (?, ?, ?, ?, ?) ON CONFLICT(email) DO NOTHING').bind(id,email,'Google Preview',unusablePassword,created).run();isNewMember=Number(inserted.meta?.changes??0)>0;member=await db.prepare('SELECT id,email,name,created_at,suspended FROM members WHERE email = ?').bind(email).first<Member>();}
 if(!member||member.suspended)return popupResponse(request,{error:'preview_unavailable'});
 const subscription=await subscriptionFor(member.id),destination=isNewMember?'/?choosePlan=1':hasAccess(member,subscription)?'/journal':subscription?'/?checkout=1':'/?choosePlan=1',response=popupResponse(request,{destination,preview:'1'});
 response.headers.append('Set-Cookie',await sessionCookie(member.id,member.id,'Lax'));return response;
}
async function unavailable(request:Request){
 const popup=new URL(request.url).searchParams.get('popup')==='1';
 if(popup){const hostname=new URL(request.url).hostname;if(['localhost','127.0.0.1'].includes(hostname))return localGooglePreview(request);return popupResponse(request,{error:'unavailable'});}
 const base=appBase(request);if(!base)return Response.json({error:'Google sign-in is unavailable.'},{status:503});const target=new URL('/membership?mode=register',base);return Response.redirect(target,303);
}

export async function GET(request:Request){
 const requestUrl=new URL(request.url);
 const base=appBase(request);if(!base||!config.GOOGLE_CLIENT_ID||!config.GOOGLE_CLIENT_SECRET)return unavailable(request);
 const callbackUrl=new URL('/api/auth/google/callback',base).toString();if(config.GOOGLE_REDIRECT_URI&&config.GOOGLE_REDIRECT_URI!==callbackUrl)return unavailable(request);
 try{await limitAttempts(request,'google:authorize');}catch(error){if(error instanceof Response)return requestUrl.searchParams.get('popup')==='1'?popupResponse(request,{error:'retry'}):error;throw error;}
 const state=randomToken(),verifier=randomToken(48),challenge=base64url(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(verifier)))),authorizeUrl=new URL('https://accounts.google.com/o/oauth2/v2/auth');
 authorizeUrl.searchParams.set('client_id',config.GOOGLE_CLIENT_ID);authorizeUrl.searchParams.set('redirect_uri',callbackUrl);authorizeUrl.searchParams.set('response_type','code');authorizeUrl.searchParams.set('scope','openid email profile');authorizeUrl.searchParams.set('state',state);authorizeUrl.searchParams.set('nonce',state);authorizeUrl.searchParams.set('code_challenge',challenge);authorizeUrl.searchParams.set('code_challenge_method','S256');authorizeUrl.searchParams.set('prompt','select_account');
 const popup=requestUrl.searchParams.get('popup')==='1';
 const flowId=requestUrl.searchParams.get('flow')??'',response=Response.redirect(authorizeUrl,303);response.headers.set('Cache-Control','no-store');response.headers.set('Set-Cookie',`${STATE_COOKIE}=${state}.${verifier}.${popup?'popup':'redirect'}.${flowId}; Path=/api/auth/google; HttpOnly; Secure; SameSite=Lax; Max-Age=600`);return response;
}
