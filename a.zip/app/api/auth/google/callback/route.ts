import {env} from 'cloudflare:workers';
import {z} from 'zod';
import {getJournalDb} from '@/db';
import {limitAttempts,passwordHash,sessionCookie,subscriptionFor} from '@/lib/member-server';
import {hasAccess} from '@/lib/membership';

type GoogleEnvironment={GOOGLE_CLIENT_ID?:string;GOOGLE_CLIENT_SECRET?:string;GOOGLE_REDIRECT_URI?:string;PUBLIC_APP_URL?:string};
const config=env as unknown as GoogleEnvironment;
const STATE_COOKIE='journal_google_oauth';
const googleProfile=z.object({email:z.string().email().max(254),email_verified:z.boolean(),name:z.string().max(200).optional()});
const googleToken=z.object({access_token:z.string().min(16).max(4096)});
type StoredMember={id:string;email:string;name:string;created_at:string;suspended:number};
const clearState=`${STATE_COOKIE}=; Path=/api/auth/google; HttpOnly; Secure; SameSite=Lax; Max-Age=0`;
function appBase(request:Request){if(config.PUBLIC_APP_URL)return new URL(config.PUBLIC_APP_URL).origin;if(config.GOOGLE_REDIRECT_URI)return new URL(config.GOOGLE_REDIRECT_URI).origin;const url=new URL(request.url);return ['localhost','127.0.0.1'].includes(url.hostname)?url.origin:null;}
function readCookie(request:Request,name:string){return (request.headers.get('cookie')??'').split(';').map(part=>part.trim()).find(part=>part.startsWith(`${name}=`))?.slice(name.length+1)??'';}
function popupFlow(request:Request){return new URL(request.url).searchParams.get('popup')==='1'||readCookie(request,STATE_COOKIE).split('.')[2]==='popup';}
function popupResponse(request:Request,payload:Record<string,string>){
 const origin=appBase(request)??new URL(request.url).origin,flowId=readCookie(request,STATE_COOKIE).split('.')[3]??'',message=JSON.stringify({type:'journal:google-auth',...payload,flowId}).replaceAll('<','\\u003c'),key=JSON.stringify(`trade-journal:google:${flowId}`);
 return new Response(`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Trade Journal</title></head><body><p>Returning to Trade Journal…</p><script>const result=${message};try{localStorage.setItem(${key},JSON.stringify(result))}catch{}if(window.opener){window.opener.postMessage(result,${JSON.stringify(origin)});window.close()}setTimeout(()=>{document.body.textContent='You can close this window and continue with email and password.'},400)</script></body></html>`,{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','Content-Security-Policy':"default-src 'none'; script-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'"}});
}
function redirectBack(request:Request,error:string){if(popupFlow(request)){const response=popupResponse(request,{error});response.headers.set('Set-Cookie',clearState);return response;}const base=appBase(request);if(!base)return Response.json({error:'Google sign-in could not be completed.'},{status:503});const target=new URL('/',base);target.searchParams.set('auth','login');target.searchParams.set('auth_error',error);const response=Response.redirect(target,303);response.headers.set('Cache-Control','no-store');response.headers.set('Set-Cookie',clearState);return response;}

export async function GET(request:Request){
 const base=appBase(request);if(!base||!config.GOOGLE_CLIENT_ID||!config.GOOGLE_CLIENT_SECRET)return redirectBack(request,'google_unavailable');
  const url=new URL(request.url),stored=readCookie(request,STATE_COOKIE),[expectedState,verifier]=stored.split('.');
 if(url.searchParams.has('error'))return redirectBack(request,'google_cancelled');
 const code=url.searchParams.get('code'),returnedState=url.searchParams.get('state');
 if(!code||code.length>4096||!expectedState||!verifier||!returnedState||returnedState!==expectedState)return redirectBack(request,'google_failed');
 try{
  await limitAttempts(request,'google:callback');
  const callbackUrl=new URL('/api/auth/google/callback',base).toString();if(config.GOOGLE_REDIRECT_URI&&config.GOOGLE_REDIRECT_URI!==callbackUrl)return redirectBack(request,'google_unavailable');
  const tokenResponse=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id:config.GOOGLE_CLIENT_ID,client_secret:config.GOOGLE_CLIENT_SECRET,code,code_verifier:verifier,grant_type:'authorization_code',redirect_uri:callbackUrl})});
  if(!tokenResponse.ok)return redirectBack(request,'google_failed');
  const token=googleToken.parse(await tokenResponse.json());
  const profileResponse=await fetch('https://openidconnect.googleapis.com/v1/userinfo',{headers:{Authorization:`Bearer ${token.access_token}`}});
  if(!profileResponse.ok)return redirectBack(request,'google_failed');
  const profile=googleProfile.parse(await profileResponse.json());if(!profile.email_verified)return redirectBack(request,'google_failed');
  const db=getJournalDb(),email=profile.email.trim().toLowerCase(),existing=await db.prepare('SELECT id,email,name,created_at,suspended FROM members WHERE email = ?').bind(email).first<StoredMember>();
  let isNewMember=false;
  let member:StoredMember|null=existing;
  if(!member){
   const id=crypto.randomUUID(),created=new Date().toISOString(),name=profile.name?.trim()||email.split('@')[0],unusablePassword=await passwordHash(crypto.randomUUID()+crypto.randomUUID());
   const inserted=await db.prepare('INSERT INTO members (id,email,name,password_hash,created_at) VALUES (?, ?, ?, ?, ?) ON CONFLICT(email) DO NOTHING').bind(id,email,name,unusablePassword,created).run();
   isNewMember=Number(inserted.meta?.changes??0)>0;
   member=await db.prepare('SELECT id,email,name,created_at,suspended FROM members WHERE email = ?').bind(email).first<StoredMember>();
  }
  if(!member||member.suspended)return redirectBack(request,'google_failed');
  const subscription=await subscriptionFor(member.id);
  // Only first-time Google registrations see the plan chooser. Returning members
  // go straight to their workspace when they have access; expired plans renew.
  const destination=isNewMember?'/?choosePlan=1':hasAccess(member,subscription)?'/journal':subscription?'/?checkout=1':'/?choosePlan=1';
  const target=new URL(destination,base),response=popupFlow(request)?popupResponse(request,{destination:`${target.pathname}${target.search}`}):Response.redirect(target,303);
  response.headers.set('Cache-Control','no-store');response.headers.set('Set-Cookie',clearState);response.headers.append('Set-Cookie',await sessionCookie(member.id,member.id,'Lax'));return response;
 }catch(error){console.error('Google OAuth callback failed',error);return redirectBack(request,'google_failed');}
}
