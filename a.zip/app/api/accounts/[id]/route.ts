import { z } from 'zod';
import { getJournalDb } from '@/db';
import { auth,body,failure,json } from '@/lib/journal-server';
import { accountIdSchema } from '@/lib/trading';
const revisionSchema=z.object({revision:z.number().int().nonnegative()});
async function setArchived(request:Request,params:Promise<{id:string}>,archived:boolean){try{
 const owner=await auth(request),id=accountIdSchema.parse((await params).id),{revision}=revisionSchema.parse(await body(request)),db=getJournalDb();
 if(revision===0&&(id!=='default'||!archived))return json({error:'ანგარიშის ვერსია არასწორია.'},400);
 // The legacy main account is virtual until edited. Persist its archive marker so it stays deleted after reload.
 let result;
 if(id==='default'&&revision===0){
  const settings=await db.prepare('SELECT data_json FROM journal_settings WHERE owner_id = ?').bind(owner).first<{data_json:string}>();
  const account={id,revision:1,name:'მთავარი ანგარიში',type:'Demo',currency:'USD',startingBalance:settings?JSON.parse(settings.data_json).startingBalance:null,description:''};
  result=await db.prepare('INSERT INTO trading_accounts (owner_id, id, data_json, revision, archived, created_at) VALUES (?, ?, ?, 1, 1, ?) ON CONFLICT(owner_id, id) DO NOTHING').bind(owner,id,JSON.stringify(account),new Date().toISOString()).run();
 }else{
  result=await db.prepare('UPDATE trading_accounts SET archived = ?, revision = revision + 1 WHERE owner_id = ? AND id = ? AND revision = ? AND archived = ?').bind(archived?1:0,owner,id,revision,archived?0:1).run();
 }
 if(!result.meta.changes)return json({error:'ანგარიში ვერ მოიძებნა ან სხვა ფანჯარაში შეიცვალა. განაახლე გვერდი.'},409);
 return json({ok:true,revision:revision+1});
}catch(e){return failure(e);}}
export async function DELETE(request:Request,{params}:{params:Promise<{id:string}>}){return setArchived(request,params,true);}
export async function PATCH(request:Request,{params}:{params:Promise<{id:string}>}){return setArchived(request,params,false);}
