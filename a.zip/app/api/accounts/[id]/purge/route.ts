import {z} from 'zod';
import {getJournalDb,getScreenshotsBucket} from '@/db';
import {auth,body,failure,json} from '@/lib/journal-server';
import {accountIdSchema} from '@/lib/trading';
const input=z.object({revision:z.number().int().positive(),confirm:z.literal(true)});
export async function POST(request:Request,{params}:{params:Promise<{id:string}>}){try{
 const owner=await auth(request),id=accountIdSchema.parse((await params).id),{revision}=input.parse(await body(request)),db=getJournalDb();
 const row=await db.prepare('SELECT archived, revision FROM trading_accounts WHERE owner_id = ? AND id = ?').bind(owner,id).first<{archived:number;revision:number}>();
 if(row?.archived===3)return json({ok:true});
 if(!row||row.archived===0||!(row.revision===revision||(row.archived===2&&row.revision===revision+1)))return json({error:'ანგარიში ვერ მოიძებნა ან სხვა ფანჯარაში შეიცვალა. განაახლე გვერდი.'},409);
 // State 2 locks restoration while storage cleanup runs; failures can be retried.
 if(row.archived===1){const lock=await db.prepare('UPDATE trading_accounts SET archived = 2, revision = revision + 1 WHERE owner_id = ? AND id = ? AND archived = 1 AND revision = ?').bind(owner,id,revision).run();if(!lock.meta.changes)return json({error:'ანგარიში სხვა ფანჯარაში შეიცვალა. განაახლე გვერდი.'},409);}
 const tradeQuery="SELECT id FROM trades WHERE owner_id = ? AND COALESCE(json_extract(data_json, '$.accountId'), 'default') = ?";
 const shots=await db.prepare(`SELECT object_key FROM screenshots WHERE owner_id = ? AND trade_id IN (${tradeQuery})`).bind(owner,owner,id).all<{object_key:string}>();
 // Delete the actual files first, keeping their references if the bucket is unavailable.
 for(let offset=0;offset<shots.results.length;offset+=1000)await getScreenshotsBucket().delete(shots.results.slice(offset,offset+1000).map(s=>s.object_key));
 await db.batch([
  db.prepare(`DELETE FROM screenshots WHERE owner_id = ? AND trade_id IN (${tradeQuery})`).bind(owner,owner,id),
  db.prepare("DELETE FROM trades WHERE owner_id = ? AND COALESCE(json_extract(data_json, '$.accountId'), 'default') = ?").bind(owner,id),
  // Keep only an empty identifier marker, preventing stale writes and the virtual main account from returning.
  db.prepare("UPDATE trading_accounts SET archived = 3, data_json = '{}', revision = revision + 1 WHERE owner_id = ? AND id = ? AND archived = 2").bind(owner,id)
 ]);
 return json({ok:true});
}catch(e){return failure(e);}}
