import { getJournalDb } from '@/db';
import { auth,body,failure,json } from '@/lib/journal-server';
import { accountSchema,type Account } from '@/lib/trading';
export async function POST(request:Request){try{
 const owner=await auth(request),account=accountSchema.parse(await body(request)),db=getJournalDb();
 const previous=await db.prepare('SELECT data_json, archived FROM trading_accounts WHERE owner_id = ? AND id = ?').bind(owner,account.id).first<{data_json:string;archived:number}>();
 if(previous?.archived)return json({error:'ეს ანგარიში წაშლილია. ჯერ აღადგინე.'},409);
 const oldCurrency=previous?(JSON.parse(previous.data_json) as Account).currency:'USD';
 if(oldCurrency!==account.currency){const used=await db.prepare("SELECT id FROM trades WHERE owner_id = ? AND COALESCE(json_extract(data_json, '$.accountId'), 'default') = ? LIMIT 1").bind(owner,account.id).first();if(used)return json({error:'თრეიდების მქონე ანგარიშის ვალუტა ვერ შეიცვლება. შექმენი სხვა ანგარიში.'},400);}
 const stored={...account,revision:account.revision+1};
 const result=account.revision===0?await db.prepare('INSERT INTO trading_accounts (owner_id, id, data_json, revision, created_at) VALUES (?, ?, ?, 1, ?) ON CONFLICT(owner_id, id) DO NOTHING').bind(owner,account.id,JSON.stringify(stored),new Date().toISOString()).run():await db.prepare('UPDATE trading_accounts SET data_json = ?, revision = revision + 1 WHERE owner_id = ? AND id = ? AND revision = ? AND archived = 0').bind(JSON.stringify(stored),owner,account.id,account.revision).run();
 if(!result.meta.changes)return json({error:'ანგარიში სხვა ფანჯარაში შეიცვალა. განაახლე გვერდი.'},409);
 return json({account:stored});
}catch(e){return failure(e);}}
