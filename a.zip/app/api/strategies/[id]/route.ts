import { z } from 'zod';
import { getJournalDb } from '@/db';
import { auth,body,failure,json } from '@/lib/journal-server';
export async function DELETE(request:Request,{params}:{params:Promise<{id:string}>}){try{
 const owner=await auth(request),id=z.string().uuid().parse((await params).id),revision=z.object({revision:z.number().int().positive()}).parse(await body(request)).revision;
 const result=await getJournalDb().prepare('UPDATE trading_strategies SET archived = 1, revision = revision + 1 WHERE owner_id = ? AND id = ? AND revision = ? AND archived = 0').bind(owner,id,revision).run();
 if(!result.meta.changes)return json({error:'სტრატეგია ვერ მოიძებნა ან შეიცვალა. განაახლე გვერდი.'},409);
 return json({ok:true});
}catch(e){return failure(e);}}
