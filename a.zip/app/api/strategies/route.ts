import { getJournalDb } from '@/db';
import { auth,body,failure,json } from '@/lib/journal-server';
import { strategySchema } from '@/lib/trading';
export async function POST(request:Request){try{
 const owner=await auth(request),strategy=strategySchema.parse(await body(request)),db=getJournalDb(),stored={...strategy,revision:strategy.revision+1};
 const result=strategy.revision===0?await db.prepare('INSERT INTO trading_strategies (owner_id, id, data_json, revision, archived, created_at) VALUES (?, ?, ?, 1, 0, ?) ON CONFLICT(owner_id, id) DO NOTHING').bind(owner,strategy.id,JSON.stringify(stored),new Date().toISOString()).run():await db.prepare('UPDATE trading_strategies SET data_json = ?, revision = revision + 1 WHERE owner_id = ? AND id = ? AND revision = ? AND archived = 0').bind(JSON.stringify(stored),owner,strategy.id,strategy.revision).run();
 if(!result.meta.changes)return json({error:'სტრატეგია სხვა ფანჯარაში შეიცვალა. განაახლე გვერდი.'},409);
 return json({strategy:stored});
}catch(e){return failure(e);}}
