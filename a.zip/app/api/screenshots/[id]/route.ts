import { getJournalDb,getScreenshotsBucket } from '@/db';
import { auth,json,failure } from '@/lib/journal-server';
export async function GET(_request:Request,{params}:{params:Promise<{id:string}>}){try{const owner=await auth(),{id}=await params;
 const shot=await getJournalDb().prepare('SELECT object_key, mime FROM screenshots WHERE id = ? AND owner_id = ?').bind(id,owner).first<{object_key:string;mime:string}>();if(!shot)return json({error:'სქრინშოტი ვერ მოიძებნა.'},404);
 const object=await getScreenshotsBucket().get(shot.object_key);if(!object)return json({error:'ფაილი დროებით მიუწვდომელია.'},404);
 return new Response(object.body,{headers:{'Content-Type':shot.mime,'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Content-Disposition':'inline'}});
}catch(e){return failure(e);}}
export async function DELETE(request:Request,{params}:{params:Promise<{id:string}>}){try{const owner=await auth(request),{id}=await params,db=getJournalDb();
 const shot=await db.prepare('SELECT object_key FROM screenshots WHERE id = ? AND owner_id = ?').bind(id,owner).first<{object_key:string}>();if(!shot)return json({error:'სქრინშოტი ვერ მოიძებნა.'},404);
 await db.prepare('DELETE FROM screenshots WHERE id = ? AND owner_id = ?').bind(id,owner).run();try{await getScreenshotsBucket().delete(shot.object_key);}catch(e){console.error('Screenshot cleanup failed',e);}return json({ok:true});
}catch(e){return failure(e);}}
