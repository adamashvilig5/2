import { getJournalDb,getScreenshotsBucket } from '@/db';
import { auth,json,failure,findTrade } from '@/lib/journal-server';
import { MAX_SCREENSHOTS } from '@/lib/trading';
const LIMIT=8*1024*1024;
export async function POST(request:Request){let key:string|undefined;let stored=false;try{
 const owner=await auth(request);if(Number(request.headers.get('content-length')??0)>LIMIT+16384)return json({error:'სქრინშოტის ზომა არ უნდა აღემატებოდეს 8 MB-ს.'},413);
 if(!request.headers.get('content-type')?.startsWith('multipart/form-data'))return json({error:'სქრინშოტი ფაილად ატვირთე.'},400);
 const form=await request.formData(),tradeId=String(form.get('tradeId')??''),phase=String(form.get('phase')??'context'),file=form.get('file'),id=String(form.get('id')??crypto.randomUUID());
 if(!['before','after','context'].includes(phase)||!(file instanceof File)||! /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id))return json({error:'აირჩიე სქრინშოტი და ეტაპი.'},400);
 if(!await findTrade(owner,tradeId))return json({error:'თრეიდი ვერ მოიძებნა.'},404);
 const db=getJournalDb(),bucket=getScreenshotsBucket();
 const existing=await db.prepare('SELECT id, owner_id, trade_id, phase, filename FROM screenshots WHERE id = ?').bind(id).first<{id:string;owner_id:string;trade_id:string;phase:string;filename:string}>();
 if(existing){if(existing.owner_id!==owner||existing.trade_id!==tradeId)return json({error:'ფოტოს იდენტიფიკატორი უკვე გამოყენებულია.'},409);return json({screenshot:{id:existing.id,phase:existing.phase,filename:existing.filename}});}
 const count=await db.prepare('SELECT COUNT(*) AS count FROM screenshots WHERE owner_id = ? AND trade_id = ?').bind(owner,tradeId).first<{count:number}>();
 if((count?.count??0)>=MAX_SCREENSHOTS)return json({error:`თითო თრეიდზე მაქსიმუმ ${MAX_SCREENSHOTS} ფოტო ინახება.`},409);
 if(!file.size||file.size>LIMIT)return json({error:'სქრინშოტის ზომა უნდა იყოს 1 ბაიტიდან 8 MB-მდე.'},413);
 const bytes=new Uint8Array(await file.arrayBuffer());
 const mime=bytes.length>=8&&[137,80,78,71,13,10,26,10].every((n,i)=>bytes[i]===n)?'image/png':bytes[0]===255&&bytes[1]===216&&bytes[2]===255?'image/jpeg':bytes.length>=12&&String.fromCharCode(...bytes.slice(0,4))==='RIFF'&&String.fromCharCode(...bytes.slice(8,12))==='WEBP'?'image/webp':null;
 if(!mime)return json({error:'დასაშვებია მხოლოდ PNG, JPG ან WebP სქრინშოტი.'},400);
 key=`screenshots/${encodeURIComponent(owner)}/${tradeId}/${id}`;
 await bucket.put(key,bytes,{httpMetadata:{contentType:mime}});
 const result=await db.prepare('INSERT INTO screenshots (id, owner_id, trade_id, phase, object_key, filename, mime) SELECT ?, ?, ?, ?, ?, ?, ? WHERE EXISTS (SELECT 1 FROM trades WHERE id = ? AND owner_id = ?) AND (SELECT COUNT(*) FROM screenshots WHERE owner_id = ? AND trade_id = ?) < ? ON CONFLICT(id) DO NOTHING').bind(id,owner,tradeId,phase,key,file.name.slice(0,200),mime,tradeId,owner,owner,tradeId,MAX_SCREENSHOTS).run();
 if(!result.meta.changes){const retry=await db.prepare('SELECT id FROM screenshots WHERE id = ? AND owner_id = ? AND trade_id = ?').bind(id,owner,tradeId).first();if(retry){stored=true;return json({screenshot:{id,phase,filename:file.name.slice(0,200)}});}throw json({error:`თრეიდი აღარ არსებობს ან უკვე ${MAX_SCREENSHOTS} ფოტო აქვს.`},409);}stored=true;
 return json({screenshot:{id,phase,filename:file.name.slice(0,200)}});
}catch(e){if(key&&!stored)try{await getScreenshotsBucket().delete(key);}catch{}return failure(e);}}
