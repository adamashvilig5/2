import { getJournalDb } from '@/db';
import { auth,json,failure,body } from '@/lib/journal-server';
import { settingsSchema } from '@/lib/trading';
export async function GET(request:Request){try{const owner=await auth(request);const row=await getJournalDb().prepare('SELECT data_json, revision FROM journal_settings WHERE owner_id = ?').bind(owner).first<{data_json:string;revision:number}>();return json({settings:row?{...JSON.parse(row.data_json),revision:row.revision}:{startingBalance:null,timezone:'America/New_York',revision:0}});}catch(e){return failure(e);}}
export async function PUT(request:Request){try{const owner=await auth(request),s=settingsSchema.parse(await body(request)),db=getJournalDb();
 const result=s.revision===0?await db.prepare('INSERT INTO journal_settings (owner_id, data_json, revision) VALUES (?, ?, 1) ON CONFLICT(owner_id) DO NOTHING').bind(owner,JSON.stringify(s)).run():await db.prepare('UPDATE journal_settings SET data_json = ?, revision = revision + 1 WHERE owner_id = ? AND revision = ?').bind(JSON.stringify(s),owner,s.revision).run();
 if(!result.meta.changes)return json({error:'პარამეტრები სხვა ფანჯარაში შეიცვალა. განაახლე გვერდი.'},409);return json({settings:{...s,revision:s.revision+1}});
}catch(e){return failure(e);}}
