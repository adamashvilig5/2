import { getJournalDb } from '@/db';
import { auth,failure,fromRow,json,type TradeRow } from '@/lib/journal-server';
import { todayIn,type Daily,type Strategy } from '@/lib/trading';
import { ACHIEVEMENTS,achievementMetrics,achievementProgress,type Award,type TodayProcessTask } from '@/lib/achievements';
import type { InnerEntry } from '@/lib/inner-space';

export async function POST(request:Request){try{
 const owner=await auth(request),db=getJournalDb();
 // All evidence comes from the authenticated journal. The client cannot award XP or mark a badge earned.
 const [trades,shots,daily,strategies,settings,existing,innerEntries]=await Promise.all([
  db.prepare('SELECT id, data_json, revision, created_at FROM trades WHERE owner_id = ?').bind(owner).all<TradeRow>(),
  db.prepare('SELECT id, trade_id, phase, filename FROM screenshots WHERE owner_id = ?').bind(owner).all<{id:string;trade_id:string;phase:'before'|'after'|'context';filename:string}>(),
  db.prepare('SELECT data_json FROM daily_notes WHERE owner_id = ?').bind(owner).all<{data_json:string}>(),
  db.prepare('SELECT data_json FROM trading_strategies WHERE owner_id = ?').bind(owner).all<{data_json:string}>(),
  db.prepare('SELECT data_json FROM journal_settings WHERE owner_id = ?').bind(owner).first<{data_json:string}>(),
  db.prepare('SELECT achievement_id, xp, earned_at FROM achievement_awards WHERE owner_id = ?').bind(owner).all<{achievement_id:string;xp:number;earned_at:string}>(),
  db.prepare('SELECT data_json FROM inner_space_entries WHERE owner_id = ?').bind(owner).all<{data_json:string}>(),
 ]);
 const grouped=new Map<string,typeof shots.results>();for(const shot of shots.results){const list=grouped.get(shot.trade_id)??[];list.push(shot);grouped.set(shot.trade_id,list);}
 const rows=trades.results.map(t=>fromRow(t,(grouped.get(t.id)??[]).map(s=>({id:s.id,phase:s.phase,filename:s.filename}))));
 const today=todayIn(settings?JSON.parse(settings.data_json).timezone:'America/New_York'),plans=daily.results.map(d=>JSON.parse(d.data_json) as Daily),entries=innerEntries.results.map(row=>JSON.parse(row.data_json) as InnerEntry);
 const metrics=achievementMetrics(rows,plans,strategies.results.map(s=>JSON.parse(s.data_json) as Strategy),today,entries);
 const todayPlan=plans.find(plan=>plan.date===today),todayTrades=rows.filter(trade=>trade.date===today),todayEntry=entries.find(entry=>entry.date===today);
 const todayProcess:TodayProcessTask[]=[
  {id:'check-in',title:'Check-in completed',xp:20,done:todayEntry?.mood!==null&&todayEntry?.mood!==undefined,earned:false},
  {id:'risk-plan',title:'Risk rule confirmed',xp:30,done:!!todayPlan?.rules.some(rule=>/risk|რისკ/i.test(rule.label)&&rule.checked),earned:false},
  {id:'trade-review',title:'Trade reviewed',xp:40,done:todayTrades.some(trade=>!!trade.review),earned:false},
  {id:'trade-notes',title:'Trade notes added',xp:20,done:todayTrades.some(trade=>trade.notes.trim().length>=20),earned:false},
  {id:'daily-rules',title:'Daily rules completed',xp:30,done:!!todayPlan?.rules.length&&todayPlan.rules.every(rule=>rule.checked),earned:false},
 ];
 const already=new Set(existing.results.map(a=>a.achievement_id)),eligible=ACHIEVEMENTS.filter(a=>!already.has(a.id)&&metrics[a.metric]>=a.target),now=new Date().toISOString();
 const dailyEligible=todayProcess.filter(task=>task.done&&!already.has(`daily:${today}:${task.id}`));
 const inserts=[...eligible.map(a=>({id:a.id,xp:a.xp})),...dailyEligible.map(task=>({id:`daily:${today}:${task.id}`,xp:task.xp}))];
 const inserted=inserts.length?await db.batch(inserts.map(item=>db.prepare('INSERT INTO achievement_awards (owner_id, achievement_id, xp, earned_at) VALUES (?, ?, ?, ?) ON CONFLICT(owner_id, achievement_id) DO NOTHING').bind(owner,item.id,item.xp,now))):[];
 const saved=await db.prepare('SELECT achievement_id, xp, earned_at FROM achievement_awards WHERE owner_id = ? ORDER BY earned_at DESC, achievement_id').bind(owner).all<{achievement_id:string;xp:number;earned_at:string}>();
 const awards:Award[]=saved.results.map(a=>({id:a.achievement_id,xp:a.xp,earnedAt:a.earned_at}));
 const earnedToday=new Set(awards.map(award=>award.id));
 const dailyProgress=todayProcess.map(task=>({...task,earned:earnedToday.has(`daily:${today}:${task.id}`)}));
 return json({progress:achievementProgress(metrics,awards,dailyProgress),newAwards:eligible.filter((_,i)=>inserted[i]?.meta.changes>0).map(a=>({id:a.id,title:a.title,xp:a.xp}))});
}catch(e){return failure(e);}}
