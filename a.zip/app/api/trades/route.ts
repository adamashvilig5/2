import { getJournalDb } from '@/db';
import { auth,json,failure,body,fromRow,findTrade } from '@/lib/journal-server';
import { conditionId,structuredEmotionsAtEntry,tradeSchema,type Strategy } from '@/lib/trading';
export async function POST(request:Request){try{
 const owner=await auth(request),trade=tradeSchema.parse(await body(request)),db=getJournalDb(),now=new Date().toISOString();
 const old=trade.revision?await findTrade(owner,trade.id):null,previous=old?fromRow(old):null;
 if(previous){if(trade.accountId===undefined)trade.accountId=previous.accountId;if(trade.strategyId===undefined){trade.strategyId=previous.strategyId;trade.strategySnapshot=previous.strategySnapshot;}}
 const accountId=trade.accountId??'default',account=await db.prepare('SELECT archived FROM trading_accounts WHERE owner_id = ? AND id = ?').bind(owner,accountId).first<{archived:number}>();
 if(account?.archived||(!account&&accountId!=='default'))return json({error:'ანგარიში ვერ მოიძებნა. ჯერ აღადგინე ან აირჩიე აქტიური ანგარიში.'},400);
 if(trade.strategyId){
  const selected=await db.prepare('SELECT data_json FROM trading_strategies WHERE owner_id = ? AND id = ? AND archived = 0').bind(owner,trade.strategyId).first<{data_json:string}>();
  // Keep the exact plan recorded on an existing trade, even after a strategy changes or is removed.
  if(previous?.strategyId===trade.strategyId&&previous.strategySnapshot)trade.strategySnapshot=previous.strategySnapshot;
  else if(selected){const strategy=JSON.parse(selected.data_json) as Strategy;trade.strategySnapshot={name:strategy.name,checklist:strategy.checklist};}
  else return json({error:'სტრატეგია ვერ მოიძებნა. აირჩიე შენ მიერ შექმნილი სტრატეგია.'},400);
  if(trade.strategyChecks?.some(label=>!trade.strategySnapshot!.checklist.includes(label)))return json({error:'მონიშნე მხოლოდ არჩეული სტრატეგიის პირობები.'},400);
  trade.tags=[trade.strategySnapshot!.name];
 }else if(trade.strategyId===null){trade.strategySnapshot=null;trade.strategyChecks=[];trade.tags=[];}
 const checkedConditions=new Set(trade.strategyChecks??[]),conditionLabels=trade.strategySnapshot?.checklist??[];
 trade.strategyConditions=conditionLabels.map(label=>({id:conditionId(label),label,checked:checkedConditions.has(label)}));
 trade.conditionsMet=trade.strategyConditions.filter(condition=>condition.checked).length;
 trade.conditionsTotal=trade.strategyConditions.length;
 trade.conditionsCompletionRate=trade.conditionsTotal?Math.round(trade.conditionsMet/trade.conditionsTotal*100):0;
 const entryEmotions=trade.emotions?.length?[...new Set(trade.emotions)]:[trade.emotion];
 trade.emotionsAtEntry=structuredEmotionsAtEntry(entryEmotions);
 trade.selectedEmotionIds=trade.emotionsAtEntry.filter(emotion=>emotion.selected).map(emotion=>emotion.id);
 trade.rMultiple=trade.pnl/trade.risk;
 const reviewStillApplies=previous?.review&&previous.symbol===trade.symbol&&previous.side===trade.side&&previous.result===trade.result&&previous.quantity===trade.quantity&&previous.pnl===trade.pnl&&previous.risk===trade.risk&&previous.date===trade.date&&previous.entryTime===trade.entryTime&&previous.exitTime===trade.exitTime&&previous.strategyId===trade.strategyId&&JSON.stringify(previous.strategyChecks??[])===JSON.stringify(trade.strategyChecks??[]);
 const stored={...trade,createdAt:previous?.createdAt??now,updatedAt:now,...(reviewStillApplies?{review:previous!.review}:{}),revision:trade.revision+1};
 // Recheck in the write itself, including the legacy main account, to prevent writes racing with deletion.
 const accountGuard="EXISTS (SELECT 1 FROM trading_accounts WHERE owner_id = ? AND id = ? AND archived = 0) OR (? = 'default' AND NOT EXISTS (SELECT 1 FROM trading_accounts WHERE owner_id = ? AND id = 'default'))";
 let result;
 if(trade.revision===0){
  const insert=db.prepare(`INSERT INTO trades (id, owner_id, trade_date, data_json, revision, created_at, updated_at) SELECT ?, ?, ?, ?, 1, ?, ? WHERE (${accountGuard}) AND NOT EXISTS (SELECT 1 FROM subscriptions WHERE member_id = ? AND (status = 'demo_used' OR (status = 'demo' AND (SELECT COUNT(*) FROM trades WHERE owner_id = ?) >= 1))) ON CONFLICT(id) DO NOTHING`).bind(trade.id,owner,trade.date,JSON.stringify(stored),now,now,owner,accountId,accountId,owner,owner,owner);
  const markDemoUsed=db.prepare("UPDATE subscriptions SET status = 'demo_used', revision = revision + 1 WHERE member_id = ? AND status = 'demo' AND EXISTS (SELECT 1 FROM trades WHERE owner_id = ? AND id = ?)").bind(owner,owner,trade.id);
  [result]=await db.batch([insert,markDemoUsed]);
 }else result=await db.prepare(`UPDATE trades SET trade_date = ?, data_json = ?, revision = revision + 1, updated_at = ? WHERE id = ? AND owner_id = ? AND revision = ? AND (${accountGuard})`).bind(trade.date,JSON.stringify(stored),now,trade.id,owner,trade.revision,owner,accountId,accountId,owner).run();
 if(!result.meta.changes){
  const limit=await db.prepare("SELECT s.status,(SELECT COUNT(*) FROM trades WHERE owner_id = s.member_id) AS trade_count FROM subscriptions s WHERE s.member_id = ? AND s.status IN ('demo','demo_used')").bind(owner).first<{status:string;trade_count:number}>();
  if(limit&&(limit.trade_count>=1||limit.status==='demo_used'))return json({error:'The Demo includes one saved trade. Choose Journal Pro to add more.',code:'DEMO_LIMIT_REACHED'},403);
  return json({error:'ჩანაწერი სხვა ფანჯარაში შეიცვალა ან უკვე შენახულია. განაახლე ჟურნალი.'},409);
 }
 return json({trade:fromRow({id:trade.id,data_json:JSON.stringify(stored),revision:trade.revision+1,created_at:previous?.createdAt??now})});
}catch(e){return failure(e);}}
