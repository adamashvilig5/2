import { getJournalDb,getScreenshotsBucket } from '@/db';
import { auth,json,failure,findTrade } from '@/lib/journal-server';
export async function DELETE(request:Request,{params}:{params:Promise<{id:string}>}){try{
 const owner=await auth(request),{id}=await params,db=getJournalDb();if(!await findTrade(owner,id))return json({error:'თრეიდი ვერ მოიძებნა.'},404);
 const shots=await db.prepare('SELECT object_key FROM screenshots WHERE trade_id = ? AND owner_id = ?').bind(id,owner).all<{object_key:string}>();
 await db.batch([db.prepare('DELETE FROM screenshots WHERE trade_id = ? AND owner_id = ?').bind(id,owner),db.prepare('DELETE FROM trades WHERE id = ? AND owner_id = ?').bind(id,owner)]);
 if(shots.results.length)try{await getScreenshotsBucket().delete(shots.results.map(s=>s.object_key));}catch(e){console.error('Object cleanup failed',e);}
 return json({ok:true});
}catch(e){return failure(e);}}
