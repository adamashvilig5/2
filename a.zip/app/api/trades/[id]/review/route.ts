import { getJournalDb } from '@/db';
import { auth, body, failure, findTrade, fromRow, json } from '@/lib/journal-server';
import { tradeReviewSchema } from '@/lib/trading';

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const owner = await auth(request);
    const { id } = await params;
    const review = tradeReviewSchema.parse(await body(request));
    const row = await findTrade(owner, id);
    if (!row) return json({ error: 'Trade not found.' }, 404);
    const trade = fromRow(row);
    const validConditionIds=new Set((trade.strategyConditions??[]).map(condition=>condition.id));
    if((review.satisfiedConditionIds??[]).some(conditionId=>!validConditionIds.has(conditionId)))return json({error:'Review conditions must belong to this trade strategy.'},400);
    const executionQuality=review.executionChecks.length>=5?'excellent':review.executionChecks.length>=4?'good':review.executionChecks.length>=2?'partial':'needs_review';
    const now=new Date().toISOString(),next = { ...trade, updatedAt:now, review:{...review,executionQuality} };
    const result = await getJournalDb().prepare('UPDATE trades SET data_json = ?, revision = revision + 1, updated_at = ? WHERE id = ? AND owner_id = ? AND revision = ?')
      .bind(JSON.stringify(next), now, id, owner, row.revision).run();
    if (!result.meta.changes) return json({ error: 'Trade changed in another window. Reload and try again.' }, 409);
    return json({ trade: { ...next, revision: row.revision + 1 } });
  } catch (error) {
    return failure(error);
  }
}
