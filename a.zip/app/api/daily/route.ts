import { getJournalDb } from '@/db';
import { auth,json,failure,body } from '@/lib/journal-server';
import { dailySchema } from '@/lib/trading';
export async function PUT(request:Request){try{const owner=await auth(request),d=dailySchema.parse(await body(request)),db=getJournalDb();
 const result=d.revision===0?await db.prepare('INSERT INTO daily_notes (owner_id, date, data_json, revision) VALUES (?, ?, ?, 1) ON CONFLICT(owner_id, date) DO NOTHING').bind(owner,d.date,JSON.stringify(d)).run():await db.prepare('UPDATE daily_notes SET data_json = ?, revision = revision + 1 WHERE owner_id = ? AND date = ? AND revision = ?').bind(JSON.stringify(d),owner,d.date,d.revision).run();
 if(!result.meta.changes)return json({error:'დღის გეგმა სხვა ფანჯარაში შეიცვალა. განაახლე გვერდი.'},409);return json({daily:{...d,revision:d.revision+1}});
}catch(e){return failure(e);}}
