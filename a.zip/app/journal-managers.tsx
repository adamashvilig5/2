'use client';
import { useLanguage } from './journal-language';
import { useEffect, useState, type FormEvent } from 'react';
import { Target, Plus, Trash2, Save, Check, Wallet, FlaskConical, History, ShieldCheck, FileText } from 'lucide-react';
import { accountSchema, strategySchema, money, type Account, type Strategy } from '@/lib/trading';
import ICTSuggestions from './ict-suggestions';
import { addICTCondition } from '@/lib/ict-checklist';
const blankStrategy = (): Strategy => ({ id: crypto.randomUUID(), revision: 0, name: '', description: '', checklist: [] });
export function StrategyManager({ strategies, onSave, onDelete, onDirtyChange }: {
    strategies: Strategy[];
    onSave: (strategy: Strategy) => Promise<Strategy>;
    onDelete: (strategy: Strategy) => Promise<void>;
    onDirtyChange?: (dirty: boolean) => void;
}) {
    const { t, language, locale } = useLanguage();
    const [draft, setDraft] = useState<Strategy>(() => strategies[0] ?? blankStrategy()), [original, setOriginal] = useState(() => JSON.stringify(strategies[0] ?? null)), [item, setItem] = useState(''), [error, setError] = useState(''), [busy, setBusy] = useState(false), [saved, setSaved] = useState(false);
    const dirty = original === 'null' ? Boolean(draft.name || draft.description || draft.checklist.length) : JSON.stringify(draft) !== original;
    useEffect(() => { onDirtyChange?.(dirty || Boolean(item.trim())); return () => onDirtyChange?.(false); }, [dirty, item, onDirtyChange]);
    function select(strategy?: Strategy) {
        if (dirty && !window.confirm(t("სტრატეგიაში შეუნახავი ცვლილებებია. გააგრძელებ?")))
            return;
        const next = strategy ?? blankStrategy();
        setDraft(next);
        setOriginal(JSON.stringify(next));
        setError('');
        setItem('');
        setSaved(false);
    }
    function change(patch: Partial<Strategy>) { setDraft(d => ({ ...d, ...patch })); setSaved(false); setError(''); }
    function addItem() {
        const value = item.trim();
        if (!value)
            return;
        if (value.length > 100) {
            setError(t("პირობა მაქსიმუმ 100 სიმბოლოა."));
            return;
        }
        if (draft.checklist.includes(value)) {
            setError(t("ეს პირობა უკვე დამატებულია."));
            return;
        }
        if (draft.checklist.length >= 16) {
            setError(t("შეგიძლია დაამატო მაქსიმუმ 16 პირობა."));
            return;
        }
        change({ checklist: [...draft.checklist, value] });
        setItem('');
    }
    function suggest(id: string) {
        try {
            change({ checklist: addICTCondition(draft.checklist, id, language) });
        }
        catch (e) {
            setError((e as Error).message);
        }
    }
    async function submit(e: FormEvent) {
        e.preventDefault();
        const parsed = strategySchema.safeParse({ ...draft, checklist: item.trim() ? [...draft.checklist, item.trim()] : draft.checklist });
        if (!parsed.success) {
            setError(parsed.error.issues[0].message);
            return;
        }
        setBusy(true);
        setError('');
        try {
            const next = await onSave(parsed.data);
            setDraft(next);
            setOriginal(JSON.stringify(next));
            setItem('');
            setSaved(true);
        }
        catch (e) {
            setError((e as Error).message);
        }
        finally {
            setBusy(false);
        }
    }
    async function remove() {
        if (!window.confirm(t("წაშლი ამ სტრატეგიას? უკვე ჩაწერილ თრეიდებში მისი გეგმა და შედეგები შენარჩუნდება.")))
            return;
        setBusy(true);
        try {
            await onDelete(draft);
            const next = blankStrategy();
            setDraft(next);
            setOriginal(JSON.stringify(next));
            setSaved(false);
        }
        catch (e) {
            setError((e as Error).message);
        }
        finally {
            setBusy(false);
        }
    }
    return <section className="strategy-manager panel"><aside className="strategy-list"><div className="manager-caption"><Target size={17}/><span>{t("ჩემი სტრატეგიები")}</span><b>{strategies.length}</b></div><button className="primary" disabled={busy} onClick={() => select()}><Plus size={16}/>{t(" ახალი სტრატეგია")}</button><div className="strategy-items">{strategies.map(s => <button key={s.id} disabled={busy} className={draft.id === s.id ? 'selected' : ''} onClick={() => select(s)}><span className="strategy-symbol"><Target size={17}/></span><span><strong>{s.name}</strong><small>{s.checklist.length}{t(" პირობა")}</small></span>{draft.id === s.id && <Check size={15}/>}</button>)}</div>{!strategies.length && <p className="manager-help">{t("შექმენი შენი პირველი სტრატეგია. შენ ირჩევ სახელსაც და ყველა პირობასაც.")}</p>}</aside><form className="strategy-editor" onSubmit={submit}><div className="editor-heading"><span className="eyebrow">{t("YOUR TRADING PLAYBOOK")}</span><h2>{draft.revision ? t("სტრატეგიის რედაქტირება") : t("ახალი სტრატეგია")}</h2><p>{t("მკაფიო გეგმა, რომელსაც ყოველი შესვლის წინ შეამოწმებ.")}</p></div><fieldset disabled={busy}><label className="field">{t("სტრატეგიის სახელი ")}<span className="required-mark">*</span><input required maxLength={60} value={draft.name} placeholder={t("მაგ. ჩემი ლონდონის სეტაპი")} onChange={e => change({ name: e.target.value })}/></label><label className="field">{t("აღწერა ")}<span className="optional">{t("არასავალდებულო")}</span><textarea maxLength={2000} value={draft.description} placeholder={t("როდის და რატომ იყენებ ამ სტრატეგიას?")} onChange={e => change({ description: e.target.value })}/></label><div className="checklist-heading"><h3>{t("შესვლამდე შესამოწმებელი პირობები")}</h3><span>{draft.checklist.length} / 16</span></div><p className="section-help">{t("ეს პირობები თრეიდის ფორმაში მოსანიშნად გამოჩნდება.")}</p><ICTSuggestions checklist={draft.checklist} onAdd={suggest} disabled={busy}/><div className="add-condition"><input aria-label={t("ახალი სტრატეგიის პირობა")} maxLength={100} placeholder={t("დაწერე შენი პირობა\u2026")} value={item} onChange={e => setItem(e.target.value)} onKeyDown={e => {
            if (e.key === 'Enter') {
                e.preventDefault();
                addItem();
            }
        }}/><button className="secondary" type="button" disabled={!item.trim() || busy} onClick={addItem}><Plus size={17}/>{t(" დამატება")}</button></div><div className="custom-checklist">{draft.checklist.map((condition, i) => <div key={i}><span>{String(i + 1).padStart(2, '0')}</span><input aria-label={t("პირობა {v0}", { v0: i + 1 })} maxLength={100} required value={condition} onChange={e => change({ checklist: draft.checklist.map((v, j) => i === j ? e.target.value : v) })}/><button type="button" className="icon-button danger" aria-label={t("პირობა {v0} წაშლა", { v0: i + 1 })} onClick={() => change({ checklist: draft.checklist.filter((_, j) => j !== i) })}><Trash2 size={16}/></button></div>)}</div>{!draft.checklist.length && <div className="checklist-empty"><Target size={22}/><p>{t("დაამატე შენი წესები, ან შეინახე მხოლოდ სტრატეგიის სახელი.")}</p></div>}</fieldset>{error && <p className="form-error" role="alert">{t(error)}</p>}{saved && <p className="saved-inline" role="status"><Check size={15}/>{t(" სტრატეგია შენახულია.")}</p>}<div className="form-actions">{draft.revision > 0 && <button type="button" className="secondary danger-text" disabled={busy} onClick={remove}><Trash2 size={15}/>{t(" წაშლა")}</button>}<button className="primary" disabled={busy}><Save size={16}/>{busy ? t("ინახება\u2026") : draft.revision ? t("ცვლილებების შენახვა") : t("სტრატეგიის შექმნა")}</button></div></form></section>;
}
const accountTypes = [{ type: 'Live', icon: Wallet, label: 'რეალური', hint: 'Live account' }, { type: 'Demo', icon: FlaskConical, label: 'დემო', hint: 'Practice account' }, { type: 'Backtesting', icon: History, label: 'ბექტესტინგი', hint: 'Historical testing' }, { type:'Challenge',icon:Target,label:'Challenge',hint:'Evaluation account' }, { type: 'Funded', icon: ShieldCheck, label: 'ფანდედი', hint: 'Funded account' }, { type: 'Paper Trading', icon: FileText, label: 'Paper Trading', hint: 'Simulated trading' }] as const;
export function AccountEditor({ account, hasTrades, onSave, onCancel }: {
    account: Account | null;
    hasTrades: boolean;
    onSave: (account: Account) => Promise<void>;
    onCancel: () => void;
}) {
    const { t: tLabel, language, locale } = useLanguage();
    const [draft, setDraft] = useState<Account>(() => account ?? { id: crypto.randomUUID(), revision: 0, name: '', type: 'Demo', currency: 'USD', startingBalance: null, description: '' }), [balance, setBalance] = useState(account?.startingBalance?.toString() ?? ''), [busy, setBusy] = useState(false), [error, setError] = useState('');
    const patch = (value: Partial<Account>) => setDraft(d => ({ ...d, ...value }));
    async function submit(e: FormEvent) {
        e.preventDefault();
        const parsed = accountSchema.safeParse({ ...draft, startingBalance: balance === '' ? null : Number(balance) });
        if (!parsed.success) {
            setError(parsed.error.issues[0].message);
            return;
        }
        setBusy(true);
        setError('');
        try {
            await onSave(parsed.data);
        }
        catch (e) {
            setError((e as Error).message);
        }
        finally {
            setBusy(false);
        }
    }
    return <form className="account-editor" onSubmit={submit}><fieldset disabled={busy}><span className="field">{tLabel("ანგარიშის ტიპი")}</span><div className="account-types">{accountTypes.map(t => <button type="button" key={t.type} className={draft.type === t.type ? 'selected' : ''} aria-pressed={draft.type === t.type} onClick={() => patch({ type: t.type })}><t.icon size={23}/><strong>{tLabel(t.label)}</strong><small>{tLabel(t.hint)}</small>{draft.type === t.type && <Check className="type-check" size={15}/>}</button>)}</div><div className="form-grid"><label className="field full">{tLabel("ანგარიშის სახელი")}<input required maxLength={60} placeholder={tLabel("მაგ. Lucid \u2014 ფანდედი")} value={draft.name} onChange={e => patch({ name: e.target.value })}/></label><label className="field">{tLabel("ვალუტა")}<select disabled={hasTrades} value={draft.currency} onChange={e => patch({ currency: e.target.value as Account['currency'] })}>{['USD', 'EUR', 'GBP', 'GEL'].map(c => <option key={c}>{c}</option>)}</select>{hasTrades && <small>{tLabel("ვალუტა ჩაწერილ თრეიდებს ემთხვევა.")}</small>}</label><label className="field">{tLabel("საწყისი ბალანსი")}<input type="number" required={draft.id !== 'default'} min="0" max="10000000000" step="0.01" placeholder={tLabel("მაგ. 10000")} value={balance} onChange={e => setBalance(e.target.value)}/><small>{tLabel("ჟურნალის დაწყებისას არსებული ბალანსი.")}</small></label><label className="field full">{tLabel("აღწერა ")}<span className="optional">{tLabel("არასავალდებულო")}</span><textarea maxLength={1000} placeholder={tLabel("მიზანი, ზომა, ანგარიშის დეტალები\u2026")} value={draft.description} onChange={e => patch({ description: e.target.value })}/></label></div><div className="account-preview"><span className="account-icon"><Wallet size={22}/></span><div><strong>{draft.name || tLabel("ჩემი ანგარიში")}</strong><small>{tLabel(draft.type)} · {draft.currency}</small></div><b>{balance === '' ? '—' : money(Number(balance) || 0, draft.currency)}</b></div><p className="section-help account-help">{tLabel("ანგარიშის დამატება ქმნის ცალკე ჟურნალს. თრეიდები და სტატისტიკა არჩეული ანგარიშის მიხედვით გამოჩნდება.")}</p></fieldset>{error && <p className="form-error" role="alert">{tLabel(error)}</p>}<div className="form-actions"><button type="button" className="secondary" disabled={busy} onClick={onCancel}>{tLabel("გაუქმება")}</button><button className="primary" disabled={busy}><Save size={16}/>{busy ? tLabel("ინახება\u2026") : account ? tLabel("შენახვა") : tLabel("ანგარიშის შექმნა")}</button></div></form>;
}
