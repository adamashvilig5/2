'use client';
import { useLanguage } from './journal-language';
import { useMemo, useState } from 'react';
import EconomicCalendar,{useEconomicCalendar} from './economic-calendar';
import {CalendarNewsBadge,NewsDayDialog} from './calendar-news-details';
import {economicDay} from '@/lib/economic-news';
import { CalendarDays, ChevronLeft, ChevronRight } from 'lucide-react';
import { money, monthCells, monthSummary, moveMonth, type Trade } from '@/lib/trading';
export default function TradeCalendar({ trades, today, onOpenDay, currency = 'USD', timezone = 'America/New_York' }: {
    trades: Trade[];
    today: string;
    currency?: string;
    timezone?: string;
    onOpenDay: (date: string) => void;
}) {
    const { t, locale } = useLanguage();
    const [newsRange,setNewsRange]=useState<{from:string;to:string}|null>(null);
    const feed=useEconomicCalendar(newsRange?.from,newsRange?.to,timezone,!!newsRange),[newsMode,setNewsMode]=useState(false),[currencies,setCurrencies]=useState(['USD']),[impacts,setImpacts]=useState(['High','Medium','Holiday']);
    const news=useMemo(()=>(newsRange?feed.data?.events??[]:[]).filter(e=>currencies.includes(e.currency)&&impacts.includes(e.impact)),[newsRange,feed.data,currencies,impacts]);
    const [newsDate,setNewsDate]=useState<string|null>(null);
    const cash = (n: number) => money(n, currency);
    const [month, setMonth] = useState(today.slice(0, 7)), [selected, setSelected] = useState<string | null>(today);
    const cells = monthCells(month), summary = monthSummary(trades, month);
    const grouped = useMemo(() => {
        const map = new Map<string, {
            pnl: number;
            count: number;
        }>();
        for (const t of trades) {
            const day = map.get(t.date) ?? { pnl: 0, count: 0 };
            day.pnl += t.pnl;
            day.count++;
            map.set(t.date, day);
        }
        return map;
    }, [trades]);
    const title = new Intl.DateTimeFormat(locale, { month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(month + '-01T00:00:00Z'));
    const changeMonth = (by: number) => { setMonth(m => moveMonth(m, by)); setSelected(null); };
    return <section className="calendar-workspace"><div className="month-toolbar"><div className="month-title"><button className="icon-button" aria-label={t("წინა თვე")} onClick={() => changeMonth(-1)}><ChevronLeft size={20}/></button><CalendarDays size={22}/><h2>{title}</h2><button className="icon-button" aria-label={t("შემდეგი თვე")} onClick={() => changeMonth(1)}><ChevronRight size={20}/></button><button className="calendar-today" onClick={() => { setMonth(today.slice(0, 7)); setSelected(today); }}>{t("დღეს")}</button></div><div className="month-metrics"><span>{t("თრეიდები ")}<b>{summary.count}</b></span><span className={summary.pnl < 0 ? 'negative' : summary.pnl > 0 ? 'positive' : ''}>{t("P&L ")}<b>{cash(summary.pnl)}</b></span><span>{t("WIN ")}<b>{summary.winRate.toFixed(1)}%</b></span></div></div><div className="calendar-news-mode"><div className="segmented"><button className={!newsMode?'active':''} onClick={()=>setNewsMode(false)}>{t('Open trade')}</button><button className={newsMode?'active':''} onClick={()=>setNewsMode(true)}>{t('View day news')}</button></div><span>{t('Choose what clicking a day opens')}</span></div><div className="calendar-scroll"><div className="month-grid"><div className="weekdays">{["კვი", "ორშ", "სამ", "ოთხ", "ხუთ", "პარ", "შაბ"].map((d, i) => <span key={d} className={i === 0 || i === 6 ? 'weekend' : ''}>{t(d)}</span>)}</div><div className="calendar-days">{cells.map(date => {
            const result = grouped.get(date), current = date.startsWith(month), weekend = [0, 6].includes(new Date(date + 'T00:00:00Z').getUTCDay());
            const dayNews=news.filter(e=>economicDay(e,timezone)===date);
            return <div key={date} className="calendar-cell"><button aria-label={t("{v0} \u00B7 {v1}", { v0: date, v1: result ? t("{v0} \u00B7 {v1} {v2}", { v0: cash(result.pnl), v1: result.count, v2: result.count === 1 ? t("თრეიდი") : t("თრეიდები") }) : t("ახალი ჩანაწერის გახსნა") })} aria-pressed={selected === date} className={`calendar-day ${current ? '' : 'outside'} ${date === today ? 'today' : ''} ${selected === date ? 'selected' : ''} ${weekend ? 'weekend' : ''} ${result ? (result.pnl > 0 ? 'has-profit' : result.pnl < 0 ? 'has-loss' : 'has-trades') : ''}`} onClick={() => {
                    setSelected(date);setNewsRange(newsMode?{from:date,to:date}:null);
                    if (!current)
                        setMonth(date.slice(0, 7));
                    if(newsMode)setNewsDate(date);else onOpenDay(date);
                }}><span className="day-number">{Number(date.slice(8))}{date === today && <i />}</span>{result ? <div className="day-result"><strong className={result.pnl < 0 ? 'negative' : result.pnl > 0 ? 'positive' : 'neutral'}>{cash(result.pnl)}</strong><span>{result.count} {result.count === 1 ? t("თრეიდი") : t("თრეიდები")}</span></div> : <span className="day-empty">—</span>}</button>{dayNews.length>0&&<CalendarNewsBadge events={dayNews} timezone={timezone} onOpen={()=>setNewsDate(date)}/>}</div>;
        })}</div></div></div><NewsDayDialog date={newsDate} events={news.filter(e=>economicDay(e,timezone)===newsDate)} timezone={timezone} onClose={()=>setNewsDate(null)}/><EconomicCalendar onRange={setNewsRange} selectedRange={newsRange} feed={feed} timezone={timezone} events={news} currencies={currencies} onCurrencies={setCurrencies} impacts={impacts} onImpacts={setImpacts}/></section>;
}
