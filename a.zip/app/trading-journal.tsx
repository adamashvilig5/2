'use client';
import { useLanguage } from './journal-language';
import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import Link from 'next/link';
import { LayoutDashboard, BookOpen, ChartNoAxesCombined, Plus, LockKeyhole, Wallet, Trophy, Activity, TrendingUp, Settings2, Target, X, Upload, Save, Trash2, Pencil, Image as ImageIcon, Check, Search, ChevronDown, CalendarDays, RefreshCw, AlertCircle, CircleHelp,Heart, Menu, Sparkles, ArrowUpRight } from 'lucide-react';
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from '@/components/ui/alert-dialog';
import StatisticsPage from './statistics-page';
import InnerSpace from './inner-space';
import TradePostReview from './trade-post-review';
import ProfileMenu from './profile-menu';
import PortfolioSummary from './portfolio-summary';
import {ALL_ACCOUNTS,accountScope} from '@/lib/portfolio';
import AchievementsPage from './achievements-page';
import AccountSwitcher from './account-switcher';
import JournalDatePicker from './journal-date-picker';
import JournalTimePicker, { TimeFormatSelector } from './journal-time-picker';
import type { TimeFormat } from '@/lib/journal-time';
import { ThemeToggle } from './theme-controls';
import type { AchievementProgress, AchievementCategory } from '@/lib/achievements';
import { calendarAction } from '@/lib/advanced-statistics';
import { Checkbox } from '@/components/ui/checkbox';
import { NativeSelect } from '@/components/ui/native-select';
import { StrategyManager, AccountEditor } from './journal-managers';
import TradeCalendar from './trade-calendar';
import { ScreenshotEditor, ScreenshotGallery, type PendingShot } from './screenshot-gallery';
import { PerformanceChart, ScoreChart } from './journal-charts';
import BillingCheckoutDialog from './membership/billing-checkout-dialog';
import type { MembershipState } from './membership/portal';
import { dateSchema, todayIn, periodTrades, openingEquity, stats, equityCurve, groupPerformance, money, ratioText, rulesDefault, MAX_SCREENSHOTS, SYMBOL_OPTIONS, EMOTION_OPTIONS, tradeEmotions, accountTrades, groupStrategies, shiftDate, type Trade, type TradeInput, type TradeReview, type Settings, type Daily, type Shot, type Account, type Strategy } from '@/lib/trading';
import { getProcessQuality,tradeDataStatus } from '@/lib/trade-analytics';
const defaultSettings: Settings = { startingBalance: null, timezone: 'America/New_York', revision: 0 };
type JournalData = {
    trades: Trade[];
    settings: Settings;
    daily: Daily;
    accounts: Account[];
    strategies: Strategy[];
    archivedAccounts: Account[];
};
type TradeDraft = Omit<TradeInput, 'quantity' | 'pnl' | 'risk' | 'tags'> & {
    quantity: string;
    pnl: string;
    risk: string;
    tagsText: string;
    screenshots: Shot[];
};
const newDraft = (date: string, accountId: string): TradeDraft => {let session:TradeInput['session']='New York';try{const saved=localStorage.getItem('trade-journal-default-session');if(['Asia','London','New York','London / New York','Other'].includes(saved??''))session=saved as TradeInput['session'];}catch{}return { id: crypto.randomUUID(), revision: 0, accountId: accountId as TradeInput['accountId'], strategyId: null, strategySnapshot: null, symbol: 'MNQ', emotions: ['დისციპლინა'], strategyChecks: [], side: 'Buy', result: 'Win', quantity: '1', pnl: '', risk: '', date, entryTime: '09:30', exitTime: '10:00', session, emotion: 'დისციპლინა', tagsText: '', notes: '', screenshots: [] };};
function draftFrom(t: Trade): TradeDraft { return { ...t, quantity: String(t.quantity), pnl: String(t.pnl), risk: String(t.risk), tagsText: t.tags.join(', '), emotions: tradeEmotions(t), strategyChecks: t.strategyChecks ?? [] }; }
function dashboardSeries(points:{date:string;equity:number;pnl:number;winRate:number}[],trades:Trade[]){const counts=new Map<string,number>();for(const trade of trades)counts.set(trade.date,(counts.get(trade.date)??0)+1);let peak=-Infinity;return points.map((point,index)=>{peak=Math.max(peak,point.equity);const sample=points.slice(Math.max(0,index-6),index+1);return {...point,benchmark:sample.reduce((sum,item)=>sum+item.equity,0)/sample.length,drawdown:peak>0?Math.max(0,(peak-point.equity)/peak*100):0,trades:counts.get(point.date)??0};});}
async function api<T>(url: string, init?: RequestInit): Promise<T> {
    const res = await fetch(url, { cache: 'no-store', ...init });
    const data = await res.json() as T & {
        error?: string;
    };
    if (!res.ok)
        throw new Error(data.error ?? 'მოთხოვნა ვერ შესრულდა. სცადე თავიდან.');
    return data;
}
const put = (body: unknown): RequestInit => ({ method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
function Modal({ title, subtitle, onClose, children, wide = false }: {
    title: string;
    subtitle?: string;
    onClose: () => void;
    children: ReactNode;
    wide?: boolean;
}) {
    const { t: tr, language, locale } = useLanguage();
    const ref = useRef<HTMLDivElement>(null), returnFocus = useRef<HTMLElement | null>(null);
    useEffect(() => {
        returnFocus.current = document.activeElement as HTMLElement;
        const previous = document.body.style.overflow;
        document.body.style.overflow = 'hidden';
        ref.current?.querySelector<HTMLElement>('button,input,select,textarea')?.focus();
        const key = (e: KeyboardEvent) => {
            if (e.key === 'Escape') {
                if (document.querySelector('[data-journal-date-popover],[data-journal-picker-popover]'))
                    return;
                e.preventDefault();
                onClose();
            }
            if (e.key === 'Tab') {
                if (!ref.current?.contains(e.target as Node))
                    return;
                const fields = ref.current?.querySelectorAll<HTMLElement>('button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex="0"]');
                if (!fields?.length)
                    return;
                const first = fields[0], last = fields[fields.length - 1];
                if (e.shiftKey && document.activeElement === first) {
                    e.preventDefault();
                    last.focus();
                }
                else if (!e.shiftKey && document.activeElement === last) {
                    e.preventDefault();
                    first.focus();
                }
            }
        };
        document.addEventListener('keydown', key);
        return () => { document.body.style.overflow = previous; document.removeEventListener('keydown', key); returnFocus.current?.focus(); };
    }, [onClose]);
    return <div className="modal-backdrop"><div ref={ref} className={`modal ${wide ? 'wide' : ''}`} role="dialog" aria-modal="true" aria-label={title}><div className="modal-head"><div><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div><button className="icon-button" aria-label={tr("დახურვა")} onClick={onClose}><X size={21}/></button></div>{children}</div></div>;
}
export default function TradingJournal() {
    const { t: tr, language, locale } = useLanguage();
    const [data, setData] = useState<JournalData | null>(null), [loading, setLoading] = useState(true), [loadError, setLoadError] = useState(''), [error, setError] = useState(''), [status, setStatus] = useState('');
    const [page, setPage] = useState<'dashboard' | 'journal' | 'analysis' | 'calendar' | 'strategies' | 'achievements' | 'inner'>('dashboard'), [days, setDays] = useState(30), [chartMode, setChartMode] = useState<'equity' | 'pnl' | 'winRate' | 'drawdown' | 'trades'>('equity');
    const [focusInitialStep, setFocusInitialStep] = useState<'check'|'session'|'review'|'analytics'>('check');
    const [sidebarOpen, setSidebarOpen] = useState(false);
    useEffect(()=>{if(!sidebarOpen)return;const drawer=document.querySelector<HTMLElement>('.workspace-rail.is-open'),trigger=document.querySelector<HTMLElement>('.workspace-menu-toggle'),items=drawer?.querySelectorAll<HTMLElement>('button:not(:disabled),a[href],select,input');items?.[0]?.focus();const handle=(event:KeyboardEvent)=>{if(event.key==='Escape'){setSidebarOpen(false);return;}if(event.key==='Tab'&&items?.length){const first=items[0],last=items[items.length-1];if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}};document.addEventListener('keydown',handle);return()=>{document.removeEventListener('keydown',handle);trigger?.focus();};},[sidebarOpen]);
    const [form, setForm] = useState<TradeDraft | null>(null), [formError, setFormError] = useState(''), [busy, setBusy] = useState(false), [files, setFiles] = useState<PendingShot[]>([]), [removals, setRemovals] = useState<string[]>([]);
    const [review, setReview] = useState<Trade | null>(null), [justSavedTradeId,setJustSavedTradeId]=useState<string|null>(null), [reviewCheckoutPending, setReviewCheckoutPending] = useState(false), [reviewReadiness, setReviewReadiness] = useState<number|null>(null), [reviewPlannedRisk, setReviewPlannedRisk] = useState<number|null>(null), [settingsOpen, setSettingsOpen] = useState(false), [balance, setBalance] = useState(''), [timezone, setTimezone] = useState('America/New_York');
    const [daily, setDaily] = useState<Daily | null>(null), [dailySaved, setDailySaved] = useState(''), [dailyDate, setDailyDate] = useState(todayIn()), [dailyBusy, setDailyBusy] = useState(false), [dailyError, setDailyError] = useState('');
    const [accountId, setAccountId] = useState<string>(ALL_ACCOUNTS), [accountModal, setAccountModal] = useState<{
        account: Account | null;
    } | null>(null), [strategyOpen, setStrategyOpen] = useState(false);
    const [accountPurge,setAccountPurge]=useState<Account|null>(null);
    const [accountDelete, setAccountDelete] = useState<Account | null>(null), [deleteError, setDeleteError] = useState(''), [archiveOpen, setArchiveOpen] = useState(false), [tradeList, setTradeList] = useState<{
        title: string;
        rows: Trade[];
        date?: string;
    } | null>(null);
    const [search, setSearch] = useState(''), [resultFilter, setResultFilter] = useState('All'),[incompleteOnly,setIncompleteOnly]=useState(false);
    const [achievements, setAchievements] = useState<AchievementProgress | null>(null), [achievementBusy, setAchievementBusy] = useState(false), [achievementError, setAchievementError] = useState(''), [achievementNotice, setAchievementNotice] = useState<{
        xp: number;
        count: number;
    } | null>(null);
    const [portfolioCurrency,setPortfolioCurrency]=useState('USD'),[balancesOpen,setBalancesOpen]=useState(false),[balanceHelpOpen,setBalanceHelpOpen]=useState(false);
    const [timeFormat,setTimeFormat]=useState<TimeFormat>('24h');
    const [membership,setMembership]=useState<MembershipState|null>(null),[upgradeOpen,setUpgradeOpen]=useState(false),[upgradeBusy,setUpgradeBusy]=useState(false),[upgradeConsent,setUpgradeConsent]=useState(false),[upgradeError,setUpgradeError]=useState('');
    useEffect(()=>{let live=true;fetch('/api/membership',{cache:'no-store'}).then(r=>r.ok?r.json() as Promise<MembershipState>:null).then(v=>{if(live&&v){setMembership(v);if(v.member&&v.subscription?.status==='demo_used'){setUpgradeConsent(false);setUpgradeError('');setUpgradeOpen(true);}}}).catch(()=>{});return()=>{live=false;};},[]);
    useEffect(()=>{try{const saved=localStorage.getItem('trading-journal-time-format');if(saved==='12h'||saved==='24h')setTimeFormat(saved);}catch{}},[]);
    useEffect(()=>{const timer=window.setTimeout(()=>{if(new URLSearchParams(window.location.search).get('review')==='incomplete'){setIncompleteOnly(true);setPage('journal');}},0);return()=>window.clearTimeout(timer);},[]);
    function changeTimeFormat(format:TimeFormat){setTimeFormat(format);try{localStorage.setItem('trading-journal-time-format',format);}catch{}}
    const innerDirty=useRef(false);
    const recordInnerDirty=useMemo(()=>((dirty:boolean)=>{innerDirty.current=dirty;}),[]);
    const achievementRequest = useRef(0);
    const strategyDirty = useRef(false), formStrategyDirty = useRef(false), loaded = useRef(false), formRef = useRef(form), busyRef = useRef(busy);
    formRef.current = form;
    busyRef.current = busy;
    const settings=data?.settings??defaultSettings,today=todayIn(settings.timezone),accounts=data?.accounts??[],strategies=data?.strategies??[];
    const scope=accountScope((data?.trades??[]).filter(row=>row.date<=today),accounts,accountId,portfolioCurrency),isPortfolio=scope.portfolio,activeAccount=scope.active,trades=scope.trades,startingBalance=scope.startingBalance,currency=scope.currency,cash=(n:number)=>money(n,currency);
    const scopeName=isPortfolio?tr('All accounts'):activeAccount?.name??tr('პირადი სივრცე');
    const rangeStart=days?shiftDate(today,1-days):(trades.map(row=>row.date).sort()[0]??today);
    function editBalance(){if(activeAccount)setAccountModal({account:activeAccount});else setBalancesOpen(true);}

    async function submitUpgrade(action:'pay'|'fail'){
        if(!membership?.subscription)return;
        setUpgradeBusy(true);setUpgradeError('');
        try{
            const response=await fetch('/api/membership',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,revision:membership.subscription.revision,requestId:crypto.randomUUID()})}),value=await response.json() as {error?:string};
            if(!response.ok)throw Error(value.error||'Checkout could not be completed.');
            if(action==='fail'){setUpgradeError('The test payment failed. No charge was made.');return;}
            const refreshed=await fetch('/api/membership',{cache:'no-store'}),state=await refreshed.json() as MembershipState;
            if(!refreshed.ok)throw Error('Could not verify your updated plan.');
            setMembership(state);setUpgradeOpen(false);setUpgradeConsent(false);window.location.assign('/journal');
        }catch(reason){setUpgradeError(reason instanceof Error?reason.message:'Checkout could not be completed.');}
        finally{setUpgradeBusy(false);}
    }

    const visible = useMemo(() => days === 0 ? trades.filter(t => t.date <= today) : periodTrades(trades, days, today), [trades, days, today]);
    const opening = days === 0 ? startingBalance : openingEquity(trades, days, today, startingBalance), metrics = stats(visible, opening);
    const chartDays = days || Math.max(1, Math.ceil((Date.parse(today) - Date.parse(trades.filter(t => t.date <= today).map(t => t.date).sort()[0] ?? today)) / 86400000) + 1);
    const curve = useMemo(() => equityCurve(trades, chartDays, today, startingBalance), [trades, chartDays, today, startingBalance]);
    const journalRows = visible.filter(t => (!incompleteOnly||tradeDataStatus(t)!=='Complete')&&(!search || [t.symbol, t.strategySnapshot?.name ?? '', ...t.tags, ...tradeEmotions(t), ...tradeEmotions(t).map(emotion => EMOTION_OPTIONS.includes(emotion) ? tr(emotion) : emotion)].join(' ').toLowerCase().includes(search.toLowerCase())) && (resultFilter === 'All' || t.result === resultFilter)).sort((a, b) => (b.date + b.entryTime).localeCompare(a.date + a.entryTime));
    const recentHighlights = [...trades].sort((a,b)=>(b.date+b.entryTime).localeCompare(a.date+a.entryTime)).slice(0,8);
    const chartData=useMemo(()=>dashboardSeries(curve,visible),[curve,visible]);
    const sparkData=chartData.slice(-14),sparkValues=sparkData.map(point=>point.equity),sparkMin=Math.min(...sparkValues,0),sparkMax=Math.max(...sparkValues,1),sparkPath=sparkValues.map((value,index)=>`${index?'L':'M'} ${(index/(Math.max(1,sparkValues.length-1)))*100} ${28-((value-sparkMin)/(sparkMax-sparkMin||1))*24}`).join(' ');
    const activityBars=chartData.slice(-12).map(point=>point.trades),activityMax=Math.max(...activityBars,1),avgComparisonMax=Math.max(metrics.avgWin,metrics.avgLoss,1);
    const sessionSummary=useMemo(()=>{const map=new Map<string,{pnl:number;wins:number;losses:number;count:number}>();for(const trade of visible){const row=map.get(trade.session)??{pnl:0,wins:0,losses:0,count:0};row.pnl+=trade.pnl;row.wins+=trade.pnl>0?1:0;row.losses+=trade.pnl<0?1:0;row.count++;map.set(trade.session,row);}return [...map.entries()].map(([name,value])=>({name,...value})).sort((a,b)=>b.pnl-a.pnl);},[visible]);
    const bestSession=sessionSummary[0],shortSummary=visible.filter(trade=>trade.side==='Sell').reduce((total,trade)=>total+trade.pnl,0),avgRisk=visible.length?visible.reduce((total,trade)=>total+trade.risk,0)/visible.length:0;
    const dailyDirty = daily !== null && JSON.stringify(daily) !== dailySaved;
    async function refreshAchievements(announce = true) {
        const request = ++achievementRequest.current;
        setAchievementBusy(true);
        setAchievementError('');
        try {
            const result = await api<{
                progress: AchievementProgress;
                newAwards: {
                    id: string;
                    title: string;
                    xp: number;
                }[];
            }>('/api/achievements', { method: 'POST' });
            if (request === achievementRequest.current) {
                setAchievements(result.progress);
                if (announce && result.newAwards.length)
                    setAchievementNotice({ xp: result.newAwards.reduce((sum, a) => sum + a.xp, 0), count: result.newAwards.length });
            }
        }
        catch (e) {
            if (request === achievementRequest.current)
                setAchievementError((e as Error).message);
        }
        finally {
            if (request === achievementRequest.current)
                setAchievementBusy(false);
        }
    }
    async function load() {
        setLoading(true);
        setLoadError('');
        try {
            const result = await api<JournalData>('/api/journal?date=' + dailyDate);
            setData(result);
            let last: string | null = null;
            try {
                last = localStorage.getItem('trade-journal-account');
            }
            catch { }
            setAccountId(current => (last??current)===ALL_ACCOUNTS||result.accounts.some(a=>a.id===(last??current))?(last??current):ALL_ACCOUNTS);
            setDaily(result.daily);
            setDailySaved(JSON.stringify(result.daily));
            setBalance(result.settings.startingBalance?.toString() ?? '');
            setTimezone(result.settings.timezone);
            void refreshAchievements(false);
        }
        catch (e) {
            setLoadError((e as Error).message);
        }
        finally {
            setLoading(false);
        }
    }
    useEffect(() => {
        if (!loaded.current) {
            loaded.current = true;
            void load();
        }
    }, []);
    useEffect(() => {
        const warn = (e: BeforeUnloadEvent) => {
            if (form || dailyDirty || strategyDirty.current || formStrategyDirty.current || innerDirty.current) {
                e.preventDefault();
                e.returnValue = '';
            }
        };
        window.addEventListener('beforeunload', warn);
        return () => window.removeEventListener('beforeunload', warn);
    }, [form, dailyDirty]);
    const closeForm = useMemo(() => () => {
        if (busyRef.current)
            return;
        if (!formRef.current || window.confirm(tr("დახურავ ფორმას? შეუნახავი ცვლილებები დაიკარგება."))) {
            setForm(null);
            setFormError('');
        }
    }, [tr]);
    const closeSettings = useMemo(() => () => {
        if (!busyRef.current)
            setSettingsOpen(false);
    }, []);
    const closeReview = useMemo(() => () => { setReview(null);setJustSavedTradeId(null); if(reviewCheckoutPending){setReviewCheckoutPending(false);setUpgradeConsent(false);setUpgradeError('');setUpgradeOpen(true);} }, [reviewCheckoutPending]);
    function openTrade(t?: Trade, date = today) {
        if(!t&&membership?.subscription&&['demo','demo_used'].includes(membership.subscription.status)&&(membership.subscription.status==='demo_used'||(data?.trades.length??0)>=1)){
            setUpgradeError('');setUpgradeConsent(false);setUpgradeOpen(true);return;
        }
        if (!accounts.length) {
            setAccountModal({ account: null });
            return;
        }
        setForm(t ? draftFrom(t) : newDraft(date,activeAccount?.id??scope.accounts[0]?.id??accounts[0].id));
        setFiles([]);
        setRemovals([]);
        setFormError('');
        setReview(null);
        setTradeList(null);
        setError('');
        setStatus('');
    }
    function change<K extends keyof TradeDraft>(key: K, value: TradeDraft[K]) { setForm(f => f ? { ...f, [key]: value } : f); setFormError(''); }
    async function saveTrade(e: FormEvent) {
        e.preventDefault();
        if (!form)
            return;
        setBusy(true);
        setFormError('');
        let saved = false;
        let current: Trade | null = null;
        try {
            const { quantity, pnl, risk, tagsText, screenshots, ...base } = form;
            if (!form.emotions?.length)
                throw new Error(tr("მონიშნე მინიმუმ ერთი ემოცია."));
            const tags = form.strategyId && form.strategySnapshot ? [form.strategySnapshot.name] : [...new Set(tagsText.split(',').map(t => t.trim()).filter(Boolean))];
            let focusSnapshot: { readiness?: number; riskLimit?: number; dailyLossLimit?: number; maxTrades?: number } | null = null;
            if(!form.revision)try{focusSnapshot=JSON.parse(localStorage.getItem(`trader-focus-v2:${form.date}`)??'null') as { readiness?: number; riskLimit?: number; dailyLossLimit?: number; maxTrades?: number } | null;}catch{}
            const preTradeReadinessScore=form.preTradeReadinessScore??(typeof focusSnapshot?.readiness==='number'&&focusSnapshot.readiness>0?focusSnapshot.readiness:undefined);
            const riskPlan={...(form.riskPlan??{}),...(typeof focusSnapshot?.riskLimit==='number'?{plannedRiskPercent:focusSnapshot.riskLimit}:{}),...(typeof focusSnapshot?.dailyLossLimit==='number'?{dailyLossLimit:focusSnapshot.dailyLossLimit}:{}),...(typeof focusSnapshot?.maxTrades==='number'?{maximumTrades:focusSnapshot.maxTrades}:{})};
            const result = await api<{
                trade: Trade;
            }>('/api/trades', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...base, ...(preTradeReadinessScore===undefined?{}:{preTradeReadinessScore}), ...(Object.keys(riskPlan).length?{riskPlan}:{}), emotion: form.emotions![0], quantity: Number(quantity), pnl: Number(pnl), risk: Number(risk), tags }) });
            current = { ...result.trade, screenshots };
            saved = true;
            setForm(f => f ? { ...f, revision: current!.revision } : f);
            setData(d => d ? { ...d, trades: [current!, ...d.trades.filter(t => t.id !== current!.id)] } : d);
            for (const shot of [...current.screenshots].filter(s => removals.includes(s.id))) {
                await api('/api/screenshots/' + shot.id, { method: 'DELETE' });
                current.screenshots = current.screenshots.filter(s => s.id !== shot.id);
                setRemovals(r => r.filter(id => id !== shot.id));
                setForm(f => f ? { ...f, screenshots: current!.screenshots } : f);
            }
            for (const photo of files) {
                const fd = new FormData();
                fd.set('tradeId', current.id);
                fd.set('phase', photo.phase);
                fd.set('id', photo.id);
                fd.set('file', photo.file);
                const uploaded = await api<{
                    screenshot: Shot;
                }>('/api/screenshots', { method: 'POST', body: fd });
                current.screenshots = [...current.screenshots.filter(s => s.id !== uploaded.screenshot.id), uploaded.screenshot];
                setFiles(f => f.filter(p => p.id !== photo.id));
                setForm(f => f ? { ...f, screenshots: current!.screenshots } : f);
            }
            setData(d => d ? { ...d, trades: [current!, ...d.trades.filter(t => t.id !== current!.id)] } : d);
            setJustSavedTradeId(current.id);
            setForm(null);
            if(!form.revision){
                setReviewReadiness(typeof focusSnapshot?.readiness==='number'&&focusSnapshot.readiness>0?focusSnapshot.readiness:null);
                setReviewPlannedRisk(typeof focusSnapshot?.riskLimit==='number'?focusSnapshot.riskLimit:null);
                setReview(current);setReviewCheckoutPending(membership?.subscription?.status==='demo');
            }
            if(current?.accountId&&!isPortfolio)chooseAccount(current.accountId);
            else if(current?.accountId)setPortfolioCurrency(accounts.find(a=>a.id===current!.accountId)?.currency??currency);
            setStatus('This trade is now included in Statistics and Insights.');
            if(!form.revision&&membership?.subscription?.status==='demo'){
                setMembership(current=>current?.subscription?{...current,subscription:{...current.subscription,status:'demo_used',revision:current.subscription.revision+1}}:current);
            }
        }
        catch (e) {
            setFormError((saved ? tr("თრეიდი შენახულია, მაგრამ სქრინშოტების განახლება ვერ დასრულდა. კვლავ დააჭირე შენახვას. ") : '') + (e as Error).message);
            if((e as Error).message.includes('Demo includes one saved trade')){setUpgradeConsent(false);setUpgradeError('');setUpgradeOpen(true);}
            if (current)
                setData(d => d ? { ...d, trades: [current!, ...d.trades.filter(t => t.id !== current!.id)] } : d);
        }
        finally {
            setBusy(false);
            if (saved)
                void refreshAchievements();
        }
    }
    async function deleteTrade(t: Trade) {
        if (!window.confirm(tr("{v0} \u2014 {v1}: ნამდვილად წაშლი ამ თრეიდსა და სქრინშოტებს?", { v0: t.symbol, v1: t.date })))
            return;
        setBusy(true);
        setError('');
        try {
            await api('/api/trades/' + t.id, { method: 'DELETE' });
            setData(d => d ? { ...d, trades: d.trades.filter(x => x.id !== t.id) } : d);
            setReview(null);
            setStatus(tr("თრეიდი წაშლილია."));
            void refreshAchievements(false);
        }
        catch (e) {
            setError((e as Error).message);
        }
        finally {
            setBusy(false);
        }
    }
    async function saveTradeReview(value: TradeReview) {
        if(!review) return;
        const result=await api<{trade:Trade}>(`/api/trades/${review.id}/review`,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(value)});
        const savedTrade={...result.trade,screenshots:review.screenshots};
        setReview(savedTrade);
        setData(current=>current?{...current,trades:current.trades.map(trade=>trade.id===savedTrade.id?{...trade,...savedTrade}:trade)}:current);
        setJustSavedTradeId(savedTrade.id);
        setStatus('This trade is now included in Statistics and Insights.');
        void refreshAchievements();
        if(reviewCheckoutPending){setReview(null);setReviewCheckoutPending(false);setUpgradeConsent(false);setUpgradeError('');setUpgradeOpen(true);}
    }
    async function saveSettings(e: FormEvent) {
        e.preventDefault();
        setBusy(true);
        setError('');
        try {
            const result = await api<{
                settings: Settings;
            }>('/api/settings', put({ startingBalance: settings.startingBalance, timezone, revision: settings.revision }));
            setData(d => d ? { ...d, settings: result.settings } : d);
            setSettingsOpen(false);
            setStatus(tr("პარამეტრები შენახულია."));
        }
        catch (e) {
            setError((e as Error).message);
        }
        finally {
            setBusy(false);
        }
    }
    async function switchDay(next: string) {
        if (!dateSchema.safeParse(next).success)
            return;
        if (dailyDirty && !window.confirm(tr("დღის გეგმაში შეუნახავი ცვლილებებია. გადახვალ სხვა დღეზე?")))
            return;
        setDailyBusy(true);
        setDailyError('');
        try {
            const result = await api<JournalData>('/api/journal?date=' + next);
            setDaily(result.daily);
            setDailySaved(JSON.stringify(result.daily));
            setDailyDate(next);
        }
        catch (e) {
            setDailyError((e as Error).message);
        }
        finally {
            setDailyBusy(false);
        }
    }
    async function saveDay() {
        if (!daily)
            return;
        setDailyBusy(true);
        setDailyError('');
        try {
            const result = await api<{
                daily: Daily;
            }>('/api/daily', put(daily));
            setDaily(result.daily);
            setDailySaved(JSON.stringify(result.daily));
            setStatus(tr("დღის მიზნები შენახულია."));
            void refreshAchievements();
        }
        catch (e) {
            setDailyError((e as Error).message);
        }
        finally {
            setDailyBusy(false);
        }
    }
    function addPhotos(incoming: File[], phase: Shot['phase']) {
        if (busy || !form)
            return;
        const available = MAX_SCREENSHOTS - form.screenshots.filter(s => !removals.includes(s.id)).length - files.length;
        const valid = incoming.filter(f => f.size > 0 && f.size <= 8 * 1024 * 1024 && ['image/png', 'image/jpeg', 'image/webp'].includes(f.type));
        const accepted = valid.slice(0, Math.max(0, available));
        setFiles(f => [...f, ...accepted.map(file => ({ id: crypto.randomUUID(), file, phase }))]);
        if (valid.length < incoming.length)
            setFormError(tr("ზოგი ფოტო ვერ დაემატა. დასაშვებია PNG, JPG ან WebP, მაქსიმუმ 8 MB."));
        else if (valid.length > available)
            setFormError(tr("თითო თრეიდზე მაქსიმუმ {v0} ფოტო ინახება. ზედმეტი ფოტოები არ დაემატა.", { v0: MAX_SCREENSHOTS }));
        else
            setFormError('');
    }
    function toggleChoice(key: 'emotions' | 'strategyChecks', value: string) {
        if (!form)
            return;
        const selected = key === 'emotions' ? (form.emotions ?? tradeEmotions(form)) : (form.strategyChecks ?? []);
        change(key, selected.includes(value) ? selected.filter(v => v !== value) : [...selected, value]);
    }
    function chooseStrategy(strategy: Strategy) {
        if (!form)
            return;
        if (form.strategyId === strategy.id) {
            setForm({ ...form, strategyId: null, strategySnapshot: null, strategyChecks: [], tagsText: '' });
            return;
        }
        setForm({ ...form, strategyId: strategy.id, strategySnapshot: { name: strategy.name, checklist: strategy.checklist }, strategyChecks: [], tagsText: strategy.name });
    }
    function navigate(next: typeof page) {
        if (page === 'strategies' && strategyDirty.current && !window.confirm(tr("სტრატეგიას შეუნახავი ცვლილებები აქვს. გადახვალ სხვა გვერდზე?")))
            return;
        if(page==='inner'&&innerDirty.current&&!window.confirm(tr('Discard unsaved Trader Focus changes?')))return;
        setSidebarOpen(false);
        setPage(next);
    }
    function achievementAction(category: AchievementCategory) {
        if (category === 'strategy') {
            navigate('strategies');
            return;
        }
        if (category === 'risk' || category === 'focus' || category === 'discipline') {
            setFocusInitialStep(category === 'risk' ? 'session' : category === 'discipline' ? 'review' : 'check');
            navigate('inner');
            return;
        }
        if (category === 'consistency') {
            navigate('dashboard');
            requestAnimationFrame(() => document.querySelector('.daily-panel')?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
            return;
        }
        navigate(category === 'journal' ? 'journal' : 'inner');
    }
    function closeStrategyManager() {
        if (busyRef.current)
            return;
        if (formStrategyDirty.current && !window.confirm(tr("სტრატეგიას შეუნახავი ცვლილებები აქვს. დაბრუნდები თრეიდზე?")))
            return;
        setStrategyOpen(false);
    }
    const recordStrategyDirty = useMemo(() => ((dirty: boolean) => { strategyDirty.current = dirty; }), []), recordFormStrategyDirty = useMemo(() => ((dirty: boolean) => { formStrategyDirty.current = dirty; }), []);
    function chooseAccount(id: string) {
        setAccountId(id);
        setReview(null);
        setTradeList(null);
        setSearch('');
        setStatus('');
        try {
            localStorage.setItem('trade-journal-account', id);
        }
        catch { }
    }
    function openCalendarDay(date: string) {
        const action = calendarAction(trades, date, today);
        if (action.kind === 'review') {
            setReview(action.rows[0]);
            return;
        }
        if (action.kind === 'new') {
            openTrade(undefined, date);
            return;
        }
        setTradeList({ title: date, rows: action.rows, date });
    }
    function askDeleteAccount(account: Account) { setAccountModal(null); setDeleteError(''); setAccountDelete(account); }
    async function deleteAccount() {
        if (!accountDelete)
            return;
        const account = accountDelete;
        setBusy(true);
        setDeleteError('');
        try {
            const result = await api<{
                revision: number;
            }>('/api/accounts/' + account.id, { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ revision: account.revision }) });
            setData(d => d ? { ...d, accounts: d.accounts.filter(a => a.id !== account.id), archivedAccounts: [...d.archivedAccounts, { ...account, revision: result.revision }] } : d);
            if (activeAccount?.id === account.id)
                chooseAccount(ALL_ACCOUNTS);
            setAccountDelete(null);
            setStatus(tr("ანგარიში წაშლილია. მისი აღდგენა შეგიძლია წაშლილი ანგარიშების სიიდან."));
        }
        catch (e) {
            setDeleteError((e as Error).message);
        }
        finally {
            setBusy(false);
        }
    }
    async function permanentlyDeleteAccount(){
        if(!accountPurge)return;
        const account=accountPurge;setBusy(true);setDeleteError('');
        try{
            await api('/api/accounts/'+account.id+'/purge',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({revision:account.revision,confirm:true})});
            setData(d=>d?{...d,archivedAccounts:d.archivedAccounts.filter(a=>a.id!==account.id),trades:d.trades.filter(t=>(t.accountId??'default')!==account.id)}:d);
            setReview(null);setTradeList(null);setAccountPurge(null);setArchiveOpen(true);
            setStatus(tr('ანგარიში, მისი თრეიდები და სქრინშოტები საბოლოოდ წაიშალა.'));
        }catch(e){setDeleteError((e as Error).message);}finally{setBusy(false);}
    }
    async function restoreAccount(account: Account) {
        setBusy(true);
        setError('');
        try {
            const result = await api<{
                revision: number;
            }>('/api/accounts/' + account.id, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ revision: account.revision }) });
            setData(d => d ? { ...d, accounts: [...d.accounts, { ...account, revision: result.revision }], archivedAccounts: d.archivedAccounts.filter(a => a.id !== account.id) } : d);
            chooseAccount(account.id);
            setArchiveOpen(false);
            setStatus(tr("ანგარიში და მისი ჩანაწერები აღდგენილია."));
        }
        catch (e) {
            setError((e as Error).message);
        }
        finally {
            setBusy(false);
        }
    }
    async function saveAccount(account: Account) {
        setBusy(true);
        try {
            const result = await api<{
                account: Account;
            }>('/api/accounts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(account) });
            setData(d => d ? { ...d, accounts: [...d.accounts.filter(a => a.id !== result.account.id), result.account] } : d);
            if(!isPortfolio)chooseAccount(result.account.id);else setPortfolioCurrency(result.account.currency);
            setAccountModal(null);
            setStatus(tr("ანგარიში შენახულია."));
        }
        finally {
            setBusy(false);
        }
    }
    async function saveStrategy(strategy: Strategy) {
        setBusy(true);
        try {
            const result = await api<{
                strategy: Strategy;
            }>('/api/strategies', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(strategy) });
            setData(d => d ? { ...d, strategies: [...d.strategies.filter(s => s.id !== result.strategy.id), result.strategy] } : d);
            void refreshAchievements();
            return result.strategy;
        }
        finally {
            setBusy(false);
        }
    }
    async function deleteStrategy(strategy: Strategy) {
        setBusy(true);
        try {
            await api('/api/strategies/' + strategy.id, { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ revision: strategy.revision }) });
            setData(d => d ? { ...d, strategies: d.strategies.filter(s => s.id !== strategy.id) } : d);
            setForm(f => f?.revision === 0 && f.strategyId === strategy.id ? { ...f, strategyId: null, strategySnapshot: null, strategyChecks: [], tagsText: '' } : f);
        }
        finally {
            setBusy(false);
        }
    }
    const periodLabel = days === 0 ? tr("ყველა ჩანაწერი") : tr("ბოლო {v0} დღე", { v0: days });
    const quote = ["კარგი თრეიდი იწყება მკაფიო გეგმით.", "შენი მიზანი გეგმის შესრულებაა, შედეგი კი მონაცემებში ჩანს.", "მოთმინება მაშინაც მუშაობს, როცა არ ვაჭრობ.", "ჩაწერე მიზეზი. შეამოწმე შედეგი. გაიმეორე კარგი ჩვევა.", "ერთი თრეიდი არ განსაზღვრავს შენს პროგრესს."][Math.floor(Date.parse(dailyDate) / 86400000) % 5];
    return <div className="journal-app">{sidebarOpen&&<button className="workspace-drawer-scrim" aria-label={tr("Close navigation")} onClick={()=>setSidebarOpen(false)}/>}<aside aria-label={tr("Workspace navigation")} className={`workspace-rail ${sidebarOpen?"is-open":""}`}><div className="rail-label">{tr("YOUR WORKSPACE ")}<span className="live-dot"/></div><button className={`dashboard-nav ${page === 'dashboard' ? 'active' : ''}`} onClick={() => navigate('dashboard')}><LayoutDashboard size={20}/><span>{tr("Dashboard")}<small>{tr("მთავარი გვერდი")}</small></span></button><AccountSwitcher accounts={accounts} trades={data?.trades ?? []} active={activeAccount} portfolio={isPortfolio} currency={currency} archivedCount={data?.archivedAccounts.length ?? 0} busy={busy} ready={!!data} onSelect={chooseAccount} onAdd={() => setAccountModal({ account: null })} onEdit={account => setAccountModal({ account })} onDelete={askDeleteAccount} onArchive={() => { setError(''); setArchiveOpen(true); }}/><div className="rail-section-title"><span>{tr("TOOLS")}</span></div><nav className="rail-nav">{([{ id: 'journal', label: tr("თრეიდების ჟურნალი"), icon: BookOpen }, { id: 'analysis', label: tr("Statistics"), icon: ChartNoAxesCombined }, { id: 'calendar', label: tr("კალენდარი"), icon: CalendarDays }, { id: 'strategies', label: tr("ჩემი სტრატეგიები"), icon: Target }, { id: 'achievements', label: tr("Achievements"), icon: Trophy }, {id:'inner',label:tr('Trader Focus'),icon:Target}] as const).map(n => <button key={n.id} className={page === n.id ? 'active' : ''} onClick={() => navigate(n.id)}><n.icon size={18}/><span>{tr(n.label)}</span>{n.id === 'strategies' && <small>{strategies.length}</small>}</button>)}</nav></aside>
 <div className="journal-main"><header className="topbar"><button className="workspace-menu-toggle" type="button" aria-label={sidebarOpen?tr("Close navigation"):tr("Open navigation")} aria-expanded={sidebarOpen} onClick={()=>setSidebarOpen(value=>!value)}>{sidebarOpen?<X size={19}/>:<Menu size={19}/>}</button><Link className="brand" href="/"><span><ChartNoAxesCombined size={21}/></span><strong>{tr("Trade")}<span>{tr(" Journal")}</span></strong></Link><div className="topbar-context"><label className="topbar-account-select"><Wallet size={14}/><select aria-label={tr("Current trading account")} value={accountId} onChange={event=>chooseAccount(event.target.value)}><option value={ALL_ACCOUNTS}>{tr("All accounts")}</option>{accounts.map(account=><option key={account.id} value={account.id}>{account.name}</option>)}</select><ChevronDown size={13}/></label><button className="header-level" title={tr("მიღწევების გახსნა")} aria-label={tr("მიღწევების და დონის ნახვა")} onClick={() => navigate('achievements')}><Trophy size={15}/><span>{tr("Level ")}{achievements?.level.level ?? 1}</span></button><span className="private-pill"><LockKeyhole size={12}/>{tr(" მხოლოდ შენთვის")}</span><button type="button" className="workspace-notice-button" title={tr("Achievements and milestones")} aria-label={tr("Achievements and milestones")} onClick={()=>navigate('achievements')}><Trophy size={16}/>{achievementNotice&&<i/>}</button><ThemeToggle /><ProfileMenu progress={achievements} onAchievements={() => navigate('achievements')}/></div></header><main>
 {loading ? <div className="loading-state"><RefreshCw size={25}/><p>{tr("ჟურნალი იტვირთება\u2026")}</p></div> : loadError ? <div className="loading-state"><AlertCircle size={28}/><h1>{tr("ჟურნალი ვერ ჩაიტვირთა")}</h1><p>{tr(loadError)}</p><button className="primary" onClick={load}><RefreshCw size={16}/>{tr(" თავიდან ცდა")}</button><a href="/signin-with-chatgpt?return_to=%2F" target="_top">{tr("ChatGPT-ით შესვლა")}</a></div> : <>
 <div className={`page-heading ${page === 'dashboard' ? 'dashboard-heading' : ''}`}><div><div className="eyebrow">{today} · {scopeName}</div><h1>{page === 'dashboard' ? tr("Trading Dashboard") : page === 'journal' ? tr("Trade Journal") : page === 'calendar' ? tr("Trading Calendar") : page === 'strategies' ? tr("Trading Playbook") : page === 'achievements' ? tr("Achievements") : page==='inner'?tr('Trader Focus'):tr("Statistics & Analytics")}</h1><p>{page === 'dashboard' ? tr("ყოველი დღე შენი პროგრესის ნაწილია.") : page === 'journal' ? tr("ჩაწერე თრეიდი. შეინახე კონტექსტი.") : page === 'calendar' ? tr("შედეგები დღეებისა და თვეების მიხედვით.") : page === 'strategies' ? tr("შენი სტრატეგიები, შენივე პირობებით.") : page === 'achievements' ? tr("მიზნები, გამოცდილება და შენი პროგრესი.") : page==='inner'?tr('Your process, mindset, and trading edge.'):tr("იპოვე რა მუშაობს შენთვის.")}</p></div><button className="primary" onClick={() => openTrade()}><Plus size={18}/>{accounts.length?tr("თრეიდის დამატება"):tr("ანგარიშის დამატება")}</button></div>
 {error && <div className="notice error" role="alert"><AlertCircle size={17}/>{tr(error)}</div>}{status && <div className="notice success" role="status"><Check size={16}/>{tr(status)}<button onClick={() => setStatus('')} aria-label={tr("შეტყობინების დახურვა")}><X size={14}/></button></div>}
 {achievementNotice && <div className="notice xp-notice" role="status"><Trophy size={19}/><strong>+{achievementNotice.xp}{tr(" XP")}</strong><span>{achievementNotice.count}{tr(" ახალი მიღწევა გახსნილია.")}</span><button className="inline-link" onClick={() => navigate('achievements')}>{tr("ნახვა")}</button><button aria-label={tr("მიღწევის შეტყობინების დახურვა")} onClick={() => setAchievementNotice(null)}><X size={15}/></button></div>}
 {!accounts.length && page !== 'strategies' && page !== 'achievements' && page!=='inner' ? <section className="panel empty-state"><Wallet size={30}/><h2>{tr("აქტიური სავაჭრო ანგარიში არ გაქვს")}</h2><p>{tr("დაამატე ახალი ანგარიში ან აღადგინე წაშლილი ანგარიში შენახული თრეიდებითა და ფოტოებით.")}</p><div className="empty-account-actions"><button className="primary" onClick={() => setAccountModal({ account: null })}><Plus size={16}/>{tr(" ანგარიშის დამატება")}</button>{!!data?.archivedAccounts.length && <button className="secondary" onClick={() => { setError(''); setArchiveOpen(true); }}><RefreshCw size={16}/>{tr(" ანგარიშის აღდგენა")}</button>}</div></section> : <>
 {page !== 'calendar' && page !== 'strategies' && page !== 'achievements' && page!=='inner' && <div className="range-toolbar"><span><CalendarDays size={15}/>{tr("Period")}</span><div className="segmented">{[{ n: 7, l: '7D' }, { n: 30, l: '30D' }, { n: 90, l: '90D' }, { n: 365, l: '1Y' }, { n: 0, l: tr("All Time") }].map(r => <button key={r.n} aria-pressed={days === r.n} className={days === r.n ? 'active' : ''} onClick={() => setDays(r.n)}>{tr(r.l)}</button>)}</div></div>}
 {isPortfolio&&accounts.length>0&&['dashboard','analysis','journal','calendar'].includes(page)&&<div className="portfolio-scope-bar"><span><Wallet size={17}/>{tr('All accounts')} · {scope.accounts.length} · {currency}</span>{scope.currencies.length>1&&<label>{tr('Currency')}<select value={currency} onChange={e=>setPortfolioCurrency(e.target.value)}>{scope.currencies.map(code=><option key={code} value={code}>{code}</option>)}</select><small>{tr('Amounts are grouped by currency; no exchange rates are assumed.')}</small></label>}</div>}
 {scope.missingBalances.length>0&&['dashboard','analysis'].includes(page)&&<button type="button" className="balance-help-trigger" aria-label={tr('Opening balance help')} title={tr('Opening balance help')} onClick={()=>setBalanceHelpOpen(true)}><CircleHelp size={16}/></button>}
 {page === 'dashboard' && <div className="metrics dashboard-metrics">
  <Metric label={tr("TOTAL P&L")} value={cash(metrics.pnl)} icon={<Wallet size={19}/>} tone={metrics.pnl < 0 ? 'red' : 'green'} detail={metrics.returnPct === null ? <button className="inline-link" onClick={() => editBalance()}>{tr("Set opening equity")}</button> : <span>{metrics.returnPct >= 0 ? '+' : ''}{metrics.returnPct.toFixed(2)}{tr("% in period")}</span>} visual={<div className="metric-visual metric-sparkline"><svg viewBox="0 0 100 30" preserveAspectRatio="none" aria-hidden="true"><path d={sparkPath}/></svg><span>{tr("Recent equity")}</span></div>}/>
  <Metric label={tr("WIN RATE")} value={`${metrics.winRate.toFixed(1)}%`} icon={<Trophy size={19}/>} tone="purple" detail={tr("{v0} wins · {v1} losses · {v2} breakeven", { v0: metrics.wins, v1: metrics.losses, v2: metrics.breakeven })} visual={<div className="metric-visual win-rate-visual"><span className="win-rate-ring" style={{background:`conic-gradient(var(--chart-positive) ${metrics.winRate}%,var(--surface-raised) 0)`}}><i><b>{metrics.winRate.toFixed(0)}%</b></i></span><small>{tr("Win rate")}</small></div>}/>
  <Metric label={tr("TOTAL TRADES")} value={String(metrics.count)} icon={<Activity size={19}/>} tone="cyan" detail={`${periodLabel} · ${visible.filter(t => t.result === 'Partial').length} ${tr("partial")}`} visual={<div className="metric-visual activity-bars" aria-label={tr("Trade activity over time")}>{activityBars.map((count,index)=><i key={index} title={`${count} ${tr("trades")}`} style={{height:`${Math.max(8,count/activityMax*100)}%`}}/>)}</div>}/>
  <Metric label={tr("AVG WIN / LOSS")} value={`${cash(metrics.avgWin)} / ${cash(metrics.avgLoss)}`} icon={<TrendingUp size={19}/>} tone="amber" compact detail={tr("Ratio = {v0}:1", { v0: ratioText(metrics.ratio) })} visual={<div className="metric-visual average-comparison"><span><i className="avg-win-bar" style={{width:`${metrics.avgWin/avgComparisonMax*100}%`}}/><small>{tr("Avg win")}</small></span><span><i className="avg-loss-bar" style={{width:`${metrics.avgLoss/avgComparisonMax*100}%`}}/><small>{tr("Avg loss")}</small></span></div>}/>
 </div>}
 {page === 'dashboard' && <>
 {page === 'dashboard' && !visible.length && <section className="dashboard-first-trade panel"><div className="first-trade-art" aria-hidden="true"><span/><span/><span/><svg viewBox="0 0 330 120"><path d="M5 96 C35 91 42 55 77 70 S119 30 151 52 S191 20 221 40 S261 8 323 18"/></svg></div><div><span className="dashboard-section-kicker">{tr(trades.length ? "A QUIETER PERIOD" : "START WITH ONE TRADE")}</span><h2>{tr(trades.length ? "No trades in this period." : "Your trading story starts with one trade.")}</h2><p>{tr(trades.length ? "Choose a wider time range to see your history, or add a new trade to this period." : "Log a setup, its risk and result. Your calendar and analytics will build from your own records.")}</p><div className="first-trade-actions"><button type="button" className="primary" onClick={()=>openTrade()}><Plus size={16}/>{tr(trades.length ? "Add trade" : "Add your first trade")}</button><button type="button" className="secondary" onClick={()=>window.location.assign('/imports')}><Upload size={16}/>{tr("Import trade history")}</button></div></div></section>}
 <div className="section-heading"><h2>{tr("შედეგები დეტალებში")}</h2><span>{periodLabel}</span></div><div className="charts-grid"><section className="panel"><div className="panel-head"><div className="panel-title"><span className="head-icon purple"><TrendingUp size={19}/></span><div><h2>{tr("Performance Overview")}</h2><p>{startingBalance === null ? tr("კუმულაციური P&L \u00B7 {v0}", { v0: currency }) : tr("კაპიტალი \u00B7 {v0}", { v0: currency })} · {periodLabel}</p></div></div><div className="segmented chart-tabs">{[{ m: 'equity', l: tr("Equity") }, { m: 'pnl', l: tr("Daily P&L") }, { m: 'winRate', l: tr("Win rate") }, { m: 'drawdown', l: tr("Drawdown") }, { m: 'trades', l: tr("Trades") }].map(v => <button key={v.m} className={chartMode === v.m ? 'active' : ''} aria-pressed={chartMode === v.m} onClick={() => setChartMode(v.m as typeof chartMode)}>{tr(v.l)}</button>)}</div></div><PerformanceChart data={chartData} mode={chartMode} currency={currency} animated/>{!visible.length && <div className="chart-empty">{tr("ამ პერიოდში თრეიდები ჯერ არ არის. დაამატე პირველი ჩანაწერი.")}</div>}</section><section className="panel score-panel"><div className="panel-head"><div className="panel-title"><span className="head-icon purple"><Target size={19}/></span><div><h2>{tr("Performance Score")}</h2><p>{tr("6 მეტრიკა \u00B7 ნორმალიზებული 0\u2013100")}</p></div></div></div><ScoreChart data={metrics.radar}/><div className="score-total"><span>{tr("YOUR PERFORMANCE SCORE")}</span><div><strong>{metrics.count ? metrics.performanceScore.toFixed(1) : '—'}</strong><div className="score-track"><span style={{ width: `${metrics.performanceScore}%` }}/></div></div></div><details className="score-explanation"><summary>{tr("როგორ ითვლება ქულა?")}</summary><p>{tr("საორიენტაციო ქულა ექვსი კომპონენტის საშუალოა. Win % და Consistency პირდაპირ გამოიყენება; Profit factor და Avg win/loss 3-ზე, Recovery factor 5-ზე აღწევს 100-ს. Drawdown-ის ქულა 0% დანაკარგზე 100-ია, 20%-ზე \u2014 0. საწყისი კაპიტალის გარეშე Drawdown-ის ქულა 0-ია. \u221E მიიღება როცა შესაბამისი ზარალი არ არსებობს.")}</p><p>{tr("Win rate: დადებითი P&L / ყველა ჩანაწერი. Consistency: მოგებიანი დღეები / სავაჭრო დღეები. Partial-იც ცალკე ჩანაწერია; საბოლოო შედეგისთვის იგივე თრეიდი შეცვალე.")}</p></details></section></div>
 <div className="home-calendar panel"><div className="calendar-intro"><div><span className="eyebrow">{tr("YOUR DAILY EDGE")}</span><h2>{tr("სავაჭრო კალენდარი")}</h2></div><p>{tr("დააჭირე დღეს ჩანაწერის გასახსნელად")}</p></div><div className="calendar-highlights"><div className="calendar-highlights-head"><h3>{tr("Recent Trade Highlights")}</h3><span>{recentHighlights.length}</span></div>{recentHighlights.length?<div className="calendar-highlight-rail">{recentHighlights.map(t=><button key={t.id} className="calendar-highlight" onClick={()=>setReview(t)}><span className={`highlight-symbol ${t.pnl<0?"loss":"profit"}`}>{t.symbol.slice(0,3)}</span><span className="highlight-meta"><strong>{t.symbol}</strong><small>{t.date} · {tr(t.session)}</small></span><strong className={`highlight-pnl ${t.pnl<0?"negative":"positive"}`}>{cash(t.pnl)}</strong></button>)}</div>:<p className="calendar-highlights-empty">{tr("Your latest trade results will appear here.")}</p>}</div><TradeCalendar timezone={settings.timezone} key={`${accountId}:${currency}`} currency={currency} trades={trades} today={today} onOpenDay={openCalendarDay}/></div>
 <div className="lower-grid"><section className="panel daily-panel"><div className="panel-head"><div className="panel-title"><span className="head-icon amber"><Target size={18}/></span><div><h2>{tr("Daily Note")}</h2><p>{tr("დღის მიზნები და წესები")}</p></div></div><JournalDatePicker label={tr("დღის გეგმის თარიღი")} value={dailyDate} today={today} disabled={dailyBusy} compact onChange={switchDay}/></div><div className="daily-body"><p className="daily-quote">“{tr(quote)}”</p><label className="field">{tr("ჩემი გეგმა")}<textarea maxLength={4000} value={daily?.note ?? ''} placeholder={tr("დღის მიზანი, რისკის ლიმიტი და რაზე იმუშავებ\u2026")} onChange={e => setDaily(d => d ? { ...d, note: e.target.value } : d)} disabled={dailyBusy}/></label><div className="rule-list">{daily?.rules.map((r, i) => <label key={i}><input type="checkbox" checked={r.checked} disabled={dailyBusy} onChange={e => setDaily(d => d ? { ...d, rules: d.rules.map((rule, j) => j === i ? { ...rule, checked: e.target.checked } : rule) } : d)}/>{tr(r.label)}</label>)}</div>{dailyError && <p className="form-error" role="alert">{tr(dailyError)}</p>}<div className="daily-save"><span>{dailyDirty ? tr("შეუნახავი ცვლილებები") : tr("გეგმა შენახულია")}</span><button className="secondary" onClick={saveDay} disabled={dailyBusy || !dailyDirty}><Save size={15}/>{dailyBusy ? tr("ინახება\u2026") : tr("გეგმის შენახვა")}</button></div></div></section><section className="panel"><div className="panel-head"><div><h2>{tr("ბოლო თრეიდები")}</h2><p>{periodLabel}</p></div><button className="inline-link" onClick={() => navigate('journal')}>{tr("ყველას ნახვა")}</button></div>{journalRows.length ? <div className="recent-list">{journalRows.slice(0, 5).map(t => <button key={t.id} className="recent-trade" onClick={() => setReview(t)}><span className="symbol-avatar">{t.symbol.slice(0, 2)}</span><span><strong>{t.symbol}<small className={t.side === 'Buy' ? 'green-text' : 'red-text'}>{tr(t.side)}</small></strong><small>{t.date} · {tr(t.session)}</small></span><span className={`recent-pnl ${t.pnl < 0 ? 'red-text' : t.pnl > 0 ? 'green-text' : ''}`}><strong>{cash(t.pnl)}</strong><small>{(t.pnl / t.risk).toFixed(2)}{tr("R")}</small></span></button>)}</div> : <Empty onAdd={() => openTrade()}/>}</section></div>
 {page === 'dashboard' && <section className="dashboard-support-grid">
  <div className="dashboard-quick-actions panel"><div className="dashboard-module-heading"><div><span className="dashboard-section-kicker">{tr("YOUR WORKSPACE")}</span><h2>{tr("Quick actions")}</h2></div><ArrowUpRight size={17}/></div><div className="quick-action-grid"><button onClick={()=>openTrade()}><i className="quick-action-icon action-add"><Plus size={17}/></i><span><strong>{tr("Add trade")}</strong><small>{tr("Log a new position")}</small></span><ChevronDown size={15}/></button><button onClick={()=>window.location.assign('/imports')}><i className="quick-action-icon action-import"><Upload size={16}/></i><span><strong>{tr("Import trades")}</strong><small>{tr("Bring in your history")}</small></span><ChevronDown size={15}/></button><button onClick={()=>navigate('analysis')}><i className="quick-action-icon action-mistakes"><AlertCircle size={16}/></i><span><strong>{tr("Review mistakes")}</strong><small>{tr("Look at repeated losses")}</small></span><ChevronDown size={15}/></button><button onClick={()=>navigate('calendar')}><i className="quick-action-icon action-calendar"><CalendarDays size={16}/></i><span><strong>{tr("Open calendar")}</strong><small>{tr("Review day by day")}</small></span><ChevronDown size={15}/></button><button onClick={()=>navigate('analysis')}><i className="quick-action-icon action-stats"><ChartNoAxesCombined size={16}/></i><span><strong>{tr("Open statistics")}</strong><small>{tr("Review your results")}</small></span><ChevronDown size={15}/></button><button onClick={()=>navigate('inner')}><i className="quick-action-icon action-focus"><Target size={16}/></i><span><strong>{tr("Trader focus")}</strong><small>{tr("Check in with your process")}</small></span><ChevronDown size={15}/></button></div></div>
  <div className="dashboard-insights panel"><div className="dashboard-module-heading"><div><span className="dashboard-section-kicker">{tr("BASED ON YOUR JOURNAL")}</span><h2>{tr("Personal insights")}</h2></div><Sparkles size={17}/></div>{visible.length?<div className="dashboard-insight-list">{bestSession&&<article><span className="insight-indicator positive-indicator"><TrendingUp size={15}/></span><div><strong>{tr("Leading session")}</strong><p>{bestSession.name} · {cash(bestSession.pnl)} net across {bestSession.count} {tr("trades")}</p></div><b>{bestSession.count?`${Math.round(bestSession.wins/bestSession.count*100)}%`:"—"}<small>{tr("win rate")}</small></b></article>}{visible.some(trade=>trade.side==='Sell')?<article><span className={`insight-indicator ${shortSummary<0?'negative-indicator':'neutral-indicator'}`}><Activity size={15}/></span><div><strong>{tr("Short positions")}</strong><p>{tr("Net result across your logged short trades")}</p></div><b className={shortSummary<0?'negative':'positive'}>{cash(shortSummary)}<small>{visible.filter(trade=>trade.side==='Sell').length} {tr("trades")}</small></b></article>:<article><span className="insight-indicator neutral-indicator"><Activity size={15}/></span><div><strong>{tr("Trade direction")}</strong><p>{tr("Log both sides to compare long and short results.")}</p></div><b>—<small>{tr("more data needed")}</small></b></article>}<article><span className="insight-indicator neutral-indicator"><LockKeyhole size={15}/></span><div><strong>{tr("Average risk")}</strong><p>{tr("Mean risk amount per recorded trade")}</p></div><b>{cash(avgRisk)}<small>{tr("per trade")}</small></b></article></div>:<p className="dashboard-insights-empty">{tr("Insights will use your journal records. Add a trade to start spotting patterns.")}</p>}</div>
 </section>}
 </>}
 {isPortfolio&&page==='dashboard'&&<PortfolioSummary accounts={accounts} trades={data?.trades??[]} start={rangeStart} end={today} onSelect={chooseAccount}/> }
 {page==='inner'&&<InnerSpace key={focusInitialStep} initialStep={focusInitialStep} today={today} trades={trades} onDirtyChange={recordInnerDirty} onProgressChange={()=>void refreshAchievements(false)} onOpenReview={trade=>{setReviewReadiness(trade.review?.readiness??null);setReviewPlannedRisk(trade.review?.plannedRisk??null);setReview(trade);}}/> }
 {page === 'strategies' && <StrategyManager strategies={strategies} onSave={saveStrategy} onDelete={deleteStrategy} onDirtyChange={recordStrategyDirty}/>}
 {page === 'achievements' && <AchievementsPage progress={achievements} busy={achievementBusy} error={achievementError} onRefresh={() => void refreshAchievements()} onAction={achievementAction} trades={data?.trades ?? []} today={today}/>}
 {page === 'calendar' && <TradeCalendar timezone={settings.timezone} currency={currency} trades={trades} today={today} onOpenDay={openCalendarDay}/>}
 {page === 'journal' && <section className="panel journal-table-panel"><div className="table-toolbar"><label className="search-box"><Search size={17}/><input aria-label={tr("თრეიდების ძებნა")} placeholder={tr("სიმბოლო, სეტაპი, ემოცია\u2026")} value={search} onChange={e => setSearch(e.target.value)}/></label><label className="trade-filter"><span>{tr("შედეგი")}</span><select aria-label={tr("შედეგის ფილტრი")} value={resultFilter} onChange={e => setResultFilter(e.target.value)}>{['All', "Win", "Loss", "Breakeven", "Partial"].map(v => <option key={v} value={v}>{v === 'All' ? tr("ყველა შედეგი") : tr(v)}</option>)}</select></label>{incompleteOnly&&<button type="button" className="secondary" onClick={()=>setIncompleteOnly(false)}>Showing incomplete · Clear</button>}<span className="trade-count">{journalRows.length}{tr(" ჩანაწერი")}</span></div>{journalRows.length ? <div className="table-scroll"><table className="trade-table"><thead><tr><th>{tr("თარიღი / დრო")}</th><th>{tr("სავაჭრო ანგარიში")}</th><th>{tr("სიმბოლო")}</th><th>{tr("შედეგი")}</th><th>{tr("Qty")}</th><th>{tr("P&L")}</th><th>{tr("Risk / R")}</th><th>{tr("სეტაპი / ემოცია")}</th><th>{tr("სქრინშოტი")}</th><th /></tr></thead><tbody>{journalRows.map(t => <tr key={t.id} tabIndex={0} onClick={event=>{if(!(event.target as HTMLElement).closest('button'))setReview(t)}} onKeyDown={event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();setReview(t)}}} aria-label={tr("{v0} თრეიდის დეტალების გახსნა",{v0:t.symbol})}><td className="trade-date"><strong>{t.date}</strong><small>{t.entryTime} – {t.exitTime}{t.exitTime < t.entryTime ? tr(" (+1 დღე)") : ''}</small></td><td><span className="account-tag">{accounts.find(account=>account.id===(t.accountId??'default'))?.name??'—'}</span></td><td className="trade-symbol"><strong>{t.symbol}</strong><small className={t.side === 'Buy' ? 'green-text' : 'red-text'}>{tr(t.side)} · {tr(t.session)}</small></td><td><span className={`result-pill ${t.result.toLowerCase()}`}>{tr(t.result)}</span></td><td>{t.quantity}</td><td className={t.pnl < 0 ? 'red-text' : t.pnl > 0 ? 'green-text' : ''}><strong>{t.pnl>0?`+${cash(t.pnl)}`:cash(t.pnl)}</strong></td><td className="trade-risk"><strong>{cash(t.risk)}</strong><small>{(t.pnl / t.risk).toFixed(2)}{tr("R")}</small></td><td className="trade-labels"><span className="trade-setup-tag">{t.tags.join(', ') || '—'}</span><small className="trade-emotion">{tradeEmotions(t).map(emotion => EMOTION_OPTIONS.includes(emotion) ? tr(emotion) : emotion).join(', ')}</small></td><td><button className="shots-button" onClick={() => setReview(t)}><ImageIcon size={16}/>{t.screenshots.length} / {MAX_SCREENSHOTS}</button></td><td><div className="row-actions"><button className="icon-button" aria-label={tr("{v0} თრეიდის შეცვლა", { v0: t.symbol })} onClick={() => openTrade(t)}><Pencil size={15}/></button><button className="icon-button danger" disabled={busy} aria-label={tr("{v0} თრეიდის წაშლა", { v0: t.symbol })} onClick={() => deleteTrade(t)}><Trash2 size={15}/></button></div></td></tr>)}</tbody></table></div> : <Empty onAdd={() => openTrade()} text={trades.length ? tr("ამ ფილტრებით თრეიდები ვერ მოიძებნა.") : tr("ჯერ თრეიდები არ გაქვს ჩაწერილი.")}/>}</section>}
 {page === 'analysis' && <StatisticsPage trades={visible} allTrades={trades} opening={opening} start={rangeStart} end={today} currency={currency} strategies={strategies} curve={curve} onReview={setReview} onFocus={() => navigate('inner')} onSetBalance={() => editBalance()} onExplore={(title, rows) => setTradeList({ title, rows })}/>}
 {isPortfolio&&page==='analysis'&&<PortfolioSummary accounts={accounts} trades={data?.trades??[]} start={rangeStart} end={today} onSelect={chooseAccount}/>}

 </>}
 <footer><span><LockKeyhole size={12}/>{tr(" მონაცემები შენს პირად ანგარიშთან ინახება.")}</span><span>{currency} · {settings.timezone}</span></footer>
 </>}
 </main></div>
 {tradeList && <Modal wide title={tradeList.title} subtitle={tr("{v0} თრეიდი \u00B7 {v1}", { v0: tradeList.rows.length, v1: cash(tradeList.rows.reduce((sum, t) => sum + t.pnl, 0)) })} onClose={() => setTradeList(null)}><div className="day-record-list">{tradeList.rows.length ? tradeList.rows.map(t => <button className="day-record" key={t.id} onClick={() => { setTradeList(null); setReview(t); }}><span className="symbol-avatar">{t.symbol.slice(0, 2)}</span><span><strong>{t.symbol} · {tr(t.side)}</strong><small>{accounts.find(a=>a.id===(t.accountId??'default'))?.name} · {t.date} · {t.entryTime} – {t.exitTime} · {tr(t.session)}</small><small>{t.strategySnapshot?.name ?? t.tags.join(', ')}</small></span><span className={`result-pill ${t.result.toLowerCase()}`}>{tr(t.result)}</span><strong className={t.pnl < 0 ? 'red-text' : t.pnl > 0 ? 'green-text' : ''}>{cash(t.pnl)}</strong><span className="day-shot-count"><ImageIcon size={16}/>{t.screenshots.length}</span></button>) : <p className="statistics-empty">{tr("ამ დღეზე ჩანაწერები ჯერ არ არის.")}</p>}<div className="form-actions"><button className="primary" disabled={!!tradeList.date && tradeList.date > today} onClick={() => openTrade(undefined, tradeList.date ?? today)}><Plus size={16}/>{tr(" თრეიდის დამატება")}</button></div></div></Modal>}
 {form && !strategyOpen && <Modal wide title={form.revision ? tr("თრეიდის შეცვლა") : tr("ახალი თრეიდი")} subtitle={tr("ჩაწერე შედეგი და კონტექსტი, რომ შემდეგ გააანალიზო.")} onClose={closeForm}><form onSubmit={saveTrade} className="trade-form"><fieldset disabled={busy}><section className="form-section"><h3><TrendingUp size={18}/>{tr(" Trade Basics")}</h3><div className="form-grid"><label className="field full">{tr("სავაჭრო ანგარიში")}<select value={form.accountId ?? 'default'} onChange={e => change('accountId', e.target.value as TradeInput['accountId'])}>{accounts.map(a => <option key={a.id} value={a.id}>{a.name} · {tr(a.type)} · {a.currency}</option>)}</select></label><label className="field">{tr("Symbol")}<NativeSelect aria-label={tr("თრეიდის სიმბოლო")} value={SYMBOL_OPTIONS.includes(form.symbol) ? form.symbol : '__other'} onChange={e => change('symbol', e.target.value === '__other' ? '' : e.target.value)}>{SYMBOL_OPTIONS.map(symbol => <option key={symbol}>{symbol}</option>)}<option value="__other">{tr("სხვა სიმბოლო")}</option></NativeSelect>{!SYMBOL_OPTIONS.includes(form.symbol) && <input required aria-label={tr("სხვა სიმბოლო")} maxLength={24} placeholder={tr("შეიყვანე სიმბოლო")} value={form.symbol} onChange={e => change('symbol', e.target.value.toUpperCase())}/>}</label><label className="field">{tr("Trade Type")}<select value={form.side} onChange={e => change('side', e.target.value as TradeInput['side'])}><option value="Buy">{tr("Buy")}</option><option value="Sell">{tr("Sell")}</option></select></label><div className="field full">{tr("Result")}<div className="result-select">{(["Win", "Loss", "Breakeven", "Partial"] as const).map(r => <button type="button" className={`${r.toLowerCase()} ${form.result === r ? 'selected' : ''}`} aria-pressed={form.result === r} key={r} onClick={() => change('result', r)}>{tr(r)}</button>)}</div></div><label className="field">{tr("Quantity")}<input type="number" required min="0.000001" max="10000000" step="any" value={form.quantity} onChange={e => change('quantity', e.target.value)}/></label><label className="field">{tr("Net P&L \u00B7 ")}{accounts.find(a => a.id === (form.accountId ?? 'default'))?.currency ?? currency}<input type="number" required step="0.01" min="-1000000000" max="1000000000" placeholder={tr("მოგება + / ზარალი \u2212")} value={form.pnl} onChange={e => change('pnl', e.target.value)}/><small>{tr("კომისიების გამოკლებით. Loss შეიყვანე მინუსით.")}</small></label><label className="field">{tr("Risk \u00B7 ")}{accounts.find(a => a.id === (form.accountId ?? 'default'))?.currency ?? currency}<input type="number" required min="0.01" max="1000000000" step="0.01" placeholder={tr("მაგ. 100")} value={form.risk} onChange={e => change('risk', e.target.value)}/></label><label className="field">{tr("Realized R:R")}<output className="calculated">{form.pnl !== '' && Number(form.risk) > 0 ? `${(Number(form.pnl) / Number(form.risk)).toFixed(2)}R` : '—'}</output><small>{tr("P&L \u00F7 Risk \u00B7 შესრულებული შედეგი")}</small></label><div className="field">{tr("თრეიდის თარიღი")}<JournalDatePicker label={tr("თრეიდის თარიღი")} value={form.date} today={today} max={today} disabled={busy} onChange={date => change('date', date)}/></div><label className="field">{tr("Trading Session")}<select value={form.session} onChange={e => change('session', e.target.value as TradeInput['session'])}>{["Asia", "London", "New York", "London / New York", "Other"].map(s => <option key={s} value={s}>{tr(s)}</option>)}</select></label><div className="field full"><TimeFormatSelector value={timeFormat} onChange={changeTimeFormat}/></div><div className="field">{tr("Entry Time")}<JournalTimePicker format={timeFormat} label={tr("Entry Time")} value={form.entryTime} disabled={busy} onChange={value => change('entryTime', value)}/></div><div className="field">{tr("Exit Time")}<JournalTimePicker format={timeFormat} label={tr("Exit Time")} value={form.exitTime} disabled={busy} onChange={value => change('exitTime', value)}/></div><p className="field-hint full">{tr("დრო: ")}{settings.timezone}{tr(". თუ Exit Time უფრო ადრეა, გასვლა მომდევნო დღედ ითვლება.")}</p></div></section>
 <section className="form-section"><h3><Target size={18}/>{tr(" Strategy & Mindset")}</h3><div className="form-grid"><div className="field full"><div className="strategy-selection-head"><span>{tr("ჩემი სტრატეგია")}</span><button type="button" className="inline-link" onClick={() => setStrategyOpen(true)}><Plus size={14}/>{tr(" შექმნა / მართვა")}</button></div>{strategies.length > 0 ? <div className="choice-grid">{strategies.map(strategy => <label className="choice-check" key={strategy.id}><Checkbox checked={form.strategyId === strategy.id} onCheckedChange={() => chooseStrategy(strategy)} disabled={busy}/><span><strong>{strategy.name}</strong><small>{strategy.checklist.length}{tr(" პირობა")}</small></span></label>)}</div> : <div className="strategy-form-empty"><Target size={23}/><p>{tr("ჯერ სტრატეგია არ გაქვს. შექმენი შენი სახელითა და პირობებით.")}</p><button type="button" className="secondary" onClick={() => setStrategyOpen(true)}><Plus size={16}/>{tr(" ჩემი სტრატეგიის შექმნა")}</button></div>}{form.strategyId && !strategies.some(s => s.id === form.strategyId) && <p className="field-hint">{tr("ისტორიული სტრატეგია: ")}{form.strategySnapshot?.name}. <button type="button" className="inline-link" onClick={() => setForm({ ...form, strategyId: null, strategySnapshot: null, strategyChecks: [], tagsText: '' })}>{tr("მოხსნა")}</button></p>}{form.strategyId && form.strategySnapshot && <div className="selected-strategy-plan"><strong>{form.strategySnapshot.name}{tr(" \u00B7 პირობები")}</strong>{form.strategySnapshot.checklist.length ? <div className="choice-grid strategy-checks">{form.strategySnapshot.checklist.map(point => <label className="choice-check" key={point}><Checkbox checked={form.strategyChecks?.includes(point) ?? false} onCheckedChange={() => toggleChoice('strategyChecks', point)} disabled={busy}/><span>{point}</span></label>)}</div> : <p className="field-hint">{tr("ამ სტრატეგიას პირობები ჯერ არ აქვს.")}</p>}<small>{form.strategyChecks?.length ?? 0} / {form.strategySnapshot.checklist.length}{tr(" შესრულებული პირობა")}</small></div>}{!form.strategyId && form.tagsText && <div className="legacy-strategy"><small>{tr("ადრე ჩაწერილი სეტაპი: ")}{form.tagsText}</small><button type="button" className="inline-link" onClick={() => setForm({ ...form, strategyId: null, strategySnapshot: null, strategyChecks: [], tagsText: '' })}>{tr("მოხსნა")}</button></div>}</div><div className="field full">{tr("ემოციები შესვლისას")}<div className="choice-grid">{[...new Set([...EMOTION_OPTIONS, ...(form.emotions ?? tradeEmotions(form))])].map(emotion => <label className="choice-check" key={EMOTION_OPTIONS.includes(emotion) ? tr(emotion) : emotion}><Checkbox checked={(form.emotions ?? tradeEmotions(form)).includes(emotion)} onCheckedChange={() => toggleChoice('emotions', emotion)} disabled={busy}/><span>{EMOTION_OPTIONS.includes(emotion) ? tr(emotion) : emotion}</span></label>)}</div><small>{tr("მონიშნე ერთი ან რამდენიმე ემოცია.")}</small></div><label className="field full">{tr("Trade Notes")}<textarea maxLength={8000} placeholder={tr("რატომ შეხვედი? რას გააკეთებ სხვაგვარად?")} value={form.notes} onChange={e => change('notes', e.target.value)}/></label></div></section>
 <ScreenshotEditor saved={form.screenshots} pending={files} removals={removals} busy={busy} onAdd={addPhotos} onRemove={(id, pending) => {
                if (pending)
                    setFiles(f => f.filter(p => p.id !== id));
                else
                    setRemovals(r => [...r, id]);
            }} onError={setFormError}/></fieldset>{formError && <div className="notice error" role="alert">{tr(formError)}</div>}<div className="form-actions"><span>{form.revision ? tr("ცვლილებები შენახვისას განახლდება.") : tr("თრეიდი დაემატება შენს პირად ჟურნალს.")}</span><button type="button" className="secondary" disabled={busy} onClick={closeForm}>{tr("გაუქმება")}</button><button className="primary" disabled={busy}><Save size={17}/>{busy ? tr("ინახება\u2026") : tr("თრეიდის შენახვა")}</button></div></form></Modal>}
  {review && <Modal wide title={review.review?tr('Trade review · {v0}',{v0:review.symbol}):tr('Review this trade · {v0}',{v0:review.symbol})} subtitle={`${review.date} · ${review.entryTime} – ${review.exitTime} · ${review.session}`} onClose={closeReview}><div className="review-body"><div className="review-summary"><span className={`result-pill ${review.result.toLowerCase()}`}>{tr(review.result)}</span><strong className={review.pnl < 0 ? 'red-text' : 'green-text'}>{cash(review.pnl)}</strong><span>{(review.pnl / review.risk).toFixed(2)}{tr("R")}</span><span>{tr("Risk ")}{cash(review.risk)}</span><span>{tr("Qty ")}{review.quantity}</span></div>{review.review&&<><div className="review-context"><span>{tr("სავაჭრო ანგარიში")}: {accounts.find(a=>a.id===(review.accountId??'default'))?.name??'—'}</span><span>{tr("სტრატეგია: ")}{review.strategySnapshot?.name ?? (review.tags.join(', ') || '—')}</span><span>{tr("ემოციები: ")}{tradeEmotions(review).map(emotion => EMOTION_OPTIONS.includes(emotion) ? tr(emotion) : emotion).join(', ')}</span></div><div className="review-conditions">{review.strategyChecks?.map(point => <span key={point}><Check size={13}/>{point}</span>)}</div><p className="trade-notes">{review.notes || tr("შენიშვნა არ არის.")}</p><ScreenshotGallery shots={review.screenshots} symbol={review.symbol}/></>}<TradeRecordDetails trade={review} justSaved={justSavedTradeId===review.id}/><TradePostReview key={`${review.id}-${review.review?.reviewedAt??'new'}`} trade={review} readiness={review.review?.readiness??reviewReadiness} plannedRisk={review.review?.plannedRisk??reviewPlannedRisk} onSave={saveTradeReview}/>{review.review&&<div className="form-actions"><button className="secondary danger-text" disabled={busy} onClick={() => deleteTrade(review)}><Trash2 size={15}/>{tr(" წაშლა")}</button><button className="primary" onClick={() => openTrade(review)}><Pencil size={16}/>{tr(" თრეიდის შეცვლა")}</button></div>}</div></Modal>}
 {strategyOpen && <Modal wide title={tr("ჩემი სტრატეგიები")} subtitle={tr("შექმენი საკუთარი გეგმა და დაბრუნდი თრეიდის ჩაწერაზე.")} onClose={closeStrategyManager}><StrategyManager strategies={strategies} onSave={saveStrategy} onDelete={deleteStrategy} onDirtyChange={recordFormStrategyDirty}/><div className="manager-return"><button className="secondary" disabled={busy} onClick={closeStrategyManager}>{tr("თრეიდზე დაბრუნება")}</button></div></Modal>}
 {accountModal && <Modal wide title={accountModal.account ? tr("ანგარიშის შეცვლა") : tr("ახალი სავაჭრო ანგარიში")} subtitle={tr("ცალკე ბალანსი, თრეიდები და სტატისტიკა თითოეული ანგარიშისთვის.")} onClose={() => {
                if (!busyRef.current)
                    setAccountModal(null);
            }}><AccountEditor account={accountModal.account} hasTrades={!!accountModal.account && accountTrades(data?.trades ?? [], accountModal.account.id).length > 0} onSave={saveAccount} onCancel={() => setAccountModal(null)}/>{accountModal.account && <div className="account-delete-action"><button className="secondary danger-text" onClick={() => askDeleteAccount(accountModal.account!)}><Trash2 size={16}/>{tr(" ანგარიშის წაშლა")}</button></div>}</Modal>}
 <AlertDialog open={!!accountDelete} onOpenChange={open => {
            if (!open && !busy)
                setAccountDelete(null);
        }}><AlertDialogContent className="account-delete-dialog"><AlertDialogHeader><AlertDialogTitle>{tr("ანგარიშის წაშლა")}</AlertDialogTitle><AlertDialogDescription>{accountDelete?.name}{tr(" გაქრება აქტიური ანგარიშებიდან. მისი თრეიდები და ფოტოები შენარჩუნდება და ანგარიშის აღდგენას შეძლებ.")}</AlertDialogDescription></AlertDialogHeader><div className="delete-account-summary"><Wallet size={19}/><strong>{accountDelete?.name}</strong><span>{accountDelete ? accountTrades(data?.trades ?? [], accountDelete.id).length : 0}{tr(" თრეიდი")}</span></div>{deleteError && <p className="form-error" role="alert">{tr(deleteError)}</p>}<AlertDialogFooter><AlertDialogCancel className="secondary" disabled={busy}>{tr("გაუქმება")}</AlertDialogCancel><AlertDialogAction className="secondary danger-text" disabled={busy} onClick={e => { e.preventDefault(); void deleteAccount(); }}><Trash2 size={16}/>{busy ? tr("იშლება\u2026") : tr("ანგარიშის წაშლა")}</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog>
 {archiveOpen && <Modal title={tr("წაშლილი ანგარიშები")} subtitle={tr("აღადგინე ანგარიში ან საბოლოოდ წაშალე მისი ჩანაწერები.")} onClose={() => {
                if (!busyRef.current)
                    setArchiveOpen(false);
            }}><div className="archived-account-list">{!data?.archivedAccounts.length&&<p>{tr("წაშლილი ანგარიშები არ არის.")}</p>}{data?.archivedAccounts.map(account => <div key={account.id}><div><strong>{account.name}</strong><p>{tr(account.type)} · {account.currency} · {accountTrades(data.trades, account.id).length}{tr(" თრეიდი")}</p></div><div className="archived-account-actions"><button className="secondary" disabled={busy} onClick={() => restoreAccount(account)}><RefreshCw size={15}/>{tr(" აღდგენა")}</button><button className="secondary danger-text" disabled={busy} onClick={()=>{setArchiveOpen(false);setDeleteError('');setAccountPurge(account);}}><Trash2 size={15}/>{tr("საბოლოოდ წაშლა")}</button></div></div>)}{error && <p className="form-error" role="alert">{tr(error)}</p>}</div></Modal>}
 <AlertDialog open={!!accountPurge} onOpenChange={open=>{if(!open&&!busy){setAccountPurge(null);setArchiveOpen(true);}}}><AlertDialogContent className="account-delete-dialog"><AlertDialogHeader><AlertDialogTitle>{tr('ანგარიშის საბოლოოდ წაშლა')}</AlertDialogTitle><AlertDialogDescription>{tr('ეს მოქმედება შეუქცევადია. ანგარიშთან ერთად საბოლოოდ წაიშლება მისი ყველა თრეიდი და სქრინშოტი. აღდგენა შეუძლებელი იქნება.')}</AlertDialogDescription></AlertDialogHeader><div className="delete-account-summary"><Wallet size={19}/><strong>{accountPurge?.name}</strong><span>{accountPurge?accountTrades(data?.trades??[],accountPurge.id).length:0}{tr(' თრეიდი')} · {accountPurge?accountTrades(data?.trades??[],accountPurge.id).reduce((sum,t)=>sum+t.screenshots.length,0):0} {tr('სქრინშოტი')}</span></div>{deleteError&&<p className="form-error" role="alert">{tr(deleteError)}</p>}<AlertDialogFooter><AlertDialogCancel className="secondary" disabled={busy}>{tr('გაუქმება')}</AlertDialogCancel><AlertDialogAction className="secondary danger-text" disabled={busy} onClick={e=>{e.preventDefault();void permanentlyDeleteAccount();}}><Trash2 size={16}/>{tr(busy?'იშლება…':'საბოლოოდ წაშლა')}</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog>
 {settingsOpen && <Modal title={tr("დროის პარამეტრები")} subtitle={tr("შენი თრეიდების საათები არჩეულ დროის სარტყელში აღირიცხება.")} onClose={closeSettings}><form className="settings-form" onSubmit={saveSettings}><label className="field">{tr("Timezone")}<select value={timezone} onChange={e => setTimezone(e.target.value)}>{['America/New_York', 'Asia/Tbilisi', 'Europe/London', 'Etc/UTC', 'Asia/Tokyo'].map(z => <option key={z}>{z}</option>)}</select></label>{error && <div className="notice error" role="alert">{tr(error)}</div>}<div className="form-actions"><button className="primary" disabled={busy}><Save size={16}/>{busy ? tr("ინახება\u2026") : tr("შენახვა")}</button></div></form></Modal>}

 {balanceHelpOpen&&<Modal title={tr('Why set opening balances?')} subtitle={tr('Opening balances are used to calculate return and risk metrics accurately.')} onClose={()=>setBalanceHelpOpen(false)}><div className="balance-help-modal"><p>{tr('Add the starting balance for each trading account. Trade P&L is then measured against the amount you actually started with.')}</p><button className="primary" onClick={()=>{setBalanceHelpOpen(false);editBalance();}}>{tr('Set balances')}</button></div></Modal>}
 {balancesOpen&&<Modal title={tr('Set balances')} onClose={()=>setBalancesOpen(false)}><div className="archived-account-list">{scope.accounts.map(account=><div key={account.id}><div><strong>{account.name}</strong><p>{account.currency} · {account.startingBalance===null?tr('ბალანსის გარეშე'):money(account.startingBalance,account.currency)}</p></div><button className="secondary" onClick={()=>{setBalancesOpen(false);setAccountModal({account});}}>{tr('ანგარიშის შეცვლა')}</button></div>)}</div></Modal>}
 {membership&&membership.subscription&&<BillingCheckoutDialog open={upgradeOpen} onOpenChange={open=>{setUpgradeOpen(open);if(!open){setUpgradeConsent(false);setUpgradeError('');}}} data={membership} busy={upgradeBusy} consent={upgradeConsent} setConsent={setUpgradeConsent} money={cents=>money(cents/100,'USD')} error={upgradeError} onPay={()=>void submitUpgrade('pay')} onFail={()=>void submitUpgrade('fail')}/>}
 </div>;
}
function TradeRecordDetails({trade,justSaved}:{trade:Trade;justSaved:boolean}){
 const conditions=trade.strategyConditions??(trade.strategySnapshot?.checklist??[]).map(label=>({id:label,label,checked:(trade.strategyChecks??[]).includes(label)}));
 const emotions=trade.emotionsAtEntry?.filter(item=>item.selected).map(item=>item.label)??tradeEmotions(trade);
 const status=tradeDataStatus(trade),score=getProcessQuality(trade),review=trade.review;
 const mistakeNames:Record<string,string>={clean:'Clean execution',early:'Entered too early',early_exit:'Exited too early',moved_stop:'Moved stop-loss',overtraded:'Overtraded',revenge:'Revenge trade',missed_confirmation:'Missed confirmation',ignored_plan:'Ignored plan',other:'Other'};
 return <section className="trade-record-details">
  {justSaved&&<div className="trade-save-confirmation" role="status"><strong>This trade is now included in Statistics and Insights.</strong><p><span>Strategy: <b>{trade.strategySnapshot?.name??'None selected'}</b></span><span>Conditions: <b>{trade.conditionsMet??conditions.filter(item=>item.checked).length} / {trade.conditionsTotal??conditions.length}</b></span><span>Entry emotion: <b>{emotions.join(', ')||'Not recorded'}</b></span><span>Post-trade review: <b>{review?'Completed':'Pending'}</b></span></p></div>}
  <div className="trade-record-heading"><div><span className={'trade-data-status status-'+status.toLowerCase().replaceAll(' ','-')}>{status}</span><span>Process quality {score===null?'—':score+'%'}</span></div><span className="trade-inclusion-badges"><i><Check size={12}/>Included in Statistics</i><i><Check size={12}/>Included in Insights</i></span></div>
  {status==='Partial'&&<p className="trade-partial-note">Partially analyzed · Add a result, strategy, or review to improve this trade’s insight coverage.</p>}
  <div className="trade-record-columns"><section><h4>Pre-trade plan</h4><p><b>Strategy</b><span>{trade.strategySnapshot?.name??'None selected'}</span></p><p><b>Readiness</b><span>{trade.preTradeReadinessScore===undefined?'Not recorded':trade.preTradeReadinessScore+' / 100'}</span></p><p><b>Planned risk</b><span>{trade.riskPlan?.plannedRiskPercent===undefined?'Not recorded':trade.riskPlan.plannedRiskPercent+'%'}</span></p><h5>Planned strategy conditions · {trade.conditionsMet??conditions.filter(item=>item.checked).length} / {trade.conditionsTotal??conditions.length}</h5><ul>{conditions.length?conditions.map(condition=><li className={condition.checked?'condition-checked':'condition-unchecked'} key={condition.id}><span>{condition.checked?'✓':'○'}</span>{condition.label}</li>):<li>No strategy conditions recorded.</li>}</ul><h5>Emotions at entry</h5><p>{emotions.join(', ')||'None recorded'}</p></section><section><h4>Post-trade reality</h4><p><b>Plan followed</b><span>{review?.planAdherence==='yes'?'Yes':review?.planAdherence==='partial'?'Partially':review?.planAdherence==='no'?'No':'Awaiting review'}</span></p><p><b>Execution quality</b><span>{review?.executionQuality?.replace('_',' ')??'Awaiting review'}</span></p><p><b>Conditions satisfied</b><span>{review?.satisfiedConditionIds?.length??0} / {conditions.length}</span></p><h5>Mistake tags</h5><p>{review?.mistakes.length?review.mistakes.map(id=>mistakeNames[id]??id).join(', '):review?'None recorded':'Awaiting review'}</p><h5>Review notes</h5><p>{review?.lesson||'Awaiting review'}</p></section></div>
 </section>;
}
function Metric({ label, value, icon, tone, detail, compact = false, visual }: {
    label: string;
    value: string;
    icon: ReactNode;
    tone: string;
    detail: ReactNode;
    compact?: boolean;
    visual?: ReactNode;
}) { const { t: tr, language, locale } = useLanguage(); return <section className={`metric ${tone}`}><div className="metric-top"><span>{label}</span><i>{icon}</i></div><strong className={compact ? 'compact' : ''}>{value}</strong><div className="metric-detail">{detail}</div>{visual&&<div className="metric-visual-wrap">{visual}</div>}</section>; }function Empty({ onAdd, text = 'პირველი თრეიდი — პირველი ნაბიჯი პროგრესისკენ.' }: {
    onAdd: () => void;
    text?: string;
}) { const { t: tr, language, locale } = useLanguage(); return <div className="empty-state"><BookOpen size={27}/><p>{tr(text)}</p><button className="secondary" onClick={onAdd}><Plus size={16}/>{tr(" თრეიდის დამატება")}</button></div>; }
function AnalysisTable({ title, subtitle, rows, currency }: {
    title: string;
    subtitle: string;
    rows: ReturnType<typeof groupPerformance>;
    currency: string;
}) { const { t: tr, language, locale } = useLanguage(); return <section className="panel"><div className="panel-head"><div><h2>{title}</h2><p>{subtitle}</p></div></div>{rows.length ? <div className="table-scroll"><table className="analysis-table"><thead><tr><th>{tr("ჯგუფი")}</th><th>{tr("თრეიდები")}</th><th>{tr("Win %")}</th><th>{tr("Net P&L")}</th></tr></thead><tbody>{rows.map(r => <tr key={r.name}><th>{r.name}</th><td>{r.count}</td><td>{r.winRate.toFixed(1)}%</td><td className={r.pnl < 0 ? 'red-text' : 'green-text'}>{money(r.pnl, currency)}</td></tr>)}</tbody></table></div> : <div className="empty-state"><Target size={26}/><p>{tr("ანალიზი პირველი თრეიდების შემდეგ გამოჩნდება.")}</p></div>}</section>; }
