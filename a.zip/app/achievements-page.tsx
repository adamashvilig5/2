'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity, ArrowRight, Award, BookOpen, Brain, CalendarCheck2, Check, CheckCircle2,
  ChevronRight, CircleGauge, ClipboardCheck, Flag, LockKeyhole,
  RefreshCw, Shield, ShieldCheck, Sparkles, Star, Target, Trophy,
} from 'lucide-react';
import { CATEGORIES, type AchievementCategory, type AchievementProgress } from '@/lib/achievements';
import type { Trade } from '@/lib/trading';
import { useLanguage } from './journal-language';

const icons: Record<AchievementCategory, typeof BookOpen> = {
  journal: BookOpen, risk: Shield, discipline: ClipboardCheck, strategy: Target,
  focus: Brain, consistency: Activity,
};

type Status = 'all' | 'earned' | 'in-progress' | 'locked';
type ProgressItem = AchievementProgress['items'][number];

function ProgressRing({ value, size = 48 }: { value: number; size?: number }) {
  const radius = 19;
  const circumference = 2 * Math.PI * radius;
  return <span className="trader-progress-ring" style={{ width: size, height: size, '--ring-progress': `${Math.max(0, Math.min(100, value))}%` } as React.CSSProperties}>
    <svg viewBox="0 0 48 48" aria-hidden="true"><circle cx="24" cy="24" r={radius}/><circle className="trader-progress-ring-value" cx="24" cy="24" r={radius} strokeDasharray={circumference} strokeDashoffset={circumference * (1 - Math.max(0, Math.min(100, value)) / 100)}/></svg>
    <strong>{value}%</strong>
  </span>;
}

export default function AchievementsPage({ progress, busy, error, onRefresh, onAction, trades, today }: {
  progress: AchievementProgress | null;
  busy: boolean;
  error: string;
  onRefresh: () => void;
  onAction: (category: AchievementCategory) => void;
  trades: Trade[];
  today: string;
}) {
  const { t, locale } = useLanguage();
  const [category, setCategory] = useState<AchievementCategory | 'all'>('all');
  const [status, setStatus] = useState<Status>('all');
  const [selected, setSelected] = useState<ProgressItem | null>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const returnFocus = useRef<HTMLElement | null>(null);
  const allItems = useMemo(() => progress?.items ?? [], [progress]);
  const level = progress?.level;

  useEffect(() => {
    if (selected && dialogRef.current && !dialogRef.current.open) {
      dialogRef.current.showModal();
      dialogRef.current.querySelector<HTMLButtonElement>('[data-detail-close]')?.focus();
    }
  }, [selected]);

  const reviews = trades.filter(trade => trade.review);
  const planAdherence = reviews.length ? Math.round(reviews.reduce((sum, trade) => sum + (trade.review!.planAdherence === 'yes' ? 100 : trade.review!.planAdherence === 'partial' ? 50 : 0), 0) / reviews.length) : null;
  const ruleTrades = trades.filter(trade => !!trade.strategySnapshot?.checklist.length);
  const ruleAdherence = ruleTrades.length ? Math.round(ruleTrades.reduce((sum, trade) => sum + trade.strategySnapshot!.checklist.filter(rule => trade.strategyChecks?.includes(rule)).length / trade.strategySnapshot!.checklist.length * 100, 0) / ruleTrades.length) : null;
  const stableRiskRate = trades.length ? Math.round((progress?.metrics.stableRiskTrades ?? 0) / trades.length * 100) : null;
  const reviewRate = trades.length ? Math.round(reviews.length / trades.length * 100) : null;
  const reviewedProcess = reviews.length ? Math.round(reviews.reduce((sum, trade) => {
    const review = trade.review!;
    const execution = review.executionChecks.length / 6 * 100;
    const adherence = review.planAdherence === 'yes' ? 100 : review.planAdherence === 'partial' ? 50 : 0;
    const risk = review.executionChecks.includes('risk') && review.executionChecks.includes('stop') ? 100 : review.executionChecks.includes('risk') || review.executionChecks.includes('stop') ? 50 : 0;
    return sum + execution * .55 + adherence * .3 + risk * .15;
  }, 0) / reviews.length) : null;
  const processScore = [reviewedProcess, ruleAdherence, stableRiskRate].filter((value): value is number => value !== null).length
    ? Math.round([reviewedProcess, ruleAdherence, stableRiskRate].filter((value): value is number => value !== null).reduce((sum, value) => sum + value, 0) / [reviewedProcess, ruleAdherence, stableRiskRate].filter((value): value is number => value !== null).length)
    : null;

  const nextBest = useMemo(() => {
    const riskAfterLoss = [...trades].sort((a, b) => (a.date + a.entryTime).localeCompare(b.date + b.entryTime));
    const afterLossRisk: number[] = [];
    const otherRisk: number[] = [];
    riskAfterLoss.forEach((trade, index) => (index > 0 && riskAfterLoss[index - 1].pnl < 0 ? afterLossRisk : otherRisk).push(trade.risk));
    const riskEscalating = afterLossRisk.length >= 2 && otherRisk.length >= 2 && afterLossRisk.reduce((sum, value) => sum + value, 0) / afterLossRisk.length > otherRisk.reduce((sum, value) => sum + value, 0) / otherRisk.length * 1.2;
    const preference: AchievementCategory = riskEscalating ? 'risk'
      : (progress?.metrics.trades ?? 0) > (progress?.metrics.reviewedTrades ?? 0) ? 'discipline'
        : (progress?.metrics.checkins ?? 0) < 7 ? 'focus'
          : (progress?.metrics.planned ?? 0) > (progress?.metrics.completePlans ?? 0) ? 'strategy'
            : 'consistency';
    const priorityIds: Partial<Record<AchievementCategory, string[]>> = {
      risk: ['consistent-risk', 'risk-protector'], discipline: ['review-habit', 'deep-review', 'first-checklist'],
      focus: ['mindset-aware', 'first-mindset'], strategy: ['first-checklist', 'first-strategy'],
      consistency: ['seven-day-streak', 'three-day-streak'], journal: ['first-entry'],
    };
    const candidates = allItems.filter(item => !item.earnedAt);
    const targeted = (priorityIds[preference] ?? []).map(id => candidates.find(item => item.id === id)).find(Boolean);
    return { item: targeted ?? [...candidates].sort((a, b) => b.percent - a.percent)[0] ?? null, riskEscalating };
  }, [allItems, progress, trades]);

  const todayProcess = progress?.todayProcess ?? [];
  const completedProcessCount = todayProcess.filter(task => task.done).length;
  const totalDailyXp = todayProcess.filter(task => task.earned).reduce((sum, task) => sum + task.xp, 0);
  const recentUnlocks = [...allItems].filter(item => item.earnedAt).sort((a, b) => (b.earnedAt ?? '').localeCompare(a.earnedAt ?? '')).slice(0, 3);
  const categorizedItems = allItems.filter(item => category === 'all' || item.category === category);
  const visibleItems = categorizedItems.filter(item => status === 'all'
    || (status === 'earned' && !!item.earnedAt)
    || (status === 'in-progress' && !item.earnedAt && item.current > 0)
    || (status === 'locked' && !item.earnedAt && item.current === 0));
  const groups = [
    { id: 'in-progress', title: 'In progress', items: visibleItems.filter(item => !item.earnedAt && item.current > 0) },
    { id: 'earned', title: 'Unlocked', items: visibleItems.filter(item => !!item.earnedAt) },
    { id: 'locked', title: 'On your roadmap', items: visibleItems.filter(item => !item.earnedAt && item.current === 0) },
  ];
  const dateLabel = (value: string) => new Intl.DateTimeFormat(locale, { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(value));

  function openDetails(item: ProgressItem) {
    returnFocus.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    setSelected(item);
  }
  function closeDetails() {
    if (dialogRef.current?.open) dialogRef.current.close();
    else setSelected(null);
  }
  function onDialogClose() {
    setSelected(null);
    requestAnimationFrame(() => returnFocus.current?.focus());
  }
  function viewRecommendation() {
    if (!nextBest.item) return;
    setSelected(nextBest.item);
  }

  return <div className="achievements-page trader-progress-page">
    <div className="achievement-banner trader-progress-heading">
      <span className="achievement-banner-icon"><Activity size={25}/></span>
      <div><span className="focus-kicker">{t('TRADER DEVELOPMENT')}</span><h2>{t('Trader Progress')}</h2><p>{t('Build habits that create a repeatable edge.')}</p></div>
      <button className="secondary" disabled={busy} onClick={onRefresh}><RefreshCw size={15} className={busy ? 'spin' : ''}/>{busy ? t('Updating…') : t('Refresh progress')}</button>
    </div>
    {error && <div className="notice error" role="alert">{t(error)}<button className="inline-link" disabled={busy} onClick={onRefresh}>{t('Try again')}</button></div>}
    {!progress ? <div className="panel empty-state"><Activity size={27}/><p>{busy ? t('Loading your progress…') : t('Refresh to calculate progress from your saved journal.')}</p></div> : <>
      <section className="panel trader-progress-hero">
        <div className="progress-hero-main">
          <div className="progress-score-orbit"><div><span>{t('PROCESS SCORE')}</span><strong>{processScore === null ? '—' : `${processScore}%`}</strong><small>{t(processScore === null ? 'Complete a review to begin' : 'Process quality · all time')}</small></div><ProgressRing value={processScore ?? 0} size={118}/></div>
          <div className="progress-rank-block"><span className="focus-kicker"><ShieldCheck size={14}/>{t('YOUR TRADING PROGRESS')}</span><h2>{t('Level ')}{level!.level}<span> · </span>{t(level!.title)}</h2><p>{t('Experience grows from your saved trading habits and journal milestones.')}</p><div className="xp-progress-caption"><strong>{level!.xp.toLocaleString()} {t('XP')}</strong><span>{level!.remaining.toLocaleString()} {t('XP to Level ')}{level!.level + 1}</span></div><div className="xp-track" role="progressbar" aria-label={t('Progress to next level')} aria-valuemin={0} aria-valuemax={level!.required} aria-valuenow={level!.current}><span style={{ width: `${level!.percent}%` }}/></div><small className="progress-rank-title">{t('Trader title')}: {t(level!.title)}</small></div>
        </div>
        <div className="progress-score-metrics">
          <div><span>{t('Rule adherence')}</span><strong>{ruleAdherence === null ? '—' : `${ruleAdherence}%`}</strong><i><b style={{ width: `${ruleAdherence ?? 0}%` }}/></i></div>
          <div><span>{t('Risk consistency')}</span><strong>{stableRiskRate === null ? '—' : `${stableRiskRate}%`}</strong><i><b style={{ width: `${stableRiskRate ?? 0}%` }}/></i></div>
          <div><span>{t('Plan adherence')}</span><strong>{planAdherence === null ? '—' : `${planAdherence}%`}</strong><i><b style={{ width: `${planAdherence ?? 0}%` }}/></i></div>
          <div><span>{t('Review consistency')}</span><strong>{reviewRate === null ? '—' : `${reviewRate}%`}</strong><i><b style={{ width: `${reviewRate ?? 0}%` }}/></i></div>
          <div><span>{t('Process streak')}</span><strong>{progress.metrics.currentStreak} {t('days')}</strong><i><b style={{ width: `${Math.min(100, progress.metrics.currentStreak / 7 * 100)}%` }}/></i></div>
          <div><span>{t('Achievements unlocked')}</span><strong>{progress.unlocked}<small> / {progress.total}</small></strong><i><b style={{ width: `${progress.total ? progress.unlocked / progress.total * 100 : 0}%` }}/></i></div>
        </div>
        <div className="progress-current-focus"><Sparkles size={16}/><span><small>{t('YOUR CURRENT FOCUS')}</small><strong>{nextBest.riskEscalating ? t('Keep risk steady after a losing trade.') : nextBest.item ? t(nextBest.item.description) : t('Keep repeating the habits that support your process.')}</strong></span></div>
      </section>

      <div className="trader-progress-top-grid">
        <section className="panel today-process-panel">
          <div className="trader-progress-section-heading"><div><span className="focus-kicker"><CalendarCheck2 size={14}/>{t('TODAY · {v0}', { v0: dateLabel(today) })}</span><h2>{t('Today’s process')}</h2><p>{t('{v0} of {v1} useful actions recorded',{v0:completedProcessCount,v1:todayProcess.length||5})}</p></div><ProgressRing value={todayProcess.length ? Math.round(completedProcessCount / todayProcess.length * 100) : 0}/></div>
          <div className="today-process-list">{todayProcess.map(task => <div className={`today-process-item ${task.done ? 'is-done' : ''}`} key={task.id}><span className="today-process-check">{task.done ? <Check size={14}/> : <i/>}</span><span><strong>{t(task.title)}</strong><small>{task.done ? t(task.earned ? 'Saved for today' : 'Recorded · checking reward') : t('Complete this in your workspace')}</small></span><b>{task.earned ? `+${task.xp} XP` : `${task.xp} XP`}</b></div>)}</div>
          <div className="today-process-footer"><span>{t('Earned today')} <strong>+{totalDailyXp} XP</strong></span><small>{t('Daily process XP is awarded once for each saved action.')}</small></div>
        </section>

        <section className="panel next-best-panel">
          <div className="trader-progress-section-heading"><div><span className="focus-kicker"><Target size={14}/>{t('A PRACTICAL NEXT STEP')}</span><h2>{t('Your next best achievement')}</h2></div><span className="next-best-label">{t('RECOMMENDED')}</span></div>
          {nextBest.item ? <>
            <div className="next-best-achievement"><span className="next-best-icon"><ShieldCheck size={23}/></span><div><h3>{t(nextBest.item.title)}</h3><p>{nextBest.riskEscalating ? t('Your recorded risk has tended to rise after losses. Keep it consistent with your plan.') : t(nextBest.item.description)}</p></div></div>
            <div className="next-best-progress"><span>{nextBest.item.current} / {nextBest.item.target}</span><strong>{nextBest.item.target - nextBest.item.current} {t('to go')}</strong><i><b style={{ width: `${nextBest.item.percent}%` }}/></i></div>
            <div className="next-best-actions"><button className="secondary" onClick={viewRecommendation}>{t('View requirements')}<ChevronRight size={15}/></button><button className="primary" onClick={() => onAction(nextBest.item!.category)}>{t('Take the next step')}<ArrowRight size={15}/></button></div>
            <small className="next-best-reward">{t('Earn')} <strong>+{nextBest.item.xp} XP</strong> · {t(nextBest.item.tier)}</small>
          </> : <div className="achievement-empty"><CheckCircle2 size={24}/><p>{t('You have unlocked every achievement. Keep building your process.')}</p></div>}
        </section>
      </div>

      <div className="achievement-wall-heading trader-progress-wall-heading"><div><span className="focus-kicker"><Activity size={14}/>{t('LONG-TERM HABITS')}</span><h2>{t('Your Trading Progress')}</h2><p>{t('Build habits that create a repeatable edge.')}</p></div><strong>{Math.round(progress.unlocked / progress.total * 100)}%<small>{t('complete')}</small></strong></div>
      <div className="achievement-filters trader-progress-filters"><div className="achievement-category-tabs" role="tablist" aria-label={t('Achievement categories')}>
        <button role="tab" className={category === 'all' ? 'active' : ''} aria-selected={category === 'all'} onClick={() => setCategory('all')}>{t('All')}<small>{allItems.length}</small></button>
        {CATEGORIES.map(item => <button role="tab" key={item.id} className={category === item.id ? 'active' : ''} aria-selected={category === item.id} onClick={() => setCategory(item.id)}>{t(item.label)}<small>{allItems.filter(achievement => achievement.category === item.id).length}</small></button>)}
      </div><label className="achievement-status-filter"><span>{t('Status')}</span><select aria-label={t('Filter achievements by status')} value={status} onChange={event => setStatus(event.target.value as Status)}><option value="all">{t('All statuses')}</option><option value="earned">{t('Unlocked')}</option><option value="in-progress">{t('In progress')}</option><option value="locked">{t('Locked')}</option></select></label></div>

      {groups.map(group => group.items.length > 0 && <section className={`trader-progress-group ${group.id}`} key={group.id}><div className="trader-progress-group-heading"><div><h3>{t(group.title)}</h3><p>{t(group.id === 'in-progress' ? 'Habits already underway.' : group.id === 'earned' ? 'Milestones earned through your saved history.' : 'Clear requirements. Progress starts with your next session.')}</p></div><span>{group.items.length.toString().padStart(2, '0')}</span></div><div className="achievement-grid trader-progress-achievement-grid">
        {group.items.map(item => { const Icon = icons[item.category]; const earned = !!item.earnedAt; const inProgress = !earned && item.current > 0; return <article key={item.id} className={`achievement-card trader-progress-card ${earned ? 'earned' : inProgress ? 'in-progress' : 'locked'} ${item.tier.toLowerCase()}`}>
          <div className="achievement-card-top"><span className="achievement-category">{t(CATEGORIES.find(entry => entry.id === item.category)?.label ?? '')}</span><span className={`achievement-state ${earned ? 'done' : inProgress ? 'working' : ''}`}>{earned ? <><Check size={12}/>{t('Unlocked')}</> : inProgress ? t('In progress') : <><LockKeyhole size={11}/>{t('Locked')}</>}</span></div>
          <button type="button" className="trader-progress-card-open" onClick={() => openDetails(item)} aria-label={`${t('View requirements')}: ${t(item.title)}`}><span className="achievement-symbol"><svg className="achievement-ring" viewBox="0 0 64 64" aria-hidden="true"><circle className="achievement-ring-track" cx="32" cy="32" r="27"/><circle className="achievement-ring-value" cx="32" cy="32" r="27" strokeDasharray={`${2 * Math.PI * 27}`} strokeDashoffset={`${2 * Math.PI * 27 * (1 - item.percent / 100)}`}/></svg><Icon size={24}/></span><span className="trader-progress-card-copy"><strong>{t(item.title)}</strong><small>{t(item.description)}</small></span></button>
          <div className="achievement-progress-label"><span className="achievement-count" key={item.current}>{item.current} / {item.target}</span><span>{item.percent}%</span></div><div className="trader-progress-bar"><i><b style={{ width: `${item.percent}%` }}/></i><span>{earned ? t('Completed') : t('{v0} remaining', { v0: Math.max(0, item.target - item.current) })}</span></div>
          <div className="achievement-card-bottom"><span className="achievement-tier">{t(item.tier)}</span><strong><Star size={12}/>{item.xp} {t('XP')}</strong></div>{earned ? <small className="achievement-date">{t('Unlocked')} · {item.earnedAt ? dateLabel(item.earnedAt) : ''}</small> : <button className="achievement-ticker" onClick={() => onAction(item.category)}><span>{t(item.description)}</span><ArrowRight size={13}/></button>}
        </article>; })}
      </div></section>)}
      {!visibleItems.length && <div className="panel empty-state"><Award size={26}/><p>{t('No achievements match these filters.')}</p></div>}

      <div className="trader-progress-bottom-grid">
        <section className="panel process-score-panel"><div className="trader-progress-section-heading"><div><span className="focus-kicker"><CircleGauge size={14}/>{t('PROCESS METRICS')}</span><h2>{t('Your process score')}</h2></div>{processScore !== null && <strong className="process-score-value">{processScore}%</strong>}</div><div className="process-score-list">{[
          { label: 'Rule adherence', value: ruleAdherence }, { label: 'Risk consistency', value: stableRiskRate }, { label: 'Plan adherence', value: planAdherence }, { label: 'Review consistency', value: reviewRate },
        ].map(metric => <div key={metric.label}><span>{t(metric.label)}</span><strong>{metric.value === null ? '—' : `${metric.value}%`}</strong><i><b style={{ width: `${metric.value ?? 0}%` }}/></i></div>)}</div><p className="process-score-note"><ShieldCheck size={14}/>{t('Your score measures recorded process quality, not only trading outcomes.')}</p></section>
        <section className="panel recent-unlocks-panel"><div className="trader-progress-section-heading"><div><span className="focus-kicker"><Trophy size={14}/>{t('MILESTONE HISTORY')}</span><h2>{t('Recent unlocks')}</h2></div></div>{recentUnlocks.length ? <div className="recent-unlock-list">{recentUnlocks.map(item => { const Icon = icons[item.category]; return <div key={item.id}><span><Icon size={16}/></span><p><strong>{t(item.title)}</strong><small>{item.earnedAt ? dateLabel(item.earnedAt) : ''}</small></p><b>+{item.xp} XP</b></div>; })}</div> : <div className="achievement-empty"><Flag size={21}/><p>{t('Your first milestone will appear here. Start with one saved trade or check-in.')}</p></div>}</section>
      </div>
      <p className="achievement-footnote">{t('Achievements are calculated from saved trades, reviews, checklists, daily plans, and check-ins. XP rewards are recorded once; the process score reflects recorded decisions rather than profit alone.')}</p>
    </>}

    <dialog ref={dialogRef} className="achievement-detail-dialog" onClose={onDialogClose} onCancel={event => { event.preventDefault(); closeDetails(); }} onClick={event => { if (event.target === dialogRef.current) closeDetails(); }}>
      {selected && <div className="achievement-detail-content"><div className="achievement-detail-header"><span className="focus-kicker"><ShieldCheck size={14}/>{t(CATEGORIES.find(entry => entry.id === selected.category)?.label ?? '')} · {t(selected.tier)}</span><button type="button" data-detail-close className="icon-button" aria-label={t('Close')} onClick={closeDetails}>×</button></div><span className="achievement-detail-icon">{(() => { const Icon = icons[selected.category]; return <Icon size={27}/>; })()}</span><h2>{t(selected.title)}</h2><p className="achievement-detail-description">{t(selected.description)}</p><div className="achievement-detail-progress"><div><span>{t('Current progress')}</span><strong>{selected.current} / {selected.target}</strong></div><ProgressRing value={selected.percent} size={62}/><i><b style={{ width: `${selected.percent}%` }}/></i></div><div className="achievement-detail-requirement"><span>{t('Requirement')}</span><p>{t(selected.description)}</p><small>{selected.earnedAt ? t('Completed {v0}', { v0: dateLabel(selected.earnedAt) }) : t('{v0} more to unlock', { v0: Math.max(0, selected.target - selected.current) })}</small></div><div className="achievement-detail-reward"><span><Star size={15}/>{t('Reward')}</span><strong>+{selected.xp} XP</strong></div><button className="primary achievement-detail-action" onClick={() => { const action = selected.category; closeDetails(); onAction(action); }}>{t(selected.earnedAt ? 'View your workspace' : 'Start focused session')}<ArrowRight size={15}/></button></div>}
    </dialog>
  </div>;
}
