import SettingsPage from './settings-panel';
export default function Page(){return <SettingsPage/>;}
