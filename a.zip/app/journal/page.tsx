import TradingJournal from '../trading-journal';
import {getChatGPTUser} from '../chatgpt-auth';
import {currentMember,subscriptionFor,hasMemberCookie} from '@/lib/member-server';
import {SITE_OWNER_ID,hasAccess} from '@/lib/membership';
import {redirect} from 'next/navigation';
export const dynamic='force-dynamic';
export default async function Home(){
 const member=await currentMember(),user=await getChatGPTUser();
 if(member){const subscription=await subscriptionFor(member.id);if(!subscription)redirect('/?choosePlan=1');if(!hasAccess(member,subscription))redirect('/?checkout=1');}
 if(!member&&(!user||user.userId!==SITE_OWNER_ID||await hasMemberCookie()))redirect('/?auth=login');
 return <TradingJournal/>;
}
